"""Call an OpenAI-compatible chat API. The key never belongs in source code.

Set AI_API_KEY in the environment. Optional:
  AI_BASE_URL  default https://api.x.ai/v1
  AI_MODEL     default grok-4.5
"""

from __future__ import annotations

import os

import requests

from prompts import SYSTEM_PROMPT


def ask_coach(question: str, context: str, history: list[dict] | None = None) -> str:
    question = question.strip()
    if not question:
        return "Type a question before sending."
    api_key = os.getenv("AI_API_KEY") or os.getenv("XAI_API_KEY")
    if not api_key:
        return (
            "The AI key is not configured. Set AI_API_KEY and try again. "
            "The readiness score and career matches still work without the coach."
        )

    base = os.getenv("AI_BASE_URL", "https://api.x.ai/v1").rstrip("/")
    model = os.getenv("AI_MODEL", "grok-4.5")
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "system",
            "content": context
            or "No student profile was provided. Say that more information is required.",
        },
    ]
    for item in (history or [])[-6:]:
        role = item.get("role")
        content = str(item.get("content", "")).strip()
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content[:1800]})
    messages.append({"role": "user", "content": question[:1200]})

    try:
        response = requests.post(
            f"{base}/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"model": model, "temperature": 0.4, "max_tokens": 700, "messages": messages},
            timeout=40,
        )
    except requests.RequestException:
        return "Could not reach the AI service. Please try again in a moment."

    if response.status_code != 200:
        return f"The AI service returned an error ({response.status_code}). Please try again once."
    try:
        text = response.json()["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, TypeError, ValueError):
        return "The AI returned an empty answer. Please try again."
    return text or "The AI returned an empty answer. Please try again."
