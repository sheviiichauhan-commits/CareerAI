# CareerAI — 15-slide presentation

Use these slides in order. The website Guide page has the same text.

## Slide 1: CareerAI

**On the slide**

- Understand your skills. Discover your career. Build your future.
- A student analytics project for BBA: Excel, SQL, Python, Power BI, and AI in one flow.
- Demo data only. The score is a classroom model, not a job prediction.

**What to say**

Good morning. CareerAI helps a student see their skills, gaps, and a short learning plan. I will show the website, then the data behind it.

## Slide 2: Problem statement

**On the slide**

- Students collect marks and certificates but still cannot explain which role fits.
- Skill gaps stay hidden until placement season.
- Teachers do not get one view of attendance, skills, and career interest together.

**What to say**

The problem is not a lack of marks. It is a lack of a simple picture that a student and a teacher can both use.

## Slide 3: Objectives

**On the slide**

- Collect a student profile and an assessment.
- Calculate a transparent Career Readiness score from 0 to 100.
- Recommend three careers, list gaps, and give a 30-day roadmap.
- Give teachers cohort charts and a Power BI file.
- Let a student ask an AI coach that can see the saved profile.

**What to say**

Every objective is something you can click in the prototype. I am not only describing a diagram.

## Slide 4: Technology stack

**On the slide**

- Excel for the fictional cohort.
- MySQL for related tables and queries.
- Python, Pandas, and NumPy for cleaning and analysis.
- A website for registration, assessment, results, and the coach.
- Power BI for the three teacher dashboards.

**What to say**

I chose tools from our course, and I connected them so each one has a job. Excel is the source, SQL stores it, Python calculates, the website explains, Power BI summarises.

## Slide 5: System architecture

**On the slide**

- Excel to cleaning to MySQL.
- Python readiness score and recommendation rules.
- Website shows the same numbers to the student.
- Analytical CSV feeds Power BI.
- The coach prompt is fixed. The student facts are added as context.

**What to say**

Please look at the Project files page. The eight steps are the architecture. The website and the Python file use the same weights, and I checked that they match.

## Slide 6: Dataset

**On the slide**

- 320 fictional students. No real personal data.
- Sheets: Students, Academic_Data, Skills, Career_Interest, Placement.
- Skills are scored from 1 to 10.
- A small dirty sample in the Python cleaning demo shows missing values and duplicates.

**What to say**

I did not use anyone’s real marks. Names and packages are invented. There are ready-made profiles, such as Aanya for a strong data match and Rohan for a low score.

## Slide 7: SQL database and queries

**On the slide**

- Database name: careerai_db.
- Primary keys on each table. Student_ID is the foreign key.
- Ten queries: low attendance, averages, skill gaps, placement, and one large JOIN.
- The high-readiness query repeats the same formula as the website.

**What to say**

A primary key identifies a row. A foreign key stops an academic row from pointing at a student who does not exist. I can open queries.sql and explain any one of them.

## Slide 8: Python data analysis

**On the slide**

- Pandas reads the five sheets and merges them on Student_ID.
- Cleaning handles duplicates, bad types, missing numbers, and scores outside range.
- Analytics reports average CGPA, attendance, skills, placement, and the most common gap.
- In this sample, Python is the most common skill below 6.

**What to say**

Pandas is the library that turns the Excel sheets into tables I can average and join. The cleaning function is separate so I can show a messy table and a clean one.

## Slide 9: Power BI dashboard

**On the slide**

- Page 1: student overview and department performance.
- Page 2: skill averages and skill gaps.
- Page 3: career preference, match, readiness bands, placement by interest.
- Slicers: department, year, gender, and career interest.
- The website admin page previews the same measures.

**What to say**

Power BI is not inside the browser. I prepared the CSV and the page plan. The admin screen is the live preview of those measures.

## Slide 10: Career recommendation

**On the slide**

- Sixteen careers across analytics, business, finance, marketing, operations, and software.
- Skill fit uses published weights. Data Analyst leans on SQL, Python, Excel, Power BI, and analysis.
- Interest fit depends on first choice, second choice, and other ticks.
- Final match is 78% skills and 22% interest. Top three are shown.

**What to say**

This is a rule, not a hidden model. If I change a Python rating, the Data Analyst percentage moves, and I can explain why.

## Slide 11: AI chatbot

**On the slide**

- Page name: AI Career Coach.
- The student can ask about careers, skills, projects, internships, and a resume.
- The coach receives the stored profile and the scores already calculated.
- If the key is missing or the service fails, the page says so. The rule-based score still works.

**What to say**

I do not let the model invent a CGPA. The numbers are passed in. I also tell the user that an AI answer can be wrong.

## Slide 12: Prompt engineering

**On the slide**

- A system prompt defines the role, the limits, and the eight-part answer.
- The prompt says: do not invent facts, and do not decide the student’s future.
- Headings: recommendation, why it fits, strengths, gaps, skills, projects, roadmap, advice.
- The prompt is visible on the Project files page.

**What to say**

Prompt engineering here means writing the instruction carefully, then attaching the real student context. The wording is part of the project, not a hidden trick.

## Slide 13: Complete workflow

**On the slide**

- Register, then complete the assessment.
- The profile is saved and the Python-equivalent rules run in the website.
- The student sees the score, matches, gaps, projects, and 30-day plan.
- They can ask the coach. A teacher opens Admin and the Power BI file.

**What to say**

I will demonstrate with Aanya Deshmukh, then with Rohan Das, so you can see a high score and a low score from the same formula.

## Slide 14: Benefits and future scope

**On the slide**

- Students get language they can use in a resume or an internship application.
- Teachers see which skill is weak across a department.
- Later ideas: resume check, internship matching, mock interview, voice coach.
- Those are future work. They are not claimed as finished.

**What to say**

The benefit today is clarity. The future list is honest about what this version does not do.

## Slide 15: Conclusion

**On the slide**

- CareerAI connects Excel, SQL, Python, Power BI, and a guided chatbot.
- The score is project-defined and explained on the result page.
- Recommendations are guidance. The dataset is fictional.
- Thank you. I can take questions from the viva list or from the live profile.

**What to say**

I will close by repeating the limit: this should not be used to accept or reject a student. It is a learning and guidance tool. I am happy to take questions.
