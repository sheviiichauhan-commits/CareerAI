# CareerAI

CareerAI helps a college student see a Career Readiness score, three career matches, skill gaps, project ideas, and a 30-day plan. A teacher view summarises the whole fictional cohort.

The live website and the Python package use the **same weights**. The score is a classroom model. It is not a scientific employability test, and it must not be used to accept or reject a student.

## 1. What you can show

- Register a demo student and submit the assessment.
- Open sample profiles such as Aanya Deshmukh (`CAI24001`) and Rohan Das (`CAI24006`).
- Read the score breakdown on the result page.
- Ask the AI Career Coach a question about that profile.
- Open Admin for cohort charts, then download the Power BI file.
- Use the Presentation and viva page while you speak.

## 2. Technologies

| Piece | Role |
| --- | --- |
| Website | Registration, assessment, results, dashboard, coach, admin |
| Excel | 320 fictional students on five sheets |
| Python / Pandas | Cleaning, cohort stats, the scoring rules |
| MySQL | Tables and ten commented queries |
| Power BI | Three dashboard pages, built from the CSV |
| AI coach | A fixed system prompt plus the saved student facts |

## 3. Project layout

```
careerai/
├── app.py                      Streamlit home page
├── pages/                      Registration, assessment, results, dashboard, coach, admin
├── screenpack.py               Screen functions used by Streamlit
├── database/schema.sql         Creates careerai_db
├── database/queries.sql        Ten teaching queries
├── database/seed_demo_20.sql   First 20 students
├── python/                     Cleaning, scoring, recommendations, Excel import
├── data/CareerAI_Student_Data.xlsx
├── ai/prompts.py               Coach system prompt
├── ai/chatbot.py               Calls the AI API from Python
├── powerbi/                    CSV and dashboard notes
├── requirements.txt
├── .env.example
├── PRESENTATION.md
└── VIVA.md
```

The interactive website that runs in the browser is the front end of this same project. Its scoring code is the TypeScript twin of `python/career_scoring.py` and `python/recommendation.py`.

## 4. Python setup

From the `careerai` folder:

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS or Linux:

```bash
source .venv/bin/activate
```

```bash
pip install -r requirements.txt
```

## 5. See the analysis without MySQL

```bash
cd python
python data_cleaning.py
python analytics.py
```

`data_cleaning.py` prints a before-and-after on a tiny messy table.

`analytics.py` reads the Excel file and prints average CGPA, attendance, placement, the most preferred career, and the most common skill gap.

## 6. MySQL

1. Install MySQL and open a client.
2. Run `database/schema.sql`. This creates `careerai_db` and the five tables.
3. Copy `.env.example` to `.env`.
4. Set `DB_HOST`, `DB_USER`, `DB_PASSWORD`, and `DB_NAME`. Do not put the password in a Python file.
5. Import every student:

```bash
cd python
python import_excel.py
```

For a smaller demo, run `database/seed_demo_20.sql` after the schema. That loads 20 fictional students.

Then run the queries in `database/queries.sql`. Each query has a comment that says what it answers.

Tables:

- `Students` — primary key `Student_ID`
- `Academic` — foreign key `Student_ID`
- `Skills` — foreign key `Student_ID`
- `Career_Interest` — foreign key `Student_ID`
- `Placement` — foreign key `Student_ID`

## 7. Streamlit

From the `careerai` folder:

```bash
streamlit run app.py
```

Use the sidebar. Home, registration, assessment, recommendations, dashboard, chatbot, and admin are separate screens. New registrations are stored in `data/local_profiles.json` on that computer. The shared Excel file is not overwritten.

## 8. AI coach

The website coach calls the model from the server. The key is never sent to the browser.

For the Python coach, set these in `.env` or in the environment:

```
AI_API_KEY=your_key_here
AI_BASE_URL=https://api.x.ai/v1
AI_MODEL=grok-4.5
```

If the key is missing, the coach says so. The rule-based score still works.

Try these questions after a profile is selected:

- What career is suitable for me?
- What skills should I improve?
- Give me a 30-day learning plan.
- What should I learn before applying for an internship?

The coach is told not to invent marks. It should quote the project score that was already calculated.

## 9. Power BI

Follow `powerbi/dashboard_documentation.md`.

Short version: import `powerbi/CareerAI_Analytical.csv`, add slicers for Department, Year, Gender, and First_Choice, and build the three pages (overview, skills, careers).

## 10. How the score works

Out of 100:

- CGPA, on a 10-point scale: 25%
- Average of Excel, SQL, Python, Power BI, and Data Analysis: 30%
- Communication: 15%
- Attendance: 10%
- Internship: 10% (0 internships = 0, one = 6, two or more = 10)
- Certifications: 10% (0 = 0, 1 = 4, 2 = 7, 3 or more = 10)

Bands, after rounding to a whole number:

- 80–100 Highly Ready
- 60–79 Moderately Ready
- Below 60 Needs Improvement

A skill below 6/10 is a gap. A skill of 7/10 or more is a strength.

Career match = 78% skill fit + 22% interest fit. The weights are written in `python/career_scoring.py` and on the Project files page.

## 11. Suggested demonstration

1. Open the home page and show Aanya Deshmukh (high score, Data Analyst).
2. Open the result breakdown so the marks in the formula are visible.
3. Open Rohan Das (`CAI24006`) and show Needs Improvement.
4. Ask the coach one question about Aanya.
5. Open Admin, point at the Python skill gap, and mention the Power BI file.
6. If the examiner wants SQL, run query 10 (the big JOIN) and query 8 (high readiness).

## 12. Limits

- Every student in the workbook is fictional.
- Recommendations are guidance, not a guaranteed career.
- The readiness score was defined for this project. It is not a validated test.
- AI answers can be wrong. Read them before you repeat them.
- Do not use the system for high-stakes decisions about students.

## 13. Possible later work

Resume review, an application-form score, job and internship suggestions, a mock interview, generated interview questions, a LinkedIn review, a voice coach, placement prediction, and a longer personal learning plan. None of those are part of this version.
