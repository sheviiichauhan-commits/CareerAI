"""CareerAI Streamlit entry.

Run from this folder:

    streamlit run app.py

The sidebar comes from the files in pages/. This home screen is the first page.
"""

import streamlit as st

st.set_page_config(page_title="CareerAI", layout="wide")

from screenpack import screen_home

screen_home()
