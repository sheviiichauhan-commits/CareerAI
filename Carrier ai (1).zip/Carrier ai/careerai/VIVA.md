# CareerAI — viva questions

Short answers a student can say aloud. Twenty-two questions.

## 1. Why did you select this project?

Students struggle to connect marks and skills to a career. This project uses the tools from our course to make that connection visible.

## 2. Why Excel?

Excel is where the raw cohort starts. It is easy to show, easy to edit, and Power BI and Pandas can both read it.

## 3. Why SQL?

SQL keeps students, marks, skills, interests, and placement in related tables so I can ask questions without scrolling through sheets.

## 4. Why Python?

Python and Pandas clean the data and calculate the score and the career matches. The same rules are used on the website.

## 5. Why Power BI?

Power BI is for the teacher view: filters, cards, and charts. The website previews those measures, and the CSV is ready to import.

## 6. What is a database?

A database is an organised store of tables. Here the database is careerai_db.

## 7. What is a primary key?

A primary key uniquely identifies each row. Student_ID is the primary key of the Students table.

## 8. What is a foreign key?

A foreign key is a column that must match a primary key in another table. Academic.Student_ID must exist in Students.

## 9. What is data cleaning?

Cleaning fixes problems before analysis: duplicate IDs, blank cells, text in a number column, and scores outside the allowed range.

## 10. What is Pandas?

Pandas is a Python library for tables. I use it to read Excel, merge sheets, and calculate averages.

## 11. What is Power BI?

Power BI is a Microsoft tool for interactive dashboards. This project prepares the dataset and the three-page plan.

## 12. What is AI in this project?

AI is the Career Coach. It writes guidance from the student’s saved facts. It does not calculate the official score. The rules do that.

## 13. What is a chatbot?

A chatbot is a conversation screen. The student types a question and the coach answers using the profile and a fixed prompt.

## 14. What is prompt engineering?

It is the design of the instruction sent to the model: the role, the banned behaviour, the student facts, and the required headings.

## 15. How does the recommendation system work?

Each career has skill weights. Skill fit is the weighted score. Interest fit comes from the student’s choices. Match is 78% skill fit plus 22% interest fit. The top three are shown.

## 16. How is Career Readiness calculated?

CGPA 25%, technical skills 30%, communication 15%, attendance 10%, internship 10%, certifications 10%. The total is rounded to a whole number. 80 and above is Highly Ready, 60 to 79 is Moderately Ready, below 60 needs improvement.

## 17. How does the website communicate with the database?

In the college package, Python writes rows into MySQL. In this prototype, the sample cohort is loaded with the app and new assessments are saved in the browser, using the same fields as the SQL tables.

## 18. How does the chatbot receive student information?

When the student sends a question, the website adds their stored profile and the calculated scores to the prompt. The API key stays on the server.

## 19. What are the limitations?

The data is fictional. The score is not a scientific employability test. AI can be wrong. The system must not make high-stakes decisions about students.

## 20. What is the future scope?

Resume analysis, an ATS-style score, job and internship suggestions, mock interviews, interview questions, LinkedIn review, a voice coach, placement prediction, and more personal learning plans.

## 21. Why is a skill below 6 called a gap?

That threshold is a project rule so the definition stays clear. It is not an industry standard.

## 22. What happens if the AI service fails?

The page shows a plain error. The readiness score, matches, gaps, and roadmap still come from the rules, so the demo can continue.
