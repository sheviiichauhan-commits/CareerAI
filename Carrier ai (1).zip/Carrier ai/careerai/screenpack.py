"""Streamlit screens for the college package. The website in the browser uses the same rules."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "python"))
sys.path.insert(0, str(ROOT / "ai"))

from career_scoring import CAREERS, normalize  # noqa: E402
from recommendation import analyze_student  # noqa: E402

EXCEL = ROOT / "data" / "CareerAI_Student_Data.xlsx"
OVERRIDES = ROOT / "data" / "local_profiles.json"


def _load_overrides() -> dict:
    if not OVERRIDES.exists():
        return {}
    return json.loads(OVERRIDES.read_text(encoding="utf-8"))


def _save_overrides(data: dict) -> None:
    OVERRIDES.write_text(json.dumps(data, indent=2), encoding="utf-8")


@st.cache_data
def load_cohort() -> pd.DataFrame:
    students = pd.read_excel(EXCEL, sheet_name="Students")
    academic = pd.read_excel(EXCEL, sheet_name="Academic_Data")
    skills = pd.read_excel(EXCEL, sheet_name="Skills")
    interest = pd.read_excel(EXCEL, sheet_name="Career_Interest")
    placement = pd.read_excel(EXCEL, sheet_name="Placement")
    frame = students.merge(academic, on="Student_ID").merge(skills, on="Student_ID")
    frame = frame.merge(interest, on="Student_ID").merge(placement, on="Student_ID")
    return frame


def all_records() -> dict[str, dict]:
    records = {}
    for raw in load_cohort().to_dict(orient="records"):
        record = normalize(raw)
        records[record["student_id"]] = record
    for student_id, record in _load_overrides().items():
        records[student_id] = record
    return records


def current_id() -> str | None:
    return st.session_state.get("student_id")


def screen_home() -> None:
    st.title("CareerAI")
    st.subheader("Understand your skills. Discover your career. Build your future.")
    st.write(
        "This is the Python side of the project. It reads the Excel cohort, scores a student "
        "with the same rules as the website, and can call the AI coach when AI_API_KEY is set."
    )
    st.info("Demo data only. The readiness score is a classroom model, not a job prediction.")
    records = all_records()
    st.metric("Students in the cohort", len(records))
    choice = st.selectbox("Open a classroom profile", ["CAI24001", "CAI24002", "CAI24003", "CAI24004", "CAI24005", "CAI24006"])
    if st.button("Use this profile"):
        st.session_state["student_id"] = choice
        st.success(f"Selected {records[choice]['name']}. Open Assessment or Recommendations from the sidebar.")


def screen_registration() -> None:
    st.title("Student registration")
    st.caption("Use a demo name and a demo email. Do not enter anyone’s real private information.")
    with st.form("register"):
        student_id = st.text_input("Student ID", placeholder="CAIU1024")
        name = st.text_input("Name")
        age = st.number_input("Age", min_value=16, max_value=40, value=20)
        gender = st.selectbox("Gender", ["Female", "Male", "Other", "Prefer not to say"])
        course = st.selectbox("Course", ["BBA", "B.Com", "BCA"])
        year = st.selectbox("Year", [1, 2, 3])
        semester = st.selectbox("Semester", [1, 2, 3, 4, 5, 6])
        department = st.selectbox(
            "Department",
            ["Marketing", "Finance", "Human Resources", "Operations", "Accounting", "General Management", "Information Technology", "Data Analytics"],
        )
        email = st.text_input("Email", placeholder="name@demo.careerai.edu")
        submitted = st.form_submit_button("Save and continue")
    if not submitted:
        return
    if len(student_id.strip()) < 4 or "@" not in email or len(name.strip()) < 3:
        st.error("Check the student ID, name, and email.")
        return
    record = {
        "student_id": student_id.strip().upper(),
        "name": name.strip(),
        "age": int(age),
        "gender": gender,
        "course": course,
        "year": int(year),
        "semester": int(semester),
        "department": department,
        "email": email.strip(),
        "cgpa": 0,
        "attendance": 0,
        "backlogs": 0,
        "internships": 0,
        "certifications": 0,
        "excel": 5,
        "sql": 5,
        "python": 5,
        "powerbi": 5,
        "communication": 5,
        "data_analysis": 5,
        "interests": [],
        "first_choice": "",
        "second_choice": "",
        "placement_status": "In Progress",
        "package_lpa": None,
        "assessed": False,
    }
    saved = _load_overrides()
    saved[record["student_id"]] = record
    _save_overrides(saved)
    st.session_state["student_id"] = record["student_id"]
    st.success("Saved on this computer in data/local_profiles.json. Continue to the assessment page.")


def screen_assessment() -> None:
    st.title("Career assessment")
    records = all_records()
    student_id = st.text_input("Student ID", value=current_id() or "CAI24001")
    record = records.get(student_id.strip().upper())
    if record is None:
        st.error("That ID is not in the cohort. Register first, or use CAI24001.")
        return
    st.write(f"{record['name']} · {record['course']} · {record['department']}")
    with st.form("assess"):
        cgpa = st.number_input("CGPA (0–10)", min_value=0.0, max_value=10.0, value=float(record["cgpa"] or 7), step=0.1)
        attendance = st.number_input("Attendance %", min_value=0, max_value=100, value=int(record["attendance"] or 80))
        backlogs = st.number_input("Backlogs", min_value=0, max_value=20, value=int(record["backlogs"]))
        internships = st.number_input("Internships", min_value=0, max_value=10, value=int(record["internships"]))
        certifications = st.number_input("Certifications", min_value=0, max_value=20, value=int(record["certifications"]))
        st.caption("Rate each skill from 1 to 10.")
        excel = st.slider("Excel", 1, 10, int(record["excel"]))
        sql = st.slider("SQL", 1, 10, int(record["sql"]))
        python = st.slider("Python", 1, 10, int(record["python"]))
        powerbi = st.slider("Power BI", 1, 10, int(record["powerbi"]))
        data_analysis = st.slider("Data Analysis", 1, 10, int(record["data_analysis"]))
        communication = st.slider("Communication", 1, 10, int(record["communication"]))
        interests = st.multiselect("Career interests", CAREERS, default=[item for item in record["interests"] if item in CAREERS] or ["Data Analyst"])
        first = st.selectbox("First choice", CAREERS, index=CAREERS.index(record["first_choice"]) if record["first_choice"] in CAREERS else 0)
        second = st.selectbox("Second choice", CAREERS, index=CAREERS.index(record["second_choice"]) if record["second_choice"] in CAREERS else 1)
        submitted = st.form_submit_button("Analyze my profile")
    if not submitted:
        return
    if not (0 <= cgpa <= 10) or not (0 <= attendance <= 100):
        st.error("Check CGPA and attendance.")
        return
    if first == second:
        st.error("First and second choices must be different.")
        return
    if 0 < cgpa <= 4:
        st.error("CGPA is on a 10-point scale. Convert a 4-point CGPA before saving.")
        return
    updated = dict(record)
    updated.update(
        {
            "cgpa": float(cgpa),
            "attendance": int(attendance),
            "backlogs": int(backlogs),
            "internships": int(internships),
            "certifications": int(certifications),
            "excel": int(excel),
            "sql": int(sql),
            "python": int(python),
            "powerbi": int(powerbi),
            "data_analysis": int(data_analysis),
            "communication": int(communication),
            "interests": list(dict.fromkeys([*interests, first, second])),
            "first_choice": first,
            "second_choice": second,
            "assessed": True,
        }
    )
    saved = _load_overrides()
    saved[updated["student_id"]] = updated
    _save_overrides(saved)
    st.session_state["student_id"] = updated["student_id"]
    st.session_state["last_result"] = analyze_student(updated)
    st.success("Profile analysed. Open Recommendations.")


def _active_result():
    records = all_records()
    student_id = current_id()
    if not student_id or student_id not in records:
        return None, None
    record = records[student_id]
    if record.get("assessed") is False or not record.get("cgpa"):
        return record, None
    return record, analyze_student(record)


def screen_recommendations() -> None:
    st.title("Recommendations")
    record, result = _active_result()
    if result is None:
        st.warning("Select a profile on the home page or finish an assessment.")
        return
    st.subheader(f"{record['name']} — {result['readiness']} / 100")
    st.write(result["band"])
    st.caption(result["note"])
    st.write("Best match:", f"{result['top3'][0]['career']} — {result['top3'][0]['percent']}%")
    st.bar_chart({item["career"]: item["percent"] for item in result["matches"]})
    left, right = st.columns(2)
    left.write("Strengths")
    left.write(result["strengths"] or "None at 7 or above yet.")
    right.write("Skill gaps")
    right.write(result["gaps"] or "No rated skill is below 6.")
    st.write("Skills to learn:", ", ".join(result["recommended_skills"]))
    st.write("Projects")
    for project in result["projects"]:
        st.write("-", project)
    st.write("30-day roadmap")
    for week in result["roadmap"]:
        st.markdown(f"**{week['week']}: {week['focus']}**")
        for task in week["tasks"]:
            st.write("-", task)
    with st.expander("How the score was calculated"):
        st.dataframe(pd.DataFrame(result["breakdown"]))


def screen_dashboard() -> None:
    st.title("My dashboard")
    record, result = _active_result()
    if result is None:
        st.warning("No analysed profile is selected.")
        return
    c1, c2, c3 = st.columns(3)
    c1.metric("Career readiness", result["readiness"])
    c2.metric("Band", result["band"])
    c3.metric("Top match", f"{result['top3'][0]['percent']}%")
    st.write(result["top3"][0]["career"])
    st.bar_chart(
        {
            "Excel": record["excel"],
            "SQL": record["sql"],
            "Python": record["python"],
            "Power BI": record["powerbi"],
            "Data Analysis": record["data_analysis"],
            "Communication": record["communication"],
        }
    )
    st.write("Roadmap")
    st.table(pd.DataFrame([{"Week": week["week"], "Focus": week["focus"]} for week in result["roadmap"]]))


def screen_admin() -> None:
    st.title("Teacher analytics")
    frame = load_cohort()
    from analytics import analyze_frame, cohort_summary

    analysed = analyze_frame(frame)
    summary = cohort_summary(analysed)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Students", summary["students"])
    c2.metric("Average CGPA", summary["average_cgpa"])
    c3.metric("Average attendance", summary["average_attendance"])
    c4.metric("Placement %", summary["placement_percentage"])
    st.write("Most preferred career:", summary["most_preferred_career"])
    st.write("Most common skill gap:", summary["most_common_skill_gap"])
    st.write("Average readiness:", summary["average_readiness"])
    st.bar_chart(summary["average_skills"])
    st.bar_chart(analysed["First_Choice"].value_counts())
    st.caption("Power BI steps are in powerbi/dashboard_documentation.md. Use CareerAI_Analytical.csv.")


def screen_chat() -> None:
    st.title("AI Career Coach")
    record, result = _active_result()
    if result is None:
        st.warning("Choose an analysed profile first. The coach should not invent marks.")
        context = ""
    else:
        context = (
            f"{record['name']} ({record['student_id']}), CGPA {record['cgpa']}, "
            f"attendance {record['attendance']}, readiness {result['readiness']} ({result['band']}). "
            + ", ".join(f"{item['career']} {item['percent']}%" for item in result["matches"])
        )
        st.caption(context)
    if "chat" not in st.session_state:
        st.session_state["chat"] = []
    for message in st.session_state["chat"]:
        st.chat_message(message["role"]).write(message["content"])
    question = st.chat_input("Ask about careers, skills, projects, or internships")
    if not question:
        return
    if not question.strip():
        st.error("Type a question before sending.")
        return
    from chatbot import ask_coach

    answer = ask_coach(question, context, st.session_state["chat"])
    st.session_state["chat"].append({"role": "user", "content": question})
    st.session_state["chat"].append({"role": "assistant", "content": answer})
    st.rerun()
