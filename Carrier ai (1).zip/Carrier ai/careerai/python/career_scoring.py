"""Project-defined Career Readiness score and career-match weights.

This is a classroom model for the CareerAI project. It is not a
scientifically validated prediction of employability or placement.
"""

from __future__ import annotations

import math
from typing import Any

CAREERS = [
    "Data Analyst",
    "Business Analyst",
    "HR Analyst",
    "Marketing Analyst",
    "Financial Analyst",
    "Supply Chain Analyst",
    "Marketing Manager",
    "HR Manager",
    "Accountant",
    "Operations Manager",
    "Sales Executive",
    "Banking Associate",
    "Management Consultant",
    "Digital Marketing Specialist",
    "Entrepreneur",
    "Software Developer",
]

# Skill-fit weights. Each career's weights sum to 1.00.
# "analytical" is not a separate form field. It is derived (see analytical_ability).
# "cgpa" uses the 0–10 CGPA scale.
WEIGHTS: dict[str, dict[str, float]] = {
    "Data Analyst": {
        "excel": 0.15,
        "sql": 0.25,
        "python": 0.22,
        "powerbi": 0.18,
        "data_analysis": 0.20,
        "communication": 0.0,
        "analytical": 0.0,
        "cgpa": 0.0,
    },
    "Business Analyst": {
        "excel": 0.22,
        "sql": 0.18,
        "python": 0.0,
        "powerbi": 0.05,
        "data_analysis": 0.22,
        "communication": 0.23,
        "analytical": 0.10,
        "cgpa": 0.0,
    },
    "HR Analyst": {
        "excel": 0.22,
        "sql": 0.05,
        "python": 0.0,
        "powerbi": 0.08,
        "data_analysis": 0.10,
        "communication": 0.35,
        "analytical": 0.20,
        "cgpa": 0.0,
    },
    "Marketing Analyst": {
        "excel": 0.20,
        "sql": 0.05,
        "python": 0.0,
        "powerbi": 0.12,
        "data_analysis": 0.23,
        "communication": 0.30,
        "analytical": 0.10,
        "cgpa": 0.0,
    },
    "Financial Analyst": {
        "excel": 0.30,
        "sql": 0.08,
        "python": 0.05,
        "powerbi": 0.10,
        "data_analysis": 0.12,
        "communication": 0.08,
        "analytical": 0.12,
        "cgpa": 0.15,
    },
    "Entrepreneur": {
        "excel": 0.10,
        "sql": 0.05,
        "python": 0.05,
        "powerbi": 0.08,
        "data_analysis": 0.15,
        "communication": 0.32,
        "analytical": 0.15,
        "cgpa": 0.10,
    },
    "Supply Chain Analyst": {
        "excel": 0.25,
        "sql": 0.12,
        "python": 0.05,
        "powerbi": 0.10,
        "data_analysis": 0.22,
        "communication": 0.12,
        "analytical": 0.14,
        "cgpa": 0.0,
    },
    "Marketing Manager": {
        "excel": 0.12,
        "sql": 0.0,
        "python": 0.0,
        "powerbi": 0.10,
        "data_analysis": 0.15,
        "communication": 0.38,
        "analytical": 0.15,
        "cgpa": 0.10,
    },
    "HR Manager": {
        "excel": 0.18,
        "sql": 0.0,
        "python": 0.0,
        "powerbi": 0.05,
        "data_analysis": 0.08,
        "communication": 0.40,
        "analytical": 0.14,
        "cgpa": 0.15,
    },
    "Accountant": {
        "excel": 0.34,
        "sql": 0.05,
        "python": 0.0,
        "powerbi": 0.08,
        "data_analysis": 0.18,
        "communication": 0.08,
        "analytical": 0.12,
        "cgpa": 0.15,
    },
    "Operations Manager": {
        "excel": 0.22,
        "sql": 0.08,
        "python": 0.0,
        "powerbi": 0.08,
        "data_analysis": 0.20,
        "communication": 0.22,
        "analytical": 0.12,
        "cgpa": 0.08,
    },
    "Sales Executive": {
        "excel": 0.12,
        "sql": 0.0,
        "python": 0.0,
        "powerbi": 0.08,
        "data_analysis": 0.10,
        "communication": 0.42,
        "analytical": 0.13,
        "cgpa": 0.15,
    },
    "Banking Associate": {
        "excel": 0.28,
        "sql": 0.05,
        "python": 0.0,
        "powerbi": 0.07,
        "data_analysis": 0.16,
        "communication": 0.18,
        "analytical": 0.11,
        "cgpa": 0.15,
    },
    "Management Consultant": {
        "excel": 0.15,
        "sql": 0.08,
        "python": 0.05,
        "powerbi": 0.10,
        "data_analysis": 0.18,
        "communication": 0.22,
        "analytical": 0.12,
        "cgpa": 0.10,
    },
    "Digital Marketing Specialist": {
        "excel": 0.12,
        "sql": 0.0,
        "python": 0.05,
        "powerbi": 0.18,
        "data_analysis": 0.15,
        "communication": 0.35,
        "analytical": 0.10,
        "cgpa": 0.05,
    },
    "Software Developer": {
        "excel": 0.05,
        "sql": 0.28,
        "python": 0.40,
        "powerbi": 0.05,
        "data_analysis": 0.12,
        "communication": 0.05,
        "analytical": 0.05,
        "cgpa": 0.0,
    },
}

SKILL_FIELDS = [
    ("excel", "Excel"),
    ("sql", "SQL"),
    ("python", "Python"),
    ("powerbi", "Power BI"),
    ("communication", "Communication"),
    ("data_analysis", "Data Analysis"),
]

# Gap rule used everywhere in the project: a rated skill below 6/10 is a gap.
# A rated skill of 7/10 or more is treated as a strength.
GAP_BELOW = 6
STRENGTH_FROM = 7


def round_half_up(value: float) -> int:
    """Nearest integer. .5 rounds away from zero (up, for these positive scores)."""
    return int(math.floor(float(value) + 0.5))


def round_places(value: float, places: int) -> float:
    """Round half up to a fixed number of decimal places (not banker's rounding)."""
    factor = 10 ** places
    return math.floor(float(value) * factor + 0.5) / factor


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def internship_points(internships: int) -> float:
    """Points out of 10. None = 0, one internship = 6, two or more = 10."""
    count = int(internships)
    if count <= 0:
        return 0.0
    if count == 1:
        return 6.0
    return 10.0


def certification_points(certifications: int) -> float:
    """Points out of 10. 0 = 0, 1 = 4, 2 = 7, 3 or more = 10."""
    count = int(certifications)
    if count <= 0:
        return 0.0
    if count == 1:
        return 4.0
    if count == 2:
        return 7.0
    return 10.0


def analytical_ability(data_analysis: float, cgpa: float) -> float:
    """Derived 1–10 score: 70% data-analysis skill + 30% CGPA on a 10-point scale."""
    cgpa_10 = clamp(float(cgpa), 0, 10)
    return round_places(0.7 * float(data_analysis) + 0.3 * cgpa_10, 2)


def readiness_parts(record: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the six weighted parts and the exact total before rounding.

    Weights required by the project brief:
    CGPA 25%, technical skills 30%, communication 15%,
    attendance 10%, internship 10%, certifications 10%.
    """
    cgpa = clamp(float(record["cgpa"]), 0, 10)
    attendance = clamp(float(record["attendance"]), 0, 100)
    tech_scores = [
        float(record["excel"]),
        float(record["sql"]),
        float(record["python"]),
        float(record["powerbi"]),
        float(record["data_analysis"]),
    ]
    tech_avg = sum(tech_scores) / 5.0
    communication = clamp(float(record["communication"]), 0, 10)
    parts = [
        {
            "key": "cgpa",
            "label": "CGPA",
            "weight": "25%",
            "detail": f"{cgpa:.1f} / 10",
            "points": round_places(cgpa / 10 * 25, 2),
            "max": 25,
        },
        {
            "key": "technical",
            "label": "Technical skills",
            "weight": "30%",
            "detail": f"Average {tech_avg:.1f} / 10 across Excel, SQL, Python, Power BI, Data Analysis",
            "points": round_places(tech_avg / 10 * 30, 2),
            "max": 30,
        },
        {
            "key": "communication",
            "label": "Communication",
            "weight": "15%",
            "detail": f"{communication:.0f} / 10",
            "points": round_places(communication / 10 * 15, 2),
            "max": 15,
        },
        {
            "key": "attendance",
            "label": "Attendance",
            "weight": "10%",
            "detail": f"{attendance:.0f}%",
            "points": round_places(attendance / 100 * 10, 2),
            "max": 10,
        },
        {
            "key": "internship",
            "label": "Internship",
            "weight": "10%",
            "detail": f"{int(record['internships'])} internship(s) — 0→0, 1→6, 2+→10",
            "points": internship_points(int(record["internships"])),
            "max": 10,
        },
        {
            "key": "certifications",
            "label": "Certifications",
            "weight": "10%",
            "detail": f"{int(record['certifications'])} certificate(s) — 0→0, 1→4, 2→7, 3+→10",
            "points": certification_points(int(record["certifications"])),
            "max": 10,
        },
    ]
    return parts


def readiness_total(parts: list[dict[str, Any]]) -> float:
    return round_places(sum(float(part["points"]) for part in parts), 2)


def readiness_band(score: int) -> str:
    if score >= 80:
        return "Highly Ready"
    if score >= 60:
        return "Moderately Ready"
    return "Needs Improvement"


def _to_100(score_out_of_10: float) -> float:
    return clamp(float(score_out_of_10), 0, 10) / 10 * 100


def interest_fit(career: str, record: dict[str, Any]) -> float:
    """100 first choice, 80 second choice, 65 other selected interest, else 40."""
    if career == record.get("first_choice"):
        return 100.0
    if career == record.get("second_choice"):
        return 80.0
    interests = record.get("interests") or []
    if career in interests:
        return 65.0
    return 40.0


def skill_fit(career: str, record: dict[str, Any]) -> float:
    analytical = analytical_ability(float(record["data_analysis"]), float(record["cgpa"]))
    values = {
        "excel": _to_100(record["excel"]),
        "sql": _to_100(record["sql"]),
        "python": _to_100(record["python"]),
        "powerbi": _to_100(record["powerbi"]),
        "data_analysis": _to_100(record["data_analysis"]),
        "communication": _to_100(record["communication"]),
        "analytical": _to_100(analytical),
        "cgpa": clamp(float(record["cgpa"]), 0, 10) / 10 * 100,
    }
    weights = WEIGHTS[career]
    return sum(weights[key] * values[key] for key in weights)


def match_percent(career: str, record: dict[str, Any]) -> int:
    """78% skill fit + 22% stated interest, rounded, capped at 100."""
    raw = 0.78 * skill_fit(career, record) + 0.22 * interest_fit(career, record)
    return int(clamp(round_half_up(raw), 0, 100))


def normalize(raw: dict[str, Any]) -> dict[str, Any]:
    """Accept either internal names or the Excel / SQL column names."""

    def pick(*keys: str, default: Any = None) -> Any:
        for key in keys:
            if key in raw and raw[key] is not None and raw[key] != "":
                return raw[key]
        return default

    first = pick("first_choice", "First_Choice", default="Business Analyst")
    second = pick("second_choice", "Second_Choice", default="Data Analyst")
    interests = pick("interests", "Interests", default=None)
    if interests is None:
        interests = [first, second]
    elif isinstance(interests, str):
        interests = [part.strip() for part in interests.split(",") if part.strip()]

    package = pick("package_lpa", "Package", default=None)
    if package == "" or package is None or (isinstance(package, float) and math.isnan(package)):
        package_value = None
    else:
        package_value = float(package)

    status = pick("placement_status", "Placement_Status", default="In Progress")
    return {
        "student_id": str(pick("student_id", "Student_ID", default="")).strip(),
        "name": str(pick("name", "Name", default="")).strip(),
        "age": int(pick("age", "Age", default=0) or 0),
        "gender": str(pick("gender", "Gender", default="") or ""),
        "course": str(pick("course", "Course", default="") or ""),
        "year": int(pick("year", "Year", default=0) or 0),
        "semester": int(pick("semester", "Semester", default=0) or 0),
        "department": str(pick("department", "Department", default="") or ""),
        "email": str(pick("email", "Email", default="") or ""),
        "cgpa": float(pick("cgpa", "CGPA", default=0) or 0),
        "attendance": float(pick("attendance", "Attendance", default=0) or 0),
        "backlogs": int(pick("backlogs", "Backlogs", default=0) or 0),
        "internships": int(pick("internships", "Internship", default=0) or 0),
        "certifications": int(pick("certifications", "Certifications", default=0) or 0),
        "excel": float(pick("excel", "Excel_Score", default=0) or 0),
        "sql": float(pick("sql", "SQL_Score", default=0) or 0),
        "python": float(pick("python", "Python_Score", default=0) or 0),
        "powerbi": float(pick("powerbi", "PowerBI_Score", default=0) or 0),
        "communication": float(pick("communication", "Communication_Score", default=0) or 0),
        "data_analysis": float(pick("data_analysis", "Data_Analysis_Score", default=0) or 0),
        "interests": list(interests),
        "first_choice": str(first),
        "second_choice": str(second),
        "placement_status": str(status),
        "package_lpa": package_value,
    }
