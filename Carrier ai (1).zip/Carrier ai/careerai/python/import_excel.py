"""Load CareerAI_Student_Data.xlsx into MySQL.

Reads DB_HOST, DB_USER, DB_PASSWORD, and DB_NAME from the environment.
Copy .env.example to .env and fill those values before you run this file.

    python import_excel.py

The script replaces rows for the student IDs found in the workbook.
It does not delete students who are not in the file.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
EXCEL_PATH = ROOT / "data" / "CareerAI_Student_Data.xlsx"


def main() -> None:
    load_dotenv(ROOT / ".env")
    host = os.getenv("DB_HOST", "")
    user = os.getenv("DB_USER", "")
    password = os.getenv("DB_PASSWORD", "")
    database = os.getenv("DB_NAME", "careerai_db")
    if not host or not user:
        print("MySQL is not configured.")
        print("Set DB_HOST, DB_USER, DB_PASSWORD, and DB_NAME, then run this script again.")
        print(f"The Excel file is ready at: {EXCEL_PATH}")
        sys.exit(1)

    try:
        import mysql.connector
    except ImportError:
        print("Install mysql-connector-python from requirements.txt first.")
        sys.exit(1)

    students = pd.read_excel(EXCEL_PATH, sheet_name="Students")
    academic = pd.read_excel(EXCEL_PATH, sheet_name="Academic_Data")
    skills = pd.read_excel(EXCEL_PATH, sheet_name="Skills")
    interest = pd.read_excel(EXCEL_PATH, sheet_name="Career_Interest")
    placement = pd.read_excel(EXCEL_PATH, sheet_name="Placement")

    connection = mysql.connector.connect(
        host=host,
        user=user,
        password=password,
        database=database,
    )
    cursor = connection.cursor()
    ids = [str(value) for value in students["Student_ID"].tolist()]
    marks = ", ".join(["%s"] * len(ids))
    for table in ("Placement", "Career_Interest", "Skills", "Academic", "Students"):
        cursor.execute(f"DELETE FROM {table} WHERE Student_ID IN ({marks})", ids)

    for row in students.itertuples(index=False):
        cursor.execute(
            """
            INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            tuple(row),
        )
    for row in academic.itertuples(index=False):
        cursor.execute(
            """
            INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            tuple(row),
        )
    for row in skills.itertuples(index=False):
        cursor.execute(
            """
            INSERT INTO Skills
              (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            tuple(row),
        )
    for row in interest.itertuples(index=False):
        cursor.execute(
            "INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES (%s, %s, %s)",
            tuple(row),
        )
    for row in placement.itertuples(index=False):
        package = None if pd.isna(row.Package) else float(row.Package)
        cursor.execute(
            "INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES (%s, %s, %s)",
            (row.Student_ID, row.Placement_Status, package),
        )

    connection.commit()
    cursor.close()
    connection.close()
    print(f"Imported {len(ids)} students into {database}.")


if __name__ == "__main__":
    main()
