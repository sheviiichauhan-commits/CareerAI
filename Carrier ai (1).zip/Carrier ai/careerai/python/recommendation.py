"""Rule-based career recommendation, skill gaps, projects, and roadmap.

The match score is intentionally simple so it can be explained in a viva:

    skill fit   = weighted average of the skills that matter for that career
    interest fit = 100 / 80 / 65 / 40 from the student's stated choices
    match %     = round(0.78 * skill fit + 0.22 * interest fit)

Top 3 careers are the highest match percentages.
"""

from __future__ import annotations

from typing import Any

from career_scoring import (
    CAREERS,
    GAP_BELOW,
    SKILL_FIELDS,
    STRENGTH_FROM,
    WEIGHTS,
    analytical_ability,
    interest_fit,
    match_percent,
    readiness_band,
    readiness_parts,
    readiness_total,
    round_half_up,
    round_places,
    skill_fit,
)

# Imported names used by generate_dataset and the Streamlit app.
__all__ = ["analyze_student", "PROJECTS"]

RELATED = {
    "Data Analyst": ["Statistics", "Data storytelling"],
    "Business Analyst": ["Requirements writing", "Process mapping"],
    "HR Analyst": ["People analytics basics", "Survey design"],
    "Marketing Analyst": ["Campaign measurement", "Customer segmentation"],
    "Financial Analyst": ["Financial statements", "Forecasting"],
    "Entrepreneur": ["Customer discovery", "Unit economics"],
    "Supply Chain Analyst": ["Inventory basics", "Demand planning"],
    "Marketing Manager": ["Brand positioning", "Team briefing"],
    "HR Manager": ["Interview design", "Labour law basics"],
    "Accountant": ["Bookkeeping basics", "GST overview"],
    "Operations Manager": ["Process mapping", "Inventory basics"],
    "Sales Executive": ["Sales conversation", "Pipeline tracking"],
    "Banking Associate": ["Bank products", "KYC basics"],
    "Management Consultant": ["Case structure", "Stakeholder briefing"],
    "Digital Marketing Specialist": ["Content calendar", "Campaign measurement"],
    "Software Developer": ["Programming practice", "SQL"],
}

PROJECTS = {
    "Data Analyst": [
        "Sales Dashboard",
        "Student Performance Analysis",
        "Customer Segmentation",
        "Marketing Analytics",
    ],
    "Business Analyst": [
        "Process Improvement Case",
        "Requirements Dashboard",
        "Market Sizing Model",
        "Stakeholder Status Report",
    ],
    "HR Analyst": [
        "Attrition Dashboard",
        "Hiring Funnel Analysis",
        "Employee Survey Insights",
        "Compensation Benchmark",
    ],
    "Marketing Analyst": [
        "Campaign Performance Dashboard",
        "Customer Segmentation Study",
        "Social Media KPI Tracker",
        "A/B Test Summary",
    ],
    "Financial Analyst": [
        "Budget versus Actual Dashboard",
        "Ratio Analysis Workbook",
        "Cash Flow Forecast",
        "Expense Variance Report",
    ],
    "Entrepreneur": [
        "Lean Canvas with Market Sizing",
        "Customer Discovery Notes",
        "Unit Economics Model",
        "Pitch Metrics Dashboard",
    ],
    "Supply Chain Analyst": [
        "Inventory Turnover Workbook",
        "Supplier Lead-Time Dashboard",
        "Demand Forecast for a Campus Store",
        "Stock-out Case Note",
    ],
    "Marketing Manager": [
        "Fest Campaign Plan",
        "Brand Message Test",
        "Channel Mix Budget",
        "Monthly Marketing Review",
    ],
    "HR Manager": [
        "Campus Hiring Plan",
        "Interview Scorecard",
        "Onboarding Checklist",
        "Attendance Policy Brief",
    ],
    "Accountant": [
        "Three-Statement Mini Workbook",
        "Expense Classification Sheet",
        "GST Calculation Example",
        "Bank Reconciliation Practice",
    ],
    "Operations Manager": [
        "Canteen Process Map",
        "Turnaround-Time Tracker",
        "Capacity Planning Sheet",
        "Service Delay Report",
    ],
    "Sales Executive": [
        "Prospect List and Script",
        "Simple Sales Pipeline",
        "Objection Handling Notes",
        "Weekly Sales Review",
    ],
    "Banking Associate": [
        "Product Comparison Sheet",
        "KYC Checklist Walkthrough",
        "Savings versus FD Example",
        "Customer Query Log",
    ],
    "Management Consultant": [
        "One-Page Problem Statement",
        "Issue Tree for a Campus Service",
        "Recommendation Memo",
        "Before-and-After Metrics",
    ],
    "Digital Marketing Specialist": [
        "Content Calendar",
        "Landing-Page KPI Sheet",
        "Social Post Test",
        "Campaign Report",
    ],
    "Software Developer": [
        "Student Lookup Script",
        "Small CRUD Practice App",
        "SQL Query Notebook",
        "Bug-Fix Log",
    ],
}

WEEK_TASKS = {
    "Excel": [
        "Clean one small table: remove blanks and fix number formats.",
        "Practice SUMIF, AVERAGEIF, and one PivotTable.",
        "Write two sentences explaining what the PivotTable shows.",
    ],
    "SQL": [
        "Write SELECT, WHERE, and ORDER BY on the Students table.",
        "JOIN Students with Academic on Student_ID.",
        "Add one GROUP BY to find an average by department.",
    ],
    "Python": [
        "Load the Excel file with Pandas.",
        "Calculate average CGPA and average attendance.",
        "Check data types and fix one column if needed.",
    ],
    "Power BI": [
        "Import the analytical CSV.",
        "Build one KPI card and one bar chart.",
        "Add a slicer for Department.",
    ],
    "Data Analysis": [
        "Write one question the dataset can answer.",
        "Compare two departments on CGPA and attendance.",
        "List three findings and one limitation.",
    ],
    "Communication": [
        "Explain your top career match in 60 seconds.",
        "Rewrite that explanation without jargon.",
        "Ask a classmate to repeat it back to you.",
    ],
    "Statistics": [
        "Revise mean, median, and percentage.",
        "Read one chart from the dashboard out loud.",
        "State one reason a score is not a prediction.",
    ],
    "Data storytelling": [
        "Turn one number into a sentence a non-technical person understands.",
        "Give a chart a title that states the finding.",
        "End with one recommended action.",
    ],
    "Requirements writing": [
        "Write the question a manager is trying to answer.",
        "List the fields you would need.",
        "Note who would use the result.",
    ],
    "Process mapping": [
        "Sketch five steps of a campus process you know.",
        "Mark where data is collected.",
        "Suggest one delay that data could reveal.",
    ],
    "People analytics basics": [
        "Define attrition in one sentence.",
        "List three HR metrics that use a percentage.",
        "Explain why a small sample can mislead.",
    ],
    "Survey design": [
        "Write five clear questions for a student survey.",
        "Remove any leading wording.",
        "Decide how you would score the answers.",
    ],
    "Campaign measurement": [
        "Pick a fictional college-fest campaign.",
        "Choose reach, clicks, and sign-ups as metrics.",
        "Say which metric matters most and why.",
    ],
    "Customer segmentation": [
        "Split a fictional customer list into three groups.",
        "Name each group by behaviour, not only age.",
        "Suggest one offer for each group.",
    ],
    "Financial statements": [
        "Name the income statement, balance sheet, and cash flow statement.",
        "Explain revenue versus profit in one line.",
        "Calculate one simple expense ratio.",
    ],
    "Forecasting": [
        "Take six fictional monthly sales numbers.",
        "Find the average and a simple next-month estimate.",
        "Write one reason the estimate could be wrong.",
    ],
    "Customer discovery": [
        "Write five questions you would ask a possible customer.",
        "Do not pitch inside those questions.",
        "Summarise what you would listen for.",
    ],
    "Unit economics": [
        "Define price, cost, and margin with a campus example.",
        "Calculate margin for one fictional product.",
        "Say what happens if the cost rises.",
    ],
    "Inventory basics": [
        "Define stock, lead time, and stock-out in one line each.",
        "Track five fictional items and their quantities.",
        "Flag one item that should be reordered.",
    ],
    "Demand planning": [
        "List three things that change demand for a campus store.",
        "Compare last month and this month for one product.",
        "Write one cautious forecast, with a reason it could be wrong.",
    ],
    "Brand positioning": [
        "Name the audience, the offer, and the difference in one sentence.",
        "Write two taglines and pick one.",
        "Say where that audience already spends time.",
    ],
    "Team briefing": [
        "Write a five-line brief: goal, audience, deadline, owner, measure.",
        "Remove jargon from the brief.",
        "Add one decision the team still needs.",
    ],
    "Interview design": [
        "Write five job-related questions, not trick questions.",
        "Add a simple 1–5 score for each answer.",
        "Note one question that checks communication.",
    ],
    "Labour law basics": [
        "List three workplace rules a new joiner should know.",
        "Explain attendance and leave in plain language.",
        "State that this is study material, not legal advice.",
    ],
    "Bookkeeping basics": [
        "Record five fictional receipts as debit and credit.",
        "Separate expense from asset with one example.",
        "Total the expenses and check the sum.",
    ],
    "GST overview": [
        "Explain GST as a tax on a sale, in one sentence.",
        "Calculate tax on a ₹1,000 bill at 18%.",
        "Say who the tax is collected for.",
    ],
    "Sales conversation": [
        "Write a 30-second opening that asks a question, not a pitch.",
        "List three objections and a calm reply for each.",
        "End with one next step and a date.",
    ],
    "Pipeline tracking": [
        "Make columns: name, need, stage, next step, date.",
        "Add five fictional prospects.",
        "Mark which one needs a follow-up this week.",
    ],
    "Bank products": [
        "Compare a savings account, an FD, and a personal loan in a table.",
        "Write who each product is for.",
        "Note one risk the customer should hear.",
    ],
    "KYC basics": [
        "List the documents a bank typically asks for.",
        "Explain why identity checks exist, in two sentences.",
        "Write one polite way to request a missing document.",
    ],
    "Case structure": [
        "State the problem in one sentence.",
        "Split it into three branches.",
        "End with one recommendation and one risk.",
    ],
    "Stakeholder briefing": [
        "Name who decides, who uses the work, and who is affected.",
        "Write what each person needs to hear.",
        "Keep the brief under 150 words.",
    ],
    "Content calendar": [
        "Plan four posts for one fictional college event.",
        "Give each post a goal: reach, click, or sign-up.",
        "Note the day and the channel.",
    ],
    "Programming practice": [
        "Write a short Python script that reads a list of marks.",
        "Print the average and the count of scores below 6.",
        "Add one comment that explains the calculation.",
    ],
    "Review and explain your strongest skill": [
        "Pick the skill you rated 7 or above.",
        "Explain it in five sentences without slides.",
        "Write one example you could put on a resume.",
    ],
}


def _tasks_for(topic: str) -> list[str]:
    if topic in WEEK_TASKS:
        return WEEK_TASKS[topic]
    return [
        f"Spend three short sessions learning the basics of {topic}.",
        "Write five bullet notes in your own words.",
        "Connect the topic to your top career match in one paragraph.",
    ]


def build_roadmap(career: str, gap_names: list[str]) -> list[dict[str, Any]]:
    """Four weeks. Weeks 1–3 follow the student's weakest relevant skills."""
    weights = WEIGHTS[career]
    label_to_key = {label: key for key, label in SKILL_FIELDS}
    ranked_gaps = sorted(
        gap_names,
        key=lambda label: weights.get(label_to_key.get(label, ""), 0),
        reverse=True,
    )
    extras = [topic for topic in RELATED[career] if topic not in ranked_gaps]
    focus: list[str] = []
    for name in ranked_gaps + extras:
        if name not in focus:
            focus.append(name)
        if len(focus) == 3:
            break
    while len(focus) < 3:
        added = False
        for topic in RELATED[career] + ["Review and explain your strongest skill"]:
            if topic not in focus:
                focus.append(topic)
                added = True
                break
        if not added:
            break

    project = PROJECTS[career][0]
    weeks = []
    for index, topic in enumerate(focus, start=1):
        weeks.append(
            {
                "week": f"Week {index}",
                "focus": topic,
                "tasks": _tasks_for(topic),
            }
        )
    weeks.append(
        {
            "week": "Week 4",
            "focus": f"Build: {project}",
            "tasks": [
                f"Start the project “{project}” with the sample data or a small public dataset.",
                "Show one chart, three findings, and one limitation.",
                "Add the project to your resume in four lines: tool, data, action, result.",
            ],
        }
    )
    return weeks


def analyze_student(record: dict[str, Any]) -> dict[str, Any]:
    parts = readiness_parts(record)
    exact = readiness_total(parts)
    score = round_half_up(exact)
    band = readiness_band(score)

    matches = []
    for career in CAREERS:
        percent = match_percent(career, record)
        matches.append(
            {
                "career": career,
                "percent": percent,
                "skill_fit": round_places(skill_fit(career, record), 1),
                "interest_fit": interest_fit(career, record),
            }
        )
    matches.sort(key=lambda item: (-item["percent"], item["career"]))

    rated = []
    for key, label in SKILL_FIELDS:
        value = int(round(float(record[key])))
        rated.append({"key": key, "skill": label, "score": value})

    strengths = [item for item in rated if item["score"] >= STRENGTH_FROM]
    gaps = [item for item in rated if item["score"] < GAP_BELOW]
    strengths.sort(key=lambda item: -item["score"])
    gaps.sort(key=lambda item: item["score"])

    top = matches[0]
    weights = WEIGHTS[top["career"]]
    label_to_key = {label: key for key, label in SKILL_FIELDS}
    recommended = sorted(
        [item["skill"] for item in gaps],
        key=lambda label: weights.get(label_to_key.get(label, ""), 0),
        reverse=True,
    )
    for topic in RELATED[top["career"]]:
        if topic not in recommended:
            recommended.append(topic)

    primary_gap = gaps[0]["skill"] if gaps else "None — no rated skill is below 6"

    return {
        "readiness_exact": exact,
        "readiness": score,
        "band": band,
        "breakdown": parts,
        "analytical_ability": analytical_ability(record["data_analysis"], record["cgpa"]),
        "matches": matches,
        "top3": matches[:3],
        "strengths": strengths,
        "gaps": gaps,
        "recommended_skills": recommended,
        "projects": PROJECTS[top["career"]],
        "roadmap": build_roadmap(top["career"], [item["skill"] for item in gaps]),
        "primary_gap": primary_gap,
        "note": (
            "Project-defined analytical score for learning and guidance. "
            "Not a placement prediction and not a decision about the student."
        ),
    }
