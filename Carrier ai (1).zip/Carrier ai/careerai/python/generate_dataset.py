"""Create the fictional CareerAI cohort and the files the rest of the project uses.

Outputs
- data/CareerAI_Student_Data.xlsx          (5 sheets, 320 students)
- powerbi/CareerAI_Analytical.csv          (flat file for Power BI)
- database/seed_demo_20.sql                (first 20 students)
- ../../src/lib/career/dataset.ts          (same people, for the web app)
- ../../public/downloads/ copies of the Excel, CSV, and SQL files

All people, marks, and packages are invented. Do not replace them with real student data.
"""

from __future__ import annotations

import csv
import random
import sys
from pathlib import Path

from openpyxl import Workbook

sys.path.insert(0, str(Path(__file__).resolve().parent))

from analytics import analyze_frame, cohort_summary  # noqa: E402
from career_scoring import CAREERS as CAREER_LIST, normalize  # noqa: E402
from recommendation import analyze_student  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
COUNT = 320
RNG = random.Random(20241007)

FIRST_F = [
    "Aanya", "Meera", "Ishita", "Kavya", "Saanvi", "Diya", "Anika", "Myra",
    "Aditi", "Nisha", "Tanvi", "Ira", "Kiara", "Ananya", "Zoya", "Lavanya",
    "Shruti", "Pari", "Navya", "Aisha",
]
FIRST_M = [
    "Arjun", "Rohan", "Kabir", "Vivaan", "Aditya", "Karthik", "Dev", "Ayaan",
    "Ishaan", "Neil", "Aman", "Harsh", "Kunal", "Yash", "Nikhil", "Varun",
    "Siddharth", "Om", "Reyansh", "Vihaan",
]
FIRST_O = ["Samar", "Tej", "Noor", "Arya", "Shan"]
LAST = [
    "Deshmukh", "Iyer", "Kapoor", "Menon", "Bose", "Chopra", "Nair", "Reddy",
    "Joshi", "Malhotra", "Banerjee", "Kulkarni", "Gill", "Sethi", "Rao",
    "Mehta", "Saxena", "Pillai", "Das", "Khanna", "Bhatt", "Chowdhury",
]

COURSES = {
    "BBA": ["Marketing", "Finance", "Human Resources", "Operations"],
    "B.Com": ["Finance", "Accounting", "General Management"],
    "BCA": ["Information Technology", "Data Analytics"],
}

BIAS = {
    "Data Analytics": (7.2, 8.0, 7.8, 7.4, 6.0, 7.8),
    "Information Technology": (6.4, 7.4, 7.6, 6.4, 5.6, 6.8),
    "Marketing": (6.4, 4.4, 3.6, 5.6, 8.0, 6.2),
    "Finance": (8.0, 5.4, 4.0, 6.0, 6.0, 6.6),
    "Accounting": (8.0, 5.0, 3.6, 5.4, 5.6, 6.0),
    "Human Resources": (6.0, 4.0, 3.2, 4.6, 8.0, 5.4),
    "Operations": (6.6, 5.0, 4.0, 5.6, 6.4, 6.0),
    "General Management": (6.4, 4.8, 3.8, 5.0, 7.0, 5.8),
}

DEPT_CAREERS = {
    "Data Analytics": ["Data Analyst", "Business Analyst", "Supply Chain Analyst"],
    "Information Technology": ["Software Developer", "Data Analyst", "Business Analyst"],
    "Marketing": ["Marketing Manager", "Digital Marketing Specialist", "Sales Executive"],
    "Finance": ["Financial Analyst", "Banking Associate", "Accountant"],
    "Accounting": ["Accountant", "Financial Analyst", "Banking Associate"],
    "Human Resources": ["HR Manager", "HR Analyst", "Management Consultant"],
    "Operations": ["Operations Manager", "Supply Chain Analyst", "Business Analyst"],
    "General Management": ["Management Consultant", "Entrepreneur", "Operations Manager"],
}


def skill(rng: random.Random, mean: float) -> int:
    value = int(round(mean + rng.uniform(-2.1, 2.1)))
    return max(1, min(10, value))


def featured() -> list[dict]:
    """Eight classroom profiles. The rest of the file is generated around them."""
    rows = [
        # Highly ready data profile — used on the home page.
        dict(name="Aanya Deshmukh", age=21, gender="Female", course="BCA", year=3, semester=6,
             department="Data Analytics", email="aanya.deshmukh@demo.careerai.edu",
             cgpa=8.8, attendance=94, backlogs=0, internships=2, certifications=3,
             excel=9, sql=9, python=8, powerbi=8, communication=8, data_analysis=8,
             interests=["Data Analyst", "Business Analyst"],
             first_choice="Data Analyst", second_choice="Business Analyst",
             placement_status="Placed", package_lpa=8.4),
        dict(name="Kabir Menon", age=21, gender="Male", course="BBA", year=3, semester=5,
             department="Marketing", email="kabir.menon@demo.careerai.edu",
             cgpa=8.1, attendance=88, backlogs=0, internships=1, certifications=1,
             excel=8, sql=7, python=4, powerbi=6, communication=9, data_analysis=8,
             interests=["Business Analyst", "Marketing Analyst"],
             first_choice="Business Analyst", second_choice="Marketing Analyst",
             placement_status="Placed", package_lpa=6.5),
        dict(name="Meera Iyer", age=20, gender="Female", course="BBA", year=2, semester=4,
             department="Human Resources", email="meera.iyer@demo.careerai.edu",
             cgpa=7.8, attendance=91, backlogs=0, internships=1, certifications=2,
             excel=7, sql=4, python=3, powerbi=5, communication=9, data_analysis=6,
             interests=["HR Analyst", "Business Analyst"],
             first_choice="HR Analyst", second_choice="Business Analyst",
             placement_status="Not Placed", package_lpa=None),
        dict(name="Riya Kapoor", age=21, gender="Female", course="BBA", year=3, semester=6,
             department="Marketing", email="riya.kapoor@demo.careerai.edu",
             cgpa=8.0, attendance=86, backlogs=0, internships=1, certifications=2,
             excel=7, sql=4, python=3, powerbi=6, communication=9, data_analysis=7,
             interests=["Marketing Analyst", "Entrepreneur"],
             first_choice="Marketing Analyst", second_choice="Entrepreneur",
             placement_status="Placed", package_lpa=5.8),
        dict(name="Arjun Reddy", age=22, gender="Male", course="B.Com", year=3, semester=6,
             department="Finance", email="arjun.reddy@demo.careerai.edu",
             cgpa=8.8, attendance=90, backlogs=0, internships=1, certifications=2,
             excel=9, sql=6, python=4, powerbi=6, communication=6, data_analysis=7,
             interests=["Financial Analyst", "Business Analyst"],
             first_choice="Financial Analyst", second_choice="Business Analyst",
             placement_status="Placed", package_lpa=7.6),
        # Clear "needs improvement" profile for the viva contrast.
        dict(name="Rohan Das", age=19, gender="Male", course="BCA", year=1, semester=2,
             department="Information Technology", email="rohan.das@demo.careerai.edu",
             cgpa=5.4, attendance=64, backlogs=3, internships=0, certifications=0,
             excel=4, sql=3, python=3, powerbi=3, communication=4, data_analysis=3,
             interests=["Data Analyst"],
             first_choice="Data Analyst", second_choice="Business Analyst",
             placement_status="Not Placed", package_lpa=None),
        dict(name="Anika Bose", age=20, gender="Female", course="BBA", year=2, semester=3,
             department="General Management", email="anika.bose@demo.careerai.edu",
             cgpa=7.4, attendance=82, backlogs=1, internships=0, certifications=1,
             excel=6, sql=5, python=4, powerbi=5, communication=8, data_analysis=6,
             interests=["Entrepreneur", "Marketing Analyst"],
             first_choice="Entrepreneur", second_choice="Marketing Analyst",
             placement_status="Higher Studies", package_lpa=None),
        dict(name="Vivaan Shah", age=21, gender="Male", course="BBA", year=3, semester=5,
             department="Operations", email="vivaan.shah@demo.careerai.edu",
             cgpa=7.2, attendance=79, backlogs=1, internships=1, certifications=1,
             excel=7, sql=6, python=5, powerbi=6, communication=7, data_analysis=6,
             interests=["Business Analyst", "Data Analyst"],
             first_choice="Business Analyst", second_choice="Data Analyst",
             placement_status="Placed", package_lpa=4.8),
    ]
    # Vivaan Shah uses a last name outside LAST so the random generator will not collide
    # if Shah is absent. Shah is absent from LAST. Good.
    for index, row in enumerate(rows, start=1):
        row["student_id"] = f"CAI24{index:03d}"
    return rows


def random_student(rng: random.Random, index: int, used: set[str]) -> dict:
    gender_roll = rng.random()
    if gender_roll < 0.48:
        gender = "Female"
        first = rng.choice(FIRST_F)
    elif gender_roll < 0.96:
        gender = "Male"
        first = rng.choice(FIRST_M)
    else:
        gender = "Other"
        first = rng.choice(FIRST_O + FIRST_F + FIRST_M)
    for _ in range(20):
        name = f"{first} {rng.choice(LAST)}"
        if name not in used:
            break
    else:
        name = f"{first} {rng.choice(LAST)} {index}"
    used.add(name)

    course = rng.choice(["BBA", "BBA", "B.Com", "BCA"])
    department = rng.choice(COURSES[course])
    year = rng.choice([1, 2, 3])
    semester = year * 2 - rng.choice([0, 1])
    means = BIAS[department]
    scores = [skill(rng, mean) for mean in means]
    excel, sql, python, powerbi, communication, data_analysis = scores
    avg = sum(scores) / 6
    cgpa = max(4.8, min(9.7, round(5.4 + avg / 10 * 3.4 + rng.uniform(-0.6, 0.5), 1)))
    attendance = int(max(58, min(99, round(62 + avg * 3.3 + rng.uniform(-6, 6)))))
    if cgpa >= 8:
        backlogs = rng.choice([0, 0, 0, 1])
    elif cgpa >= 6.5:
        backlogs = rng.choice([0, 0, 1, 1, 2])
    else:
        backlogs = rng.choice([1, 2, 2, 3, 4])
    internships = 2 if rng.random() < 0.12 else 1 if rng.random() < 0.42 else 0
    certifications = rng.choice([0, 0, 1, 1, 1, 2, 2, 3])
    pool = DEPT_CAREERS[department][:]
    if rng.random() < 0.35:
        pool.append(rng.choice(CAREER_LIST))
    first_choice = rng.choice(pool)
    second_pool = [career for career in CAREER_LIST if career != first_choice]
    second_choice = rng.choice(second_pool)
    interests = [first_choice, second_choice]
    if rng.random() < 0.4:
        extra = rng.choice([career for career in CAREER_LIST if career not in interests])
        interests.append(extra)

    strength = (cgpa / 10) * 0.5 + (avg / 10) * 0.3 + (attendance / 100) * 0.2
    roll = rng.random()
    if roll < 0.08:
        status = "Higher Studies"
        package = None
    elif roll < 0.08 + (0.28 + strength * 0.55):
        status = "Placed"
        package = round(max(3.0, min(16.0, 3.1 + (cgpa - 6) * 0.85 + (avg - 5) * 0.4 + rng.uniform(0, 1.1))), 1)
    else:
        status = "Not Placed"
        package = None

    slug = name.lower().replace(" ", ".")
    return dict(
        student_id=f"CAI24{index:03d}",
        name=name,
        age=rng.choice([18, 19, 19, 20, 20, 21, 21, 22]),
        gender=gender,
        course=course,
        year=year,
        semester=semester,
        department=department,
        email=f"{slug}@demo.careerai.edu",
        cgpa=cgpa,
        attendance=attendance,
        backlogs=backlogs,
        internships=internships,
        certifications=certifications,
        excel=excel,
        sql=sql,
        python=python,
        powerbi=powerbi,
        communication=communication,
        data_analysis=data_analysis,
        interests=interests,
        first_choice=first_choice,
        second_choice=second_choice,
        placement_status=status,
        package_lpa=package,
    )


def build_records() -> list[dict]:
    rows = featured()
    used = {row["name"] for row in rows}
    for index in range(len(rows) + 1, COUNT + 1):
        rows.append(random_student(RNG, index, used))
    return rows


def write_excel(records: list[dict], path: Path) -> None:
    book = Workbook()
    students = book.active
    students.title = "Students"
    students.append(["Student_ID", "Name", "Age", "Gender", "Course", "Year", "Semester", "Department"])
    academic = book.create_sheet("Academic_Data")
    academic.append(["Student_ID", "CGPA", "Attendance", "Backlogs", "Internship", "Certifications"])
    skills = book.create_sheet("Skills")
    skills.append(["Student_ID", "Excel_Score", "SQL_Score", "Python_Score", "PowerBI_Score", "Communication_Score", "Data_Analysis_Score"])
    interest = book.create_sheet("Career_Interest")
    interest.append(["Student_ID", "First_Choice", "Second_Choice"])
    placement = book.create_sheet("Placement")
    placement.append(["Student_ID", "Placement_Status", "Package"])

    for row in records:
        students.append([row["student_id"], row["name"], row["age"], row["gender"], row["course"], row["year"], row["semester"], row["department"]])
        academic.append([row["student_id"], row["cgpa"], row["attendance"], row["backlogs"], row["internships"], row["certifications"]])
        skills.append([row["student_id"], row["excel"], row["sql"], row["python"], row["powerbi"], row["communication"], row["data_analysis"]])
        interest.append([row["student_id"], row["first_choice"], row["second_choice"]])
        placement.append([row["student_id"], row["placement_status"], row["package_lpa"] if row["package_lpa"] is not None else None])

    path.parent.mkdir(parents=True, exist_ok=True)
    book.save(path)


def write_csv(frame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def sql_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def write_seed(records: list[dict], path: Path) -> None:
    """Twenty rows — enough to demo MySQL without importing the full file."""
    lines = [
        "-- Twenty fictional students for a quick MySQL demo.",
        "-- Import the full workbook with: python import_excel.py",
        "-- Safe to re-run: deletes these 20 IDs first.",
        "USE careerai_db;",
        "",
    ]
    ids = ", ".join(sql_string(row["student_id"]) for row in records[:20])
    lines.append(f"DELETE FROM Placement WHERE Student_ID IN ({ids});")
    lines.append(f"DELETE FROM Career_Interest WHERE Student_ID IN ({ids});")
    lines.append(f"DELETE FROM Skills WHERE Student_ID IN ({ids});")
    lines.append(f"DELETE FROM Academic WHERE Student_ID IN ({ids});")
    lines.append(f"DELETE FROM Students WHERE Student_ID IN ({ids});")
    lines.append("")
    for row in records[:20]:
        lines.append(
            "INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ("
            + ", ".join([
                sql_string(row["student_id"]),
                sql_string(row["name"]),
                str(row["age"]),
                sql_string(row["gender"]),
                sql_string(row["course"]),
                str(row["year"]),
                str(row["semester"]),
                sql_string(row["department"]),
            ])
            + ");"
        )
        lines.append(
            "INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ("
            + ", ".join([
                sql_string(row["student_id"]),
                f"{row['cgpa']:.1f}",
                str(int(row["attendance"])),
                str(row["backlogs"]),
                str(row["internships"]),
                str(row["certifications"]),
            ])
            + ");"
        )
        lines.append(
            "INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ("
            + ", ".join([
                sql_string(row["student_id"]),
                str(row["excel"]),
                str(row["sql"]),
                str(row["python"]),
                str(row["powerbi"]),
                str(row["communication"]),
                str(row["data_analysis"]),
            ])
            + ");"
        )
        lines.append(
            "INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ("
            + ", ".join([
                sql_string(row["student_id"]),
                sql_string(row["first_choice"]),
                sql_string(row["second_choice"]),
            ])
            + ");"
        )
        package = "NULL" if row["package_lpa"] is None else f"{row['package_lpa']:.1f}"
        lines.append(
            "INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ("
            + ", ".join([
                sql_string(row["student_id"]),
                sql_string(row["placement_status"]),
                package,
            ])
            + ");"
        )
        lines.append("")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def ts_string(value: str) -> str:
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def write_dataset_ts(records: list[dict], path: Path) -> None:
    lines = [
        "/* Generated by careerai/python/generate_dataset.py. Fictional students only. */",
        'import type { StudentRecord } from "./types";',
        "",
        "export const FEATURED: { studentId: string; name: string; note: string }[] = [",
        '  { studentId: "CAI24001", name: "Aanya Deshmukh", note: "High readiness, data profile" },',
        '  { studentId: "CAI24002", name: "Kabir Menon", note: "Business analyst profile" },',
        '  { studentId: "CAI24003", name: "Meera Iyer", note: "HR analyst profile" },',
        '  { studentId: "CAI24004", name: "Riya Kapoor", note: "Marketing analyst profile" },',
        '  { studentId: "CAI24005", name: "Arjun Reddy", note: "Financial analyst profile" },',
        '  { studentId: "CAI24006", name: "Rohan Das", note: "Needs improvement" },',
        "];",
        "",
        "export const DATASET: StudentRecord[] = [",
    ]
    for row in records:
        interests = ", ".join(ts_string(item) for item in row["interests"])
        package = "null" if row["package_lpa"] is None else str(row["package_lpa"])
        lines.append(
            "  {"
            + f' studentId: {ts_string(row["student_id"])},'
            + f' name: {ts_string(row["name"])},'
            + f' age: {row["age"]},'
            + f' gender: {ts_string(row["gender"])},'
            + f' course: {ts_string(row["course"])},'
            + f' year: {row["year"]},'
            + f' semester: {row["semester"]},'
            + f' department: {ts_string(row["department"])},'
            + f' email: {ts_string(row["email"])},'
            + f' cgpa: {row["cgpa"]},'
            + f' attendance: {int(row["attendance"])},'
            + f' backlogs: {row["backlogs"]},'
            + f' internships: {row["internships"]},'
            + f' certifications: {row["certifications"]},'
            + f' excel: {row["excel"]},'
            + f' sql: {row["sql"]},'
            + f' python: {row["python"]},'
            + f' powerbi: {row["powerbi"]},'
            + f' communication: {row["communication"]},'
            + f' dataAnalysis: {row["data_analysis"]},'
            + f" interests: [{interests}],"
            + f' firstChoice: {ts_string(row["first_choice"])},'
            + f' secondChoice: {ts_string(row["second_choice"])},'
            + f' placementStatus: {ts_string(row["placement_status"])},'
            + f" packageLpa: {package},"
            + " },"
        )
    lines.append("];")
    lines.append("")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def excel_frame(records: list[dict]):
    import pandas as pd

    raw_rows = []
    for row in records:
        raw_rows.append(
            {
                "Student_ID": row["student_id"],
                "Name": row["name"],
                "Age": row["age"],
                "Gender": row["gender"],
                "Course": row["course"],
                "Year": row["year"],
                "Semester": row["semester"],
                "Department": row["department"],
                "CGPA": row["cgpa"],
                "Attendance": row["attendance"],
                "Backlogs": row["backlogs"],
                "Internship": row["internships"],
                "Certifications": row["certifications"],
                "Excel_Score": row["excel"],
                "SQL_Score": row["sql"],
                "Python_Score": row["python"],
                "PowerBI_Score": row["powerbi"],
                "Communication_Score": row["communication"],
                "Data_Analysis_Score": row["data_analysis"],
                "First_Choice": row["first_choice"],
                "Second_Choice": row["second_choice"],
                "Interests": ", ".join(row["interests"]),
                "Placement_Status": row["placement_status"],
                "Package": row["package_lpa"],
            }
        )
    return pd.DataFrame(raw_rows)


def main() -> None:
    records = build_records()
    excel_path = ROOT / "data" / "CareerAI_Student_Data.xlsx"
    write_excel(records, excel_path)

    frame = excel_frame(records)
    analysed = analyze_frame(frame)
    csv_path = ROOT / "powerbi" / "CareerAI_Analytical.csv"
    write_csv(analysed, csv_path)
    write_seed(records, ROOT / "database" / "seed_demo_20.sql")
    write_dataset_ts(records, WORKSPACE / "src" / "lib" / "career" / "dataset.ts")

    download = WORKSPACE / "public" / "downloads"
    download.mkdir(parents=True, exist_ok=True)
    (download / "CareerAI_Student_Data.xlsx").write_bytes(excel_path.read_bytes())
    (download / "CareerAI_Analytical.csv").write_bytes(csv_path.read_bytes())

    summary = cohort_summary(analysed)
    print("Wrote", len(records), "students")
    print(summary)
    print("--- featured ---")
    for row in records[:8]:
        result = analyze_student(normalize(row))
        top = ", ".join(f"{item['career']} {item['percent']}%" for item in result["top3"])
        print(f"{row['student_id']} {row['name']}: {result['readiness']} {result['band']} | {top}")


if __name__ == "__main__":
    main()
