"""CareerAI analysis package. Run modules from this folder, or add it to PYTHONPATH."""
