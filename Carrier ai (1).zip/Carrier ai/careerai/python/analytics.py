"""Cohort analytics: averages, placement, preferences, and readiness.

Uses Pandas. The numbers match the admin page of the web prototype because
both call the same project-defined formulas.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from career_scoring import normalize
from recommendation import analyze_student

ROOT = Path(__file__).resolve().parents[1]
EXCEL_PATH = ROOT / "data" / "CareerAI_Student_Data.xlsx"


def load_workbook(path: Path | None = None) -> dict[str, pd.DataFrame]:
    """Read the five project sheets from the Excel workbook."""
    workbook = path or EXCEL_PATH
    sheets = {
        "students": pd.read_excel(workbook, sheet_name="Students"),
        "academic": pd.read_excel(workbook, sheet_name="Academic_Data"),
        "skills": pd.read_excel(workbook, sheet_name="Skills"),
        "interest": pd.read_excel(workbook, sheet_name="Career_Interest"),
        "placement": pd.read_excel(workbook, sheet_name="Placement"),
    }
    return sheets


def merge_sheets(sheets: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """One row per student, the same shape as the Power BI dataset."""
    frame = sheets["students"].merge(sheets["academic"], on="Student_ID", how="left")
    frame = frame.merge(sheets["skills"], on="Student_ID", how="left")
    frame = frame.merge(sheets["interest"], on="Student_ID", how="left")
    frame = frame.merge(sheets["placement"], on="Student_ID", how="left")
    return frame


def analyze_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Add readiness, band, matches, and the main skill gap for every row."""
    rows: list[dict[str, Any]] = []
    for raw in frame.to_dict(orient="records"):
        record = normalize(raw)
        result = analyze_student(record)
        match_map = {item["career"]: item["percent"] for item in result["matches"]}
        rows.append(
            {
                "Student_ID": record["student_id"],
                "Name": record["name"],
                "Age": record["age"],
                "Gender": record["gender"],
                "Course": record["course"],
                "Year": record["year"],
                "Semester": record["semester"],
                "Department": record["department"],
                "CGPA": record["cgpa"],
                "Attendance": record["attendance"],
                "Backlogs": record["backlogs"],
                "Internship": record["internships"],
                "Certifications": record["certifications"],
                "Excel_Score": record["excel"],
                "SQL_Score": record["sql"],
                "Python_Score": record["python"],
                "PowerBI_Score": record["powerbi"],
                "Communication_Score": record["communication"],
                "Data_Analysis_Score": record["data_analysis"],
                "First_Choice": record["first_choice"],
                "Second_Choice": record["second_choice"],
                "Placement_Status": record["placement_status"],
                "Package": record["package_lpa"],
                "Career_Readiness": result["readiness"],
                "Readiness_Band": result["band"],
                "Analytical_Ability": result["analytical_ability"],
                "Top_Career": result["top3"][0]["career"],
                "Top_Match": result["top3"][0]["percent"],
                **{
                    "Match_" + career.replace(" ", "_"): match_map[career]
                    for career in match_map
                },
                "Gap_Excel": int(record["excel"] < 6),
                "Gap_SQL": int(record["sql"] < 6),
                "Gap_Python": int(record["python"] < 6),
                "Gap_PowerBI": int(record["powerbi"] < 6),
                "Gap_Communication": int(record["communication"] < 6),
                "Gap_Data_Analysis": int(record["data_analysis"] < 6),
                "Primary_Gap": result["primary_gap"],
            }
        )
    return pd.DataFrame(rows)


def cohort_summary(analysed: pd.DataFrame) -> dict[str, Any]:
    """KPIs shown on the admin page and on Power BI page 1."""
    placed = (analysed["Placement_Status"] == "Placed").sum()
    known = analysed["Placement_Status"].isin(["Placed", "Not Placed", "Higher Studies"]).sum()
    gap_columns = {
        "Excel": "Gap_Excel",
        "SQL": "Gap_SQL",
        "Python": "Gap_Python",
        "Power BI": "Gap_PowerBI",
        "Communication": "Gap_Communication",
        "Data Analysis": "Gap_Data_Analysis",
    }
    gap_counts = {label: int(analysed[column].sum()) for label, column in gap_columns.items()}
    most_common_gap = max(gap_counts, key=gap_counts.get)
    return {
        "students": int(len(analysed)),
        "average_cgpa": round(float(analysed["CGPA"].mean()), 2),
        "average_attendance": round(float(analysed["Attendance"].mean()), 1),
        "average_readiness": round(float(analysed["Career_Readiness"].mean()), 1),
        "placement_percentage": round(100 * float(placed) / float(known), 1) if known else 0,
        "most_preferred_career": analysed["First_Choice"].mode().iloc[0],
        "most_common_skill_gap": most_common_gap,
        "gap_counts": gap_counts,
        "average_skills": {
            "Excel": round(float(analysed["Excel_Score"].mean()), 2),
            "SQL": round(float(analysed["SQL_Score"].mean()), 2),
            "Python": round(float(analysed["Python_Score"].mean()), 2),
            "Power BI": round(float(analysed["PowerBI_Score"].mean()), 2),
            "Communication": round(float(analysed["Communication_Score"].mean()), 2),
            "Data Analysis": round(float(analysed["Data_Analysis_Score"].mean()), 2),
        },
    }


def load_and_summarise(path: Path | None = None) -> tuple[pd.DataFrame, dict[str, Any]]:
    analysed = analyze_frame(merge_sheets(load_workbook(path)))
    return analysed, cohort_summary(analysed)


if __name__ == "__main__":
    table, summary = load_and_summarise()
    print(f"Students: {summary['students']}")
    print(f"Average CGPA: {summary['average_cgpa']}")
    print(f"Average attendance: {summary['average_attendance']}")
    print(f"Average career readiness: {summary['average_readiness']}")
    print(f"Placement %: {summary['placement_percentage']}")
    print(f"Most preferred career: {summary['most_preferred_career']}")
    print(f"Most common skill gap: {summary['most_common_skill_gap']}")
    print("Average skills:", summary["average_skills"])
    print(table[["Student_ID", "Name", "Career_Readiness", "Readiness_Band", "Top_Career", "Top_Match"]].head(8).to_string(index=False))
