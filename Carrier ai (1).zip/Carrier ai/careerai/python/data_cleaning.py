"""Clean student tables before they are loaded into MySQL or analysed.

The main Excel file is already fictional and tidy. Run demonstrate() to see
how this module treats missing values, duplicates, impossible scores, and
wrong data types — the checks a real file would need.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from career_scoring import SKILL_FIELDS


SCORE_COLUMNS = [key for key, _label in SKILL_FIELDS]


def clean_student_frame(frame: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Return a cleaned copy and a short report of what changed."""
    report: dict[str, Any] = {
        "rows_in": int(len(frame)),
        "duplicate_ids_removed": 0,
        "missing_filled": 0,
        "scores_clipped": 0,
        "types_fixed": 0,
    }
    data = frame.copy()

    if "Student_ID" not in data.columns and "student_id" in data.columns:
        data = data.rename(columns={"student_id": "Student_ID"})

    before = len(data)
    data = data.drop_duplicates(subset=["Student_ID"], keep="first")
    report["duplicate_ids_removed"] = before - len(data)

    numeric_columns = [
        "Age",
        "Year",
        "Semester",
        "CGPA",
        "Attendance",
        "Backlogs",
        "Internship",
        "Certifications",
        "Excel_Score",
        "SQL_Score",
        "Python_Score",
        "PowerBI_Score",
        "Communication_Score",
        "Data_Analysis_Score",
    ]
    for column in numeric_columns:
        if column not in data.columns:
            continue
        converted = pd.to_numeric(data[column], errors="coerce")
        report["types_fixed"] += int((converted.isna() & data[column].notna()).sum())
        data[column] = converted

    for column in numeric_columns:
        if column not in data.columns:
            continue
        missing = int(data[column].isna().sum())
        if missing:
            fill = data[column].median()
            if pd.isna(fill):
                fill = 0
            data[column] = data[column].fillna(fill)
            report["missing_filled"] += missing

    ranges = {
        "CGPA": (0, 10),
        "Attendance": (0, 100),
        "Backlogs": (0, 20),
        "Internship": (0, 10),
        "Certifications": (0, 20),
        "Age": (16, 40),
        "Year": (1, 5),
        "Semester": (1, 10),
        "Excel_Score": (1, 10),
        "SQL_Score": (1, 10),
        "Python_Score": (1, 10),
        "PowerBI_Score": (1, 10),
        "Communication_Score": (1, 10),
        "Data_Analysis_Score": (1, 10),
    }
    for column, (low, high) in ranges.items():
        if column not in data.columns:
            continue
        too_low = data[column] < low
        too_high = data[column] > high
        report["scores_clipped"] += int(too_low.sum() + too_high.sum())
        data[column] = data[column].clip(low, high)

    report["rows_out"] = int(len(data))
    return data, report


def demonstrate() -> pd.DataFrame:
    """Build a tiny messy table, clean it, and print the report."""
    messy = pd.DataFrame(
        [
            {
                "Student_ID": "DIRTY01",
                "Name": "Demo One",
                "CGPA": "8.2",
                "Attendance": 110,
                "Excel_Score": 12,
                "SQL_Score": None,
                "Python_Score": "abc",
                "PowerBI_Score": 6,
                "Communication_Score": 7,
                "Data_Analysis_Score": 0,
            },
            {
                "Student_ID": "DIRTY01",
                "Name": "Duplicate row",
                "CGPA": 9,
                "Attendance": 80,
                "Excel_Score": 8,
                "SQL_Score": 8,
                "Python_Score": 8,
                "PowerBI_Score": 8,
                "Communication_Score": 8,
                "Data_Analysis_Score": 8,
            },
            {
                "Student_ID": "DIRTY02",
                "Name": "Demo Two",
                "CGPA": None,
                "Attendance": 70,
                "Excel_Score": 5,
                "SQL_Score": 4,
                "Python_Score": 3,
                "PowerBI_Score": 5,
                "Communication_Score": 6,
                "Data_Analysis_Score": 4,
            },
        ]
    )
    cleaned, report = clean_student_frame(messy)
    print("Cleaning report:")
    for key, value in report.items():
        print(f"  {key}: {value}")
    print(cleaned.to_string(index=False))
    return cleaned


if __name__ == "__main__":
    demonstrate()
