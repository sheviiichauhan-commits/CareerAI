# CareerAI Power BI dashboards

Power BI Desktop is not embedded in the website. The admin page of the website shows the same measures so the project can be presented without opening Power BI. Use this file when you build the three Power BI pages.

## Which file to import

Preferred for a laptop demo:

1. Open Power BI Desktop.
2. Get data → Text/CSV.
3. Choose `CareerAI_Analytical.csv` in this folder.
4. Load it.

That file is one row per fictional student. It already contains the readiness score, the band, each career match, and a 1/0 flag for every skill gap.

Alternative, if MySQL is running:

1. Run `database/schema.sql`.
2. Import the workbook with `python python/import_excel.py`.
3. In Power BI, Get data → MySQL database, and use the JOIN query in `database/queries.sql` (query 10).
4. Add the score in Power Query or use the CSV, which is simpler for a viva.

## Slicers (put these on every page)

- Department
- Year
- Gender
- First_Choice (career interest)

## Page 1 — Student overview

Cards:

- Count of Student_ID
- Average of CGPA
- Average of Attendance
- Placement percentage: count of Placement_Status = "Placed" divided by all placement rows
- Average of Career_Readiness

Charts:

- CGPA as a histogram or a column chart of bands (you can bin CGPA in Power BI)
- Attendance as a column chart
- Placement_Status as a donut
- Department on the axis, Average of CGPA as the value

## Page 2 — Skill analytics

Cards or a bar chart for the average of:

- Excel_Score
- SQL_Score
- Python_Score
- PowerBI_Score
- Communication_Score
- Data_Analysis_Score

Skill-gap visual:

- Sum of Gap_Excel, Gap_SQL, Gap_Python, Gap_PowerBI, Gap_Communication, Gap_Data_Analysis
- The largest sum is the most common weak skill
- In this sample, Python is the most common gap (score below 6)

## Page 3 — Career analytics

- First_Choice as a bar chart (most preferred careers)
- A column for Top_Match, or the six Match_ columns, to show how strong the matches are
- Readiness_Band as a donut (Highly Ready, Moderately Ready, Needs Improvement)
- A clustered column of average skill scores split by First_Choice (career versus skill)
- Placement_Status counted by First_Choice (placement by career interest)

## How the numbers were produced

`python/analytics.py` merges the five Excel sheets and calls the same recommendation function as the website. Do not type a different formula into Power BI unless you also change the Python file and the website. The project rule is one formula, three views.

## Limits to say in the viva

- The students are fictional.
- Career_Readiness is a project-defined score.
- A chart is not a decision about a real student.
