import { DATASET, FEATURED } from "./dataset";
import type { Analysis, StudentRecord } from "./types";

export { DATASET, FEATURED };

export function isAssessed(student: StudentRecord): boolean {
  return student.assessed !== false;
}

export function mergeStudents(overrides: Record<string, StudentRecord>): StudentRecord[] {
  const map = new Map(DATASET.map((student) => [student.studentId.toUpperCase(), student]));
  for (const student of Object.values(overrides)) {
    map.set(student.studentId.toUpperCase(), { ...student, studentId: student.studentId.toUpperCase() });
  }
  return [...map.values()].sort((a, b) => a.studentId.localeCompare(b.studentId));
}

export function findStudent(
  id: string | null | undefined,
  overrides: Record<string, StudentRecord>,
): StudentRecord | undefined {
  const key = (id ?? "").trim().toUpperCase();
  if (!key) return undefined;
  return mergeStudents(overrides).find((student) => student.studentId === key);
}

export function studentContext(student: StudentRecord, analysis: Analysis): string {
  const skillLine = (label: string, score: number) => `${label}: ${score}/10`;
  return [
    "Student context. Use only these facts. Do not invent marks, projects, internships, or employers.",
    `Student ID: ${student.studentId}`,
    `Name: ${student.name}`,
    `Age: ${student.age}`,
    `Gender: ${student.gender}`,
    `Course: ${student.course}`,
    `Year: ${student.year}, Semester: ${student.semester}`,
    `Department: ${student.department}`,
    `CGPA (10-point scale): ${student.cgpa}`,
    `Attendance: ${student.attendance}%`,
    `Backlogs: ${student.backlogs}`,
    `Internships completed: ${student.internships}`,
    `Certifications: ${student.certifications}`,
    skillLine("Excel", student.excel),
    skillLine("SQL", student.sql),
    skillLine("Python", student.python),
    skillLine("Power BI", student.powerbi),
    skillLine("Communication", student.communication),
    skillLine("Data Analysis", student.dataAnalysis),
    `Selected interests: ${student.interests.join(", ") || "not provided"}`,
    `First career choice: ${student.firstChoice}`,
    `Second career choice: ${student.secondChoice}`,
    `Project-defined Career Readiness: ${analysis.readiness}/100 (${analysis.band}). Exact weighted total before rounding: ${analysis.readinessExact}.`,
    "Career match percentages already calculated by the project rules:",
    ...analysis.matches.map((match) => `${match.career}: ${match.percent}%`),
    `Strengths (7/10 or above): ${analysis.strengths.map((item) => `${item.skill} ${item.score}`).join(", ") || "none yet"}`,
    `Skill gaps (below 6/10): ${analysis.gaps.map((item) => `${item.skill} ${item.score}`).join(", ") || "none"}`,
    `Suggested skills and topics: ${analysis.recommendedSkills.join(", ")}`,
    `Suggested projects: ${analysis.projects.join("; ")}`,
    "30-day roadmap already prepared:",
    ...analysis.roadmap.map((week) => `${week.week} — ${week.focus}: ${week.tasks.join(" ")}`),
    "Quote the readiness score and match percentages above. Do not replace them with new percentages.",
  ].join("\n");
}
