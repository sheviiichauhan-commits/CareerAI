export const CAREERS = [
  "Data Analyst",
  "Business Analyst",
  "HR Analyst",
  "Marketing Analyst",
  "Financial Analyst",
  "Supply Chain Analyst",
  "Marketing Manager",
  "HR Manager",
  "Accountant",
  "Operations Manager",
  "Sales Executive",
  "Banking Associate",
  "Management Consultant",
  "Digital Marketing Specialist",
  "Entrepreneur",
  "Software Developer",
] as const;

export type Career = (typeof CAREERS)[number];

export const CAREER_GROUPS: { stream: string; careers: readonly Career[] }[] = [
  {
    stream: "Analytics",
    careers: [
      "Data Analyst",
      "Business Analyst",
      "HR Analyst",
      "Marketing Analyst",
      "Financial Analyst",
      "Supply Chain Analyst",
    ],
  },
  {
    stream: "Business",
    careers: [
      "Marketing Manager",
      "Digital Marketing Specialist",
      "HR Manager",
      "Accountant",
      "Banking Associate",
      "Operations Manager",
      "Sales Executive",
      "Management Consultant",
      "Entrepreneur",
    ],
  },
  {
    stream: "Technology",
    careers: ["Software Developer"],
  },
];

export function careerStream(career: string): string {
  return CAREER_GROUPS.find((group) => (group.careers as readonly string[]).includes(career))?.stream ?? "Career";
}

export type StudentRecord = {
  studentId: string;
  name: string;
  age: number;
  gender: string;
  course: string;
  year: number;
  semester: number;
  department: string;
  email: string;
  cgpa: number;
  attendance: number;
  backlogs: number;
  internships: number;
  certifications: number;
  excel: number;
  sql: number;
  python: number;
  powerbi: number;
  communication: number;
  dataAnalysis: number;
  interests: string[];
  firstChoice: string;
  secondChoice: string;
  placementStatus: string;
  packageLpa: number | null;
  /** False until a newly registered student finishes the assessment. */
  assessed?: boolean;
};

export type ScorePart = {
  key: string;
  label: string;
  weight: string;
  detail: string;
  points: number;
  max: number;
};

export type CareerMatch = {
  career: Career;
  percent: number;
  skillFit: number;
  interestFit: number;
};

export type RatedSkill = {
  key: string;
  skill: string;
  score: number;
};

export type RoadmapWeek = {
  week: string;
  focus: string;
  tasks: string[];
};

export type Analysis = {
  readinessExact: number;
  readiness: number;
  band: "Highly Ready" | "Moderately Ready" | "Needs Improvement";
  breakdown: ScorePart[];
  analyticalAbility: number;
  matches: CareerMatch[];
  top3: CareerMatch[];
  strengths: RatedSkill[];
  gaps: RatedSkill[];
  recommendedSkills: string[];
  projects: string[];
  roadmap: RoadmapWeek[];
  primaryGap: string;
  note: string;
};
