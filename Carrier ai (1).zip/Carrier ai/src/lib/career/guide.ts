export type Slide = {
  title: string;
  bullets: string[];
  say: string;
};

export const SLIDES: Slide[] = [
  {
    title: "CareerAI",
    bullets: [
      "Understand your skills. Discover your career. Build your future.",
      "A student analytics project for BBA: Excel, SQL, Python, Power BI, and AI in one flow.",
      "Demo data only. The score is a classroom model, not a job prediction.",
    ],
    say: "Good morning. CareerAI helps a student see their skills, gaps, and a short learning plan. I will show the website, then the data behind it.",
  },
  {
    title: "Problem statement",
    bullets: [
      "Students collect marks and certificates but still cannot explain which role fits.",
      "Skill gaps stay hidden until placement season.",
      "Teachers do not get one view of attendance, skills, and career interest together.",
    ],
    say: "The problem is not a lack of marks. It is a lack of a simple picture that a student and a teacher can both use.",
  },
  {
    title: "Objectives",
    bullets: [
      "Collect a student profile and an assessment.",
      "Calculate a transparent Career Readiness score from 0 to 100.",
      "Recommend three careers, list gaps, and give a 30-day roadmap.",
      "Give teachers cohort charts and a Power BI file.",
      "Let a student ask an AI coach that can see the saved profile.",
    ],
    say: "Every objective is something you can click in the prototype. I am not only describing a diagram.",
  },
  {
    title: "Technology stack",
    bullets: [
      "Excel for the fictional cohort.",
      "MySQL for related tables and queries.",
      "Python, Pandas, and NumPy for cleaning and analysis.",
      "A website for registration, assessment, results, and the coach.",
      "Power BI for the three teacher dashboards.",
    ],
    say: "I chose tools from our course, and I connected them so each one has a job. Excel is the source, SQL stores it, Python calculates, the website explains, Power BI summarises.",
  },
  {
    title: "System architecture",
    bullets: [
      "Excel to cleaning to MySQL.",
      "Python readiness score and recommendation rules.",
      "Website shows the same numbers to the student.",
      "Analytical CSV feeds Power BI.",
      "The coach prompt is fixed. The student facts are added as context.",
    ],
    say: "Please look at the Project files page. The eight steps are the architecture. The website and the Python file use the same weights, and I checked that they match.",
  },
  {
    title: "Dataset",
    bullets: [
      "320 fictional students. No real personal data.",
      "Sheets: Students, Academic_Data, Skills, Career_Interest, Placement.",
      "Skills are scored from 1 to 10.",
      "A small dirty sample in the Python cleaning demo shows missing values and duplicates.",
    ],
    say: "I did not use anyone’s real marks. Names and packages are invented. There are ready-made profiles, such as Aanya for a strong data match and Rohan for a low score.",
  },
  {
    title: "SQL database and queries",
    bullets: [
      "Database name: careerai_db.",
      "Primary keys on each table. Student_ID is the foreign key.",
      "Ten queries: low attendance, averages, skill gaps, placement, and one large JOIN.",
      "The high-readiness query repeats the same formula as the website.",
    ],
    say: "A primary key identifies a row. A foreign key stops an academic row from pointing at a student who does not exist. I can open queries.sql and explain any one of them.",
  },
  {
    title: "Python data analysis",
    bullets: [
      "Pandas reads the five sheets and merges them on Student_ID.",
      "Cleaning handles duplicates, bad types, missing numbers, and scores outside range.",
      "Analytics reports average CGPA, attendance, skills, placement, and the most common gap.",
      "In this sample, Python is the most common skill below 6.",
    ],
    say: "Pandas is the library that turns the Excel sheets into tables I can average and join. The cleaning function is separate so I can show a messy table and a clean one.",
  },
  {
    title: "Power BI dashboard",
    bullets: [
      "Page 1: student overview and department performance.",
      "Page 2: skill averages and skill gaps.",
      "Page 3: career preference, match, readiness bands, placement by interest.",
      "Slicers: department, year, gender, and career interest.",
      "The website admin page previews the same measures.",
    ],
    say: "Power BI is not inside the browser. I prepared the CSV and the page plan. The admin screen is the live preview of those measures.",
  },
  {
    title: "Career recommendation",
    bullets: [
      "Sixteen careers across analytics, business, finance, marketing, operations, and software.",
      "Skill fit uses published weights. Data Analyst leans on SQL, Python, Excel, Power BI, and analysis.",
      "Interest fit depends on first choice, second choice, and other ticks.",
      "Final match is 78% skills and 22% interest. Top three are shown.",
    ],
    say: "This is a rule, not a hidden model. If I change a Python rating, the Data Analyst percentage moves, and I can explain why.",
  },
  {
    title: "AI chatbot",
    bullets: [
      "Page name: AI Career Coach.",
      "The student can ask about careers, skills, projects, internships, and a resume.",
      "The coach receives the stored profile and the scores already calculated.",
      "If the key is missing or the service fails, the page says so. The rule-based score still works.",
    ],
    say: "I do not let the model invent a CGPA. The numbers are passed in. I also tell the user that an AI answer can be wrong.",
  },
  {
    title: "Prompt engineering",
    bullets: [
      "A system prompt defines the role, the limits, and the eight-part answer.",
      "The prompt says: do not invent facts, and do not decide the student’s future.",
      "Headings: recommendation, why it fits, strengths, gaps, skills, projects, roadmap, advice.",
      "The prompt is visible on the Project files page.",
    ],
    say: "Prompt engineering here means writing the instruction carefully, then attaching the real student context. The wording is part of the project, not a hidden trick.",
  },
  {
    title: "Complete workflow",
    bullets: [
      "Register, then complete the assessment.",
      "The profile is saved and the Python-equivalent rules run in the website.",
      "The student sees the score, matches, gaps, projects, and 30-day plan.",
      "They can ask the coach. A teacher opens Admin and the Power BI file.",
    ],
    say: "I will demonstrate with Aanya Deshmukh, then with Rohan Das, so you can see a high score and a low score from the same formula.",
  },
  {
    title: "Benefits and future scope",
    bullets: [
      "Students get language they can use in a resume or an internship application.",
      "Teachers see which skill is weak across a department.",
      "Later ideas: resume check, internship matching, mock interview, voice coach.",
      "Those are future work. They are not claimed as finished.",
    ],
    say: "The benefit today is clarity. The future list is honest about what this version does not do.",
  },
  {
    title: "Conclusion",
    bullets: [
      "CareerAI connects Excel, SQL, Python, Power BI, and a guided chatbot.",
      "The score is project-defined and explained on the result page.",
      "Recommendations are guidance. The dataset is fictional.",
      "Thank you. I can take questions from the viva list or from the live profile.",
    ],
    say: "I will close by repeating the limit: this should not be used to accept or reject a student. It is a learning and guidance tool. I am happy to take questions.",
  },
];

export const VIVA: { question: string; answer: string }[] = [
  {
    question: "Why did you select this project?",
    answer: "Students struggle to connect marks and skills to a career. This project uses the tools from our course to make that connection visible.",
  },
  {
    question: "Why Excel?",
    answer: "Excel is where the raw cohort starts. It is easy to show, easy to edit, and Power BI and Pandas can both read it.",
  },
  {
    question: "Why SQL?",
    answer: "SQL keeps students, marks, skills, interests, and placement in related tables so I can ask questions without scrolling through sheets.",
  },
  {
    question: "Why Python?",
    answer: "Python and Pandas clean the data and calculate the score and the career matches. The same rules are used on the website.",
  },
  {
    question: "Why Power BI?",
    answer: "Power BI is for the teacher view: filters, cards, and charts. The website previews those measures, and the CSV is ready to import.",
  },
  {
    question: "What is a database?",
    answer: "A database is an organised store of tables. Here the database is careerai_db.",
  },
  {
    question: "What is a primary key?",
    answer: "A primary key uniquely identifies each row. Student_ID is the primary key of the Students table.",
  },
  {
    question: "What is a foreign key?",
    answer: "A foreign key is a column that must match a primary key in another table. Academic.Student_ID must exist in Students.",
  },
  {
    question: "What is data cleaning?",
    answer: "Cleaning fixes problems before analysis: duplicate IDs, blank cells, text in a number column, and scores outside the allowed range.",
  },
  {
    question: "What is Pandas?",
    answer: "Pandas is a Python library for tables. I use it to read Excel, merge sheets, and calculate averages.",
  },
  {
    question: "What is Power BI?",
    answer: "Power BI is a Microsoft tool for interactive dashboards. This project prepares the dataset and the three-page plan.",
  },
  {
    question: "What is AI in this project?",
    answer: "AI is the Career Coach. It writes guidance from the student’s saved facts. It does not calculate the official score. The rules do that.",
  },
  {
    question: "What is a chatbot?",
    answer: "A chatbot is a conversation screen. The student types a question and the coach answers using the profile and a fixed prompt.",
  },
  {
    question: "What is prompt engineering?",
    answer: "It is the design of the instruction sent to the model: the role, the banned behaviour, the student facts, and the required headings.",
  },
  {
    question: "How does the recommendation system work?",
    answer: "Each career has skill weights. Skill fit is the weighted score. Interest fit comes from the student’s choices. Match is 78% skill fit plus 22% interest fit. The top three are shown.",
  },
  {
    question: "How is Career Readiness calculated?",
    answer: "CGPA 25%, technical skills 30%, communication 15%, attendance 10%, internship 10%, certifications 10%. The total is rounded to a whole number. 80 and above is Highly Ready, 60 to 79 is Moderately Ready, below 60 needs improvement.",
  },
  {
    question: "How does the website communicate with the database?",
    answer: "In the college package, Python writes rows into MySQL. In this prototype, the sample cohort is loaded with the app and new assessments are saved in the browser, using the same fields as the SQL tables.",
  },
  {
    question: "How does the chatbot receive student information?",
    answer: "When the student sends a question, the website adds their stored profile and the calculated scores to the prompt. The API key stays on the server.",
  },
  {
    question: "What are the limitations?",
    answer: "The data is fictional. The score is not a scientific employability test. AI can be wrong. The system must not make high-stakes decisions about students.",
  },
  {
    question: "What is the future scope?",
    answer: "Resume analysis, an ATS-style score, job and internship suggestions, mock interviews, interview questions, LinkedIn review, a voice coach, placement prediction, and more personal learning plans.",
  },
  {
    question: "Why is a skill below 6 called a gap?",
    answer: "That threshold is a project rule so the definition stays clear. It is not an industry standard.",
  },
  {
    question: "What happens if the AI service fails?",
    answer: "The page shows a plain error. The readiness score, matches, gaps, and roadmap still come from the rules, so the demo can continue.",
  },
];
