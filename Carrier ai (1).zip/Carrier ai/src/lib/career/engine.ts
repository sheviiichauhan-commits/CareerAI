import type {
  Analysis,
  Career,
  CareerMatch,
  RatedSkill,
  RoadmapWeek,
  ScorePart,
  StudentRecord,
} from "./types";
import { CAREERS } from "./types";

/**
 * Same classroom model as careerai/python/career_scoring.py.
 * Not a validated employability test.
 *
 * Career match = round(0.78 × skill fit + 0.22 × interest fit).
 * Skill weights for each career are in WEIGHTS and sum to 1.
 */

type WeightKey =
  | "excel"
  | "sql"
  | "python"
  | "powerbi"
  | "dataAnalysis"
  | "communication"
  | "analytical"
  | "cgpa";

export const WEIGHTS: Record<Career, Record<WeightKey, number>> = {
  "Data Analyst": {
    excel: 0.15,
    sql: 0.25,
    python: 0.22,
    powerbi: 0.18,
    dataAnalysis: 0.2,
    communication: 0,
    analytical: 0,
    cgpa: 0,
  },
  "Business Analyst": {
    excel: 0.22,
    sql: 0.18,
    python: 0,
    powerbi: 0.05,
    dataAnalysis: 0.22,
    communication: 0.23,
    analytical: 0.1,
    cgpa: 0,
  },
  "HR Analyst": {
    excel: 0.22,
    sql: 0.05,
    python: 0,
    powerbi: 0.08,
    dataAnalysis: 0.1,
    communication: 0.35,
    analytical: 0.2,
    cgpa: 0,
  },
  "Marketing Analyst": {
    excel: 0.2,
    sql: 0.05,
    python: 0,
    powerbi: 0.12,
    dataAnalysis: 0.23,
    communication: 0.3,
    analytical: 0.1,
    cgpa: 0,
  },
  "Financial Analyst": {
    excel: 0.3,
    sql: 0.08,
    python: 0.05,
    powerbi: 0.1,
    dataAnalysis: 0.12,
    communication: 0.08,
    analytical: 0.12,
    cgpa: 0.15,
  },
  Entrepreneur: {
    excel: 0.1,
    sql: 0.05,
    python: 0.05,
    powerbi: 0.08,
    dataAnalysis: 0.15,
    communication: 0.32,
    analytical: 0.15,
    cgpa: 0.1,
  },
  "Supply Chain Analyst": {
    excel: 0.25,
    sql: 0.12,
    python: 0.05,
    powerbi: 0.1,
    dataAnalysis: 0.22,
    communication: 0.12,
    analytical: 0.14,
    cgpa: 0,
  },
  "Marketing Manager": {
    excel: 0.12,
    sql: 0,
    python: 0,
    powerbi: 0.1,
    dataAnalysis: 0.15,
    communication: 0.38,
    analytical: 0.15,
    cgpa: 0.1,
  },
  "HR Manager": {
    excel: 0.18,
    sql: 0,
    python: 0,
    powerbi: 0.05,
    dataAnalysis: 0.08,
    communication: 0.4,
    analytical: 0.14,
    cgpa: 0.15,
  },
  Accountant: {
    excel: 0.34,
    sql: 0.05,
    python: 0,
    powerbi: 0.08,
    dataAnalysis: 0.18,
    communication: 0.08,
    analytical: 0.12,
    cgpa: 0.15,
  },
  "Operations Manager": {
    excel: 0.22,
    sql: 0.08,
    python: 0,
    powerbi: 0.08,
    dataAnalysis: 0.2,
    communication: 0.22,
    analytical: 0.12,
    cgpa: 0.08,
  },
  "Sales Executive": {
    excel: 0.12,
    sql: 0,
    python: 0,
    powerbi: 0.08,
    dataAnalysis: 0.1,
    communication: 0.42,
    analytical: 0.13,
    cgpa: 0.15,
  },
  "Banking Associate": {
    excel: 0.28,
    sql: 0.05,
    python: 0,
    powerbi: 0.07,
    dataAnalysis: 0.16,
    communication: 0.18,
    analytical: 0.11,
    cgpa: 0.15,
  },
  "Management Consultant": {
    excel: 0.15,
    sql: 0.08,
    python: 0.05,
    powerbi: 0.1,
    dataAnalysis: 0.18,
    communication: 0.22,
    analytical: 0.12,
    cgpa: 0.1,
  },
  "Digital Marketing Specialist": {
    excel: 0.12,
    sql: 0,
    python: 0.05,
    powerbi: 0.18,
    dataAnalysis: 0.15,
    communication: 0.35,
    analytical: 0.1,
    cgpa: 0.05,
  },
  "Software Developer": {
    excel: 0.05,
    sql: 0.28,
    python: 0.4,
    powerbi: 0.05,
    dataAnalysis: 0.12,
    communication: 0.05,
    analytical: 0.05,
    cgpa: 0,
  },
};

const SKILL_FIELDS: { key: keyof StudentRecord; label: string; weightKey: WeightKey }[] = [
  { key: "excel", label: "Excel", weightKey: "excel" },
  { key: "sql", label: "SQL", weightKey: "sql" },
  { key: "python", label: "Python", weightKey: "python" },
  { key: "powerbi", label: "Power BI", weightKey: "powerbi" },
  { key: "communication", label: "Communication", weightKey: "communication" },
  { key: "dataAnalysis", label: "Data Analysis", weightKey: "dataAnalysis" },
];

const RELATED: Record<Career, string[]> = {
  "Data Analyst": ["Statistics", "Data storytelling"],
  "Business Analyst": ["Requirements writing", "Process mapping"],
  "HR Analyst": ["People analytics basics", "Survey design"],
  "Marketing Analyst": ["Campaign measurement", "Customer segmentation"],
  "Financial Analyst": ["Financial statements", "Forecasting"],
  Entrepreneur: ["Customer discovery", "Unit economics"],
  "Supply Chain Analyst": ["Inventory basics", "Demand planning"],
  "Marketing Manager": ["Brand positioning", "Team briefing"],
  "HR Manager": ["Interview design", "Labour law basics"],
  Accountant: ["Bookkeeping basics", "GST overview"],
  "Operations Manager": ["Process mapping", "Inventory basics"],
  "Sales Executive": ["Sales conversation", "Pipeline tracking"],
  "Banking Associate": ["Bank products", "KYC basics"],
  "Management Consultant": ["Case structure", "Stakeholder briefing"],
  "Digital Marketing Specialist": ["Content calendar", "Campaign measurement"],
  "Software Developer": ["Programming practice", "SQL"],
};

const PROJECTS: Record<Career, string[]> = {
  "Data Analyst": [
    "Sales Dashboard",
    "Student Performance Analysis",
    "Customer Segmentation",
    "Marketing Analytics",
  ],
  "Business Analyst": [
    "Process Improvement Case",
    "Requirements Dashboard",
    "Market Sizing Model",
    "Stakeholder Status Report",
  ],
  "HR Analyst": [
    "Attrition Dashboard",
    "Hiring Funnel Analysis",
    "Employee Survey Insights",
    "Compensation Benchmark",
  ],
  "Marketing Analyst": [
    "Campaign Performance Dashboard",
    "Customer Segmentation Study",
    "Social Media KPI Tracker",
    "A/B Test Summary",
  ],
  "Financial Analyst": [
    "Budget versus Actual Dashboard",
    "Ratio Analysis Workbook",
    "Cash Flow Forecast",
    "Expense Variance Report",
  ],
  Entrepreneur: [
    "Lean Canvas with Market Sizing",
    "Customer Discovery Notes",
    "Unit Economics Model",
    "Pitch Metrics Dashboard",
  ],
  "Supply Chain Analyst": [
    "Inventory Turnover Workbook",
    "Supplier Lead-Time Dashboard",
    "Demand Forecast for a Campus Store",
    "Stock-out Case Note",
  ],
  "Marketing Manager": [
    "Fest Campaign Plan",
    "Brand Message Test",
    "Channel Mix Budget",
    "Monthly Marketing Review",
  ],
  "HR Manager": [
    "Campus Hiring Plan",
    "Interview Scorecard",
    "Onboarding Checklist",
    "Attendance Policy Brief",
  ],
  Accountant: [
    "Three-Statement Mini Workbook",
    "Expense Classification Sheet",
    "GST Calculation Example",
    "Bank Reconciliation Practice",
  ],
  "Operations Manager": [
    "Canteen Process Map",
    "Turnaround-Time Tracker",
    "Capacity Planning Sheet",
    "Service Delay Report",
  ],
  "Sales Executive": [
    "Prospect List and Script",
    "Simple Sales Pipeline",
    "Objection Handling Notes",
    "Weekly Sales Review",
  ],
  "Banking Associate": [
    "Product Comparison Sheet",
    "KYC Checklist Walkthrough",
    "Savings versus FD Example",
    "Customer Query Log",
  ],
  "Management Consultant": [
    "One-Page Problem Statement",
    "Issue Tree for a Campus Service",
    "Recommendation Memo",
    "Before-and-After Metrics",
  ],
  "Digital Marketing Specialist": [
    "Content Calendar",
    "Landing-Page KPI Sheet",
    "Social Post Test",
    "Campaign Report",
  ],
  "Software Developer": [
    "Student Lookup Script",
    "Small CRUD Practice App",
    "SQL Query Notebook",
    "Bug-Fix Log",
  ],
};

const WEEK_TASKS: Record<string, string[]> = {
  Excel: [
    "Clean one small table: remove blanks and fix number formats.",
    "Practice SUMIF, AVERAGEIF, and one PivotTable.",
    "Write two sentences explaining what the PivotTable shows.",
  ],
  SQL: [
    "Write SELECT, WHERE, and ORDER BY on the Students table.",
    "JOIN Students with Academic on Student_ID.",
    "Add one GROUP BY to find an average by department.",
  ],
  Python: [
    "Load the Excel file with Pandas.",
    "Calculate average CGPA and average attendance.",
    "Check data types and fix one column if needed.",
  ],
  "Power BI": [
    "Import the analytical CSV.",
    "Build one KPI card and one bar chart.",
    "Add a slicer for Department.",
  ],
  "Data Analysis": [
    "Write one question the dataset can answer.",
    "Compare two departments on CGPA and attendance.",
    "List three findings and one limitation.",
  ],
  Communication: [
    "Explain your top career match in 60 seconds.",
    "Rewrite that explanation without jargon.",
    "Ask a classmate to repeat it back to you.",
  ],
  Statistics: [
    "Revise mean, median, and percentage.",
    "Read one chart from the dashboard out loud.",
    "State one reason a score is not a prediction.",
  ],
  "Data storytelling": [
    "Turn one number into a sentence a non-technical person understands.",
    "Give a chart a title that states the finding.",
    "End with one recommended action.",
  ],
  "Requirements writing": [
    "Write the question a manager is trying to answer.",
    "List the fields you would need.",
    "Note who would use the result.",
  ],
  "Process mapping": [
    "Sketch five steps of a campus process you know.",
    "Mark where data is collected.",
    "Suggest one delay that data could reveal.",
  ],
  "People analytics basics": [
    "Define attrition in one sentence.",
    "List three HR metrics that use a percentage.",
    "Explain why a small sample can mislead.",
  ],
  "Survey design": [
    "Write five clear questions for a student survey.",
    "Remove any leading wording.",
    "Decide how you would score the answers.",
  ],
  "Campaign measurement": [
    "Pick a fictional college-fest campaign.",
    "Choose reach, clicks, and sign-ups as metrics.",
    "Say which metric matters most and why.",
  ],
  "Customer segmentation": [
    "Split a fictional customer list into three groups.",
    "Name each group by behaviour, not only age.",
    "Suggest one offer for each group.",
  ],
  "Financial statements": [
    "Name the income statement, balance sheet, and cash flow statement.",
    "Explain revenue versus profit in one line.",
    "Calculate one simple expense ratio.",
  ],
  Forecasting: [
    "Take six fictional monthly sales numbers.",
    "Find the average and a simple next-month estimate.",
    "Write one reason the estimate could be wrong.",
  ],
  "Customer discovery": [
    "Write five questions you would ask a possible customer.",
    "Do not pitch inside those questions.",
    "Summarise what you would listen for.",
  ],
  "Unit economics": [
    "Define price, cost, and margin with a campus example.",
    "Calculate margin for one fictional product.",
    "Say what happens if the cost rises.",
  ],
  "Inventory basics": [
    "Define stock, lead time, and stock-out in one line each.",
    "Track five fictional items and their quantities.",
    "Flag one item that should be reordered.",
  ],
  "Demand planning": [
    "List three things that change demand for a campus store.",
    "Compare last month and this month for one product.",
    "Write one cautious forecast, with a reason it could be wrong.",
  ],
  "Brand positioning": [
    "Name the audience, the offer, and the difference in one sentence.",
    "Write two taglines and pick one.",
    "Say where that audience already spends time.",
  ],
  "Team briefing": [
    "Write a five-line brief: goal, audience, deadline, owner, measure.",
    "Remove jargon from the brief.",
    "Add one decision the team still needs.",
  ],
  "Interview design": [
    "Write five job-related questions, not trick questions.",
    "Add a simple 1–5 score for each answer.",
    "Note one question that checks communication.",
  ],
  "Labour law basics": [
    "List three workplace rules a new joiner should know.",
    "Explain attendance and leave in plain language.",
    "State that this is study material, not legal advice.",
  ],
  "Bookkeeping basics": [
    "Record five fictional receipts as debit and credit.",
    "Separate expense from asset with one example.",
    "Total the expenses and check the sum.",
  ],
  "GST overview": [
    "Explain GST as a tax on a sale, in one sentence.",
    "Calculate tax on a ₹1,000 bill at 18%.",
    "Say who the tax is collected for.",
  ],
  "Sales conversation": [
    "Write a 30-second opening that asks a question, not a pitch.",
    "List three objections and a calm reply for each.",
    "End with one next step and a date.",
  ],
  "Pipeline tracking": [
    "Make columns: name, need, stage, next step, date.",
    "Add five fictional prospects.",
    "Mark which one needs a follow-up this week.",
  ],
  "Bank products": [
    "Compare a savings account, an FD, and a personal loan in a table.",
    "Write who each product is for.",
    "Note one risk the customer should hear.",
  ],
  "KYC basics": [
    "List the documents a bank typically asks for.",
    "Explain why identity checks exist, in two sentences.",
    "Write one polite way to request a missing document.",
  ],
  "Case structure": [
    "State the problem in one sentence.",
    "Split it into three branches.",
    "End with one recommendation and one risk.",
  ],
  "Stakeholder briefing": [
    "Name who decides, who uses the work, and who is affected.",
    "Write what each person needs to hear.",
    "Keep the brief under 150 words.",
  ],
  "Content calendar": [
    "Plan four posts for one fictional college event.",
    "Give each post a goal: reach, click, or sign-up.",
    "Note the day and the channel.",
  ],
  "Programming practice": [
    "Write a short Python script that reads a list of marks.",
    "Print the average and the count of scores below 6.",
    "Add one comment that explains the calculation.",
  ],
  "Review and explain your strongest skill": [
    "Pick the skill you rated 7 or above.",
    "Explain it in five sentences without slides.",
    "Write one example you could put on a resume.",
  ],
};

export const GAP_BELOW = 6;
export const STRENGTH_FROM = 7;

export function roundHalfUp(value: number): number {
  return Math.floor(value + 0.5);
}

export function roundPlaces(value: number, places: number): number {
  const factor = 10 ** places;
  return Math.floor(value * factor + 0.5) / factor;
}

function clamp(value: number, low: number, high: number): number {
  return Math.max(low, Math.min(high, value));
}

function internshipPoints(internships: number): number {
  if (internships <= 0) return 0;
  if (internships === 1) return 6;
  return 10;
}

function certificationPoints(certifications: number): number {
  if (certifications <= 0) return 0;
  if (certifications === 1) return 4;
  if (certifications === 2) return 7;
  return 10;
}

export function analyticalAbility(dataAnalysis: number, cgpa: number): number {
  const cgpa10 = clamp(cgpa, 0, 10);
  return roundPlaces(0.7 * dataAnalysis + 0.3 * cgpa10, 2);
}

export function readinessParts(student: StudentRecord): ScorePart[] {
  const cgpa = clamp(student.cgpa, 0, 10);
  const attendance = clamp(student.attendance, 0, 100);
  const techAvg =
    (student.excel + student.sql + student.python + student.powerbi + student.dataAnalysis) / 5;
  const communication = clamp(student.communication, 0, 10);
  return [
    {
      key: "cgpa",
      label: "CGPA",
      weight: "25%",
      detail: `${cgpa.toFixed(1)} / 10`,
      points: roundPlaces((cgpa / 10) * 25, 2),
      max: 25,
    },
    {
      key: "technical",
      label: "Technical skills",
      weight: "30%",
      detail: `Average ${techAvg.toFixed(1)} / 10 across Excel, SQL, Python, Power BI, Data Analysis`,
      points: roundPlaces((techAvg / 10) * 30, 2),
      max: 30,
    },
    {
      key: "communication",
      label: "Communication",
      weight: "15%",
      detail: `${communication.toFixed(0)} / 10`,
      points: roundPlaces((communication / 10) * 15, 2),
      max: 15,
    },
    {
      key: "attendance",
      label: "Attendance",
      weight: "10%",
      detail: `${attendance.toFixed(0)}%`,
      points: roundPlaces((attendance / 100) * 10, 2),
      max: 10,
    },
    {
      key: "internship",
      label: "Internship",
      weight: "10%",
      detail: `${student.internships} internship(s) — 0→0, 1→6, 2+→10`,
      points: internshipPoints(student.internships),
      max: 10,
    },
    {
      key: "certifications",
      label: "Certifications",
      weight: "10%",
      detail: `${student.certifications} certificate(s) — 0→0, 1→4, 2→7, 3+→10`,
      points: certificationPoints(student.certifications),
      max: 10,
    },
  ];
}

function interestFit(career: Career, student: StudentRecord): number {
  if (career === student.firstChoice) return 100;
  if (career === student.secondChoice) return 80;
  if (student.interests.includes(career)) return 65;
  return 40;
}

function to100(score: number): number {
  return (clamp(score, 0, 10) / 10) * 100;
}

function skillFit(career: Career, student: StudentRecord): number {
  const analytical = analyticalAbility(student.dataAnalysis, student.cgpa);
  const values: Record<WeightKey, number> = {
    excel: to100(student.excel),
    sql: to100(student.sql),
    python: to100(student.python),
    powerbi: to100(student.powerbi),
    dataAnalysis: to100(student.dataAnalysis),
    communication: to100(student.communication),
    analytical: to100(analytical),
    cgpa: (clamp(student.cgpa, 0, 10) / 10) * 100,
  };
  const weights = WEIGHTS[career];
  return (Object.keys(weights) as WeightKey[]).reduce((sum, key) => sum + weights[key] * values[key], 0);
}

function matchPercent(career: Career, student: StudentRecord): number {
  const raw = 0.78 * skillFit(career, student) + 0.22 * interestFit(career, student);
  return clamp(roundHalfUp(raw), 0, 100);
}

function tasksFor(topic: string): string[] {
  return (
    WEEK_TASKS[topic] ?? [
      `Spend three short sessions learning the basics of ${topic}.`,
      "Write five bullet notes in your own words.",
      "Connect the topic to your top career match in one paragraph.",
    ]
  );
}

function buildRoadmap(career: Career, gapNames: string[]): RoadmapWeek[] {
  const weights = WEIGHTS[career];
  const weightOf = (label: string) => {
    const field = SKILL_FIELDS.find((item) => item.label === label);
    return field ? weights[field.weightKey] : 0;
  };
  const ranked = [...gapNames].sort((a, b) => weightOf(b) - weightOf(a));
  const extras = RELATED[career].filter((topic) => !ranked.includes(topic));
  const focus: string[] = [];
  for (const name of [...ranked, ...extras]) {
    if (!focus.includes(name)) focus.push(name);
    if (focus.length === 3) break;
  }
  while (focus.length < 3) {
    const options = [...RELATED[career], "Review and explain your strongest skill"];
    const topic = options.find((item) => !focus.includes(item));
    if (!topic) break;
    focus.push(topic);
  }
  const project = PROJECTS[career][0] ?? "Analytics project";
  const weeks: RoadmapWeek[] = focus.map((topic, index) => ({
    week: `Week ${index + 1}`,
    focus: topic,
    tasks: tasksFor(topic),
  }));
  weeks.push({
    week: "Week 4",
    focus: `Build: ${project}`,
    tasks: [
      `Start the project “${project}” with the sample data or a small public dataset.`,
      "Show one chart, three findings, and one limitation.",
      "Add the project to your resume in four lines: tool, data, action, result.",
    ],
  });
  return weeks;
}

export function analyzeStudent(student: StudentRecord): Analysis {
  const breakdown = readinessParts(student);
  const readinessExact = roundPlaces(
    breakdown.reduce((sum, part) => sum + part.points, 0),
    2,
  );
  const readiness = roundHalfUp(readinessExact);
  const band = readiness >= 80 ? "Highly Ready" : readiness >= 60 ? "Moderately Ready" : "Needs Improvement";

  const matches: CareerMatch[] = CAREERS.map((career) => ({
    career,
    percent: matchPercent(career, student),
    skillFit: roundPlaces(skillFit(career, student), 1),
    interestFit: interestFit(career, student),
  })).sort((a, b) => b.percent - a.percent || a.career.localeCompare(b.career));

  const rated: RatedSkill[] = SKILL_FIELDS.map((field) => ({
    key: field.key,
    skill: field.label,
    score: Math.round(Number(student[field.key])),
  }));
  const strengths = rated.filter((item) => item.score >= STRENGTH_FROM).sort((a, b) => b.score - a.score);
  const gaps = rated.filter((item) => item.score < GAP_BELOW).sort((a, b) => a.score - b.score);
  const top = matches[0];
  if (!top) {
    throw new Error("No careers configured.");
  }
  const weights = WEIGHTS[top.career];
  const recommended = [...gaps]
    .sort((a, b) => {
      const aw = SKILL_FIELDS.find((field) => field.label === a.skill);
      const bw = SKILL_FIELDS.find((field) => field.label === b.skill);
      return (bw ? weights[bw.weightKey] : 0) - (aw ? weights[aw.weightKey] : 0);
    })
    .map((item) => item.skill);
  for (const topic of RELATED[top.career]) {
    if (!recommended.includes(topic)) recommended.push(topic);
  }

  return {
    readinessExact,
    readiness,
    band,
    breakdown,
    analyticalAbility: analyticalAbility(student.dataAnalysis, student.cgpa),
    matches,
    top3: matches.slice(0, 3),
    strengths,
    gaps,
    recommendedSkills: recommended,
    projects: PROJECTS[top.career],
    roadmap: buildRoadmap(top.career, gaps.map((item) => item.skill)),
    primaryGap: gaps[0]?.skill ?? "None — no rated skill is below 6",
    note: "Project-defined analytical score for learning and guidance. Not a placement prediction and not a decision about the student.",
  };
}

export function bandTone(band: Analysis["band"]): "ready" | "mid" | "gap" {
  if (band === "Highly Ready") return "ready";
  if (band === "Moderately Ready") return "mid";
  return "gap";
}
