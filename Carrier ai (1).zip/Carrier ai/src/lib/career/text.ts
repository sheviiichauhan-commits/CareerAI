/** Drop markdown markers so coach answers read cleanly without a markdown library. */
export function readableAnswer(text: string): string {
  return text.replace(/\*\*/g, "").replace(/^#{1,6}\s+/gm, "");
}
