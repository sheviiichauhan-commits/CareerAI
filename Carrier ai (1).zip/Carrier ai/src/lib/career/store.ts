import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { StudentRecord } from "./types";

export type ChatMessage = { role: "user" | "assistant"; content: string };

type CareerState = {
  overrides: Record<string, StudentRecord>;
  activeId: string | null;
  chats: Record<string, ChatMessage[]>;
  advice: Record<string, string>;
  hydrated: boolean;
  setActive: (id: string | null) => void;
  saveStudent: (student: StudentRecord) => void;
  pushMessage: (id: string, message: ChatMessage) => void;
  setAdvice: (id: string, text: string) => void;
};

export const useCareerStore = create<CareerState>()(
  persist(
    (set) => ({
      overrides: {},
      activeId: null,
      chats: {},
      advice: {},
      hydrated: false,
      setActive: (id) => set({ activeId: id }),
      saveStudent: (student) =>
        set((state) => ({
          overrides: { ...state.overrides, [student.studentId.toUpperCase()]: student },
          activeId: student.studentId.toUpperCase(),
        })),
      pushMessage: (id, message) =>
        set((state) => {
          const key = id.toUpperCase();
          const next = [...(state.chats[key] ?? []), message].slice(-30);
          return { chats: { ...state.chats, [key]: next } };
        }),
      setAdvice: (id, text) =>
        set((state) => ({ advice: { ...state.advice, [id.toUpperCase()]: text } })),
    }),
    {
      name: "careerai-store",
      skipHydration: true,
      partialize: (state) => ({
        overrides: state.overrides,
        activeId: state.activeId,
        chats: state.chats,
        advice: state.advice,
      }),
    },
  ),
);
