import { createServerFn } from "@tanstack/react-start";
import { SYSTEM_PROMPT } from "../career/prompts";

type HistoryItem = { role: "user" | "assistant"; content: string };

function cleanHistory(value: unknown): HistoryItem[] {
  if (!Array.isArray(value)) return [];
  const items: HistoryItem[] = [];
  for (const entry of value) {
    if (!entry || typeof entry !== "object") continue;
    const role = (entry as { role?: unknown }).role;
    const content = (entry as { content?: unknown }).content;
    if ((role === "user" || role === "assistant") && typeof content === "string" && content.trim()) {
      items.push({ role, content: content.trim().slice(0, 1800) });
    }
  }
  return items.slice(-6);
}

export const askCoach = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object") {
      throw new Error("Type a question before sending.");
    }
    const message = String((input as { message?: unknown }).message ?? "").trim();
    if (!message) throw new Error("Type a question before sending.");
    if (message.length > 1200) throw new Error("Please keep the question under 1200 characters.");
    const context = String((input as { context?: unknown }).context ?? "").slice(0, 7000);
    const history = cleanHistory((input as { history?: unknown }).history);
    return { message, context, history };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return {
        ok: false as const,
        error:
          "The AI Career Coach is not available in this environment. Your score, skill gaps, and roadmap still work without it.",
      };
    }

    const messages = [
      { role: "system" as const, content: SYSTEM_PROMPT },
      {
        role: "system" as const,
        content:
          data.context ||
          "No student profile was provided. Tell the student that more information is required before you can give a personal recommendation. You may still explain the project in general terms.",
      },
      ...data.history,
      { role: "user" as const, content: data.message },
    ];

    try {
      const response = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.4,
          max_tokens: 700,
          messages,
        }),
      });
      if (!response.ok) {
        return {
          ok: false as const,
          error: `The AI service returned an error (${response.status}). Please try again once.`,
        };
      }
      const body = (await response.json()) as {
        choices?: { message?: { content?: string } }[];
      };
      const text = body.choices?.[0]?.message?.content?.trim() ?? "";
      if (!text) {
        return { ok: false as const, error: "The AI returned an empty answer. Please try again." };
      }
      return { ok: true as const, text };
    } catch {
      return {
        ok: false as const,
        error: "Could not reach the AI service. Please try again in a moment.",
      };
    }
  });
