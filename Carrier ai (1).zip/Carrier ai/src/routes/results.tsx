import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ResultPanel } from "@/components/result-panel";
import { btnPrimary, cardClass } from "@/components/ui";
import { askCoach } from "@/lib/ai/coach";
import { findStudent, isAssessed, studentContext } from "@/lib/career/cohort";
import { analyzeStudent } from "@/lib/career/engine";
import { useCareerStore } from "@/lib/career/store";

export const Route = createFileRoute("/results")({ component: ResultsPage });

function ResultsPage() {
  const hydrated = useCareerStore((state) => state.hydrated);
  const activeId = useCareerStore((state) => state.activeId);
  const overrides = useCareerStore((state) => state.overrides);
  const advice = useCareerStore((state) => (activeId ? state.advice[activeId] : undefined));
  const setAdvice = useCareerStore((state) => state.setAdvice);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const student = findStudent(activeId, overrides);
  const ready = student && isAssessed(student) && student.cgpa > 0;
  const analysis = ready && student ? analyzeStudent(student) : null;

  async function generate() {
    if (!student || !analysis) return;
    setBusy(true);
    setError("");
    try {
      const result = await askCoach({
        data: {
          message:
            "Give me my full career guidance using the stored profile and the project scores. Keep each section short.",
          context: studentContext(student, analysis),
          history: [],
        },
      });
      if (!result.ok) setError(result.error);
      else setAdvice(student.studentId, result.text);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "The advice could not be generated.");
    } finally {
      setBusy(false);
    }
  }

  if (!hydrated) return <p className="text-sm text-muted">Loading your saved profile…</p>;

  if (!student || !analysis) {
    return (
      <section className={cardClass}>
        <h1 className="font-serif text-3xl">No assessment yet</h1>
        <p className="mt-2 text-muted">Complete an assessment, or open a sample profile from the home page.</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Link to="/assess" search={{ id: undefined }} className={btnPrimary}>
            Start assessment
          </Link>
          <Link to="/" className="inline-flex min-h-11 items-center text-sm font-semibold text-primary">
            Sample profiles
          </Link>
        </div>
      </section>
    );
  }

  return (
    <ResultPanel
      student={student}
      analysis={analysis}
      advice={advice}
      adviceError={error}
      adviceBusy={busy}
      onAdvice={() => void generate()}
    />
  );
}
