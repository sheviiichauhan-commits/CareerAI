import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { btnGhost, btnPrimary, cardClass, fieldClass } from "@/components/ui";
import { askCoach } from "@/lib/ai/coach";
import { FEATURED, findStudent, isAssessed, studentContext } from "@/lib/career/cohort";
import { analyzeStudent } from "@/lib/career/engine";
import { SUGGESTED_QUESTIONS } from "@/lib/career/prompts";
import { readableAnswer } from "@/lib/career/text";
import { useCareerStore } from "@/lib/career/store";

export const Route = createFileRoute("/coach")({ component: CoachPage });

function CoachPage() {
  const hydrated = useCareerStore((state) => state.hydrated);
  const activeId = useCareerStore((state) => state.activeId);
  const overrides = useCareerStore((state) => state.overrides);
  const chats = useCareerStore((state) => state.chats);
  const setActive = useCareerStore((state) => state.setActive);
  const pushMessage = useCareerStore((state) => state.pushMessage);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const student = findStudent(activeId, overrides);
  const ready = Boolean(student && isAssessed(student) && student.cgpa > 0);
  const analysis = ready && student ? analyzeStudent(student) : null;
  const thread = activeId ? (chats[activeId.toUpperCase()] ?? []) : [];

  async function send(text: string) {
    const message = text.trim();
    if (!message) {
      setError("Type a question before sending.");
      return;
    }
    if (!student) {
      setError("Open a student profile first so the coach has something to use.");
      return;
    }
    setBusy(true);
    setError("");
    setDraft("");
    try {
      const result = await askCoach({
        data: {
          message,
          context: analysis ? studentContext(student, analysis) : "Profile is registered but the assessment is not complete. Say that more information is required.",
          history: thread,
        },
      });
      if (!result.ok) {
        setDraft(message);
        setError(result.error);
        return;
      }
      pushMessage(student.studentId, { role: "user", content: message });
      pushMessage(student.studentId, { role: "assistant", content: result.text });
    } catch (caught) {
      setDraft(message);
      setError(caught instanceof Error ? caught.message : "The coach could not answer.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[16rem_1fr]">
      <aside className="grid content-start gap-3">
        <div>
          <h1 className="font-serif text-4xl">AI Career Coach</h1>
          <p className="mt-2 text-sm text-muted">
            Answers use the selected profile and the project scores. They are guidance, and they can be wrong.
          </p>
        </div>
        <label className="grid gap-1 text-sm font-medium">
          Profile
          <select
            className={fieldClass}
            value={student?.studentId ?? ""}
            onChange={(event) => setActive(event.target.value || null)}
          >
            <option value="">Select a student</option>
            {FEATURED.map((person) => (
              <option key={person.studentId} value={person.studentId}>
                {person.name}
              </option>
            ))}
            {Object.values(overrides)
              .filter((person) => person.assessed !== false)
              .map((person) => (
                <option key={person.studentId} value={person.studentId}>
                  {person.name} (saved)
                </option>
              ))}
          </select>
        </label>
        {student && analysis ? (
          <p className="rounded-md bg-primary-soft p-3 text-sm">
            {student.name}: readiness {analysis.readiness}, best match {analysis.top3[0]?.career}{" "}
            {analysis.top3[0]?.percent}%.
          </p>
        ) : (
          <p className="text-sm text-muted">
            No assessed profile selected.{" "}
            <Link to="/assess" search={{ id: undefined }} className="font-semibold text-primary">
              Complete an assessment
            </Link>
            .
          </p>
        )}
      </aside>

      <section className={`${cardClass} grid gap-4`}>
        <div className="grid max-h-[28rem] gap-3 overflow-y-auto">
          {thread.length === 0 ? (
            <p className="text-sm text-muted">
              {hydrated
                ? "Ask about careers, skills, projects, internships, or a resume. Suggested questions are below."
                : "Loading saved chat…"}
            </p>
          ) : (
            thread.map((message, index) => (
              <article
                key={`${message.role}-${index}`}
                className={
                  message.role === "user"
                    ? "max-w-2xl justify-self-end rounded-md bg-primary px-3 py-2 text-sm break-words text-primary-ink"
                    : "max-w-2xl rounded-md bg-primary-soft px-3 py-2 text-sm break-words text-ink"
                }
              >
                <p className="mb-1 text-xs font-semibold opacity-80">{message.role === "user" ? "You" : "CareerAI"}</p>
                <div className="whitespace-pre-wrap leading-relaxed">{readableAnswer(message.content)}</div>
              </article>
            ))
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          {SUGGESTED_QUESTIONS.map((question) => (
            <button
              key={question}
              type="button"
              className="min-h-11 rounded-md border border-line px-3 text-left text-sm hover:bg-primary-soft disabled:opacity-50"
              disabled={busy || !ready}
              onClick={() => void send(question)}
            >
              {question}
            </button>
          ))}
        </div>
        <form
          className="grid gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            void send(draft);
          }}
        >
          <label className="grid gap-1 text-sm font-medium">
            Your question
            <textarea
              className={`${fieldClass} min-h-24 py-2`}
              value={draft}
              maxLength={1200}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="What should I learn before an internship?"
            />
          </label>
          {error ? (
            <p className="text-sm text-gap" role="alert">
              {error}
            </p>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <button className={btnPrimary} type="submit" disabled={busy || !hydrated}>
              {busy ? "Thinking…" : "Send"}
            </button>
            <Link to="/results" className={btnGhost}>
              View score
            </Link>
          </div>
        </form>
      </section>
    </div>
  );
}
