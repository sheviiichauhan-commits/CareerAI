import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { cardClass, fieldClass } from "@/components/ui";
import { isAssessed, mergeStudents } from "@/lib/career/cohort";
import { analyzeStudent, roundPlaces } from "@/lib/career/engine";
import { useCareerStore } from "@/lib/career/store";
import { CAREERS, type StudentRecord } from "@/lib/career/types";

export const Route = createFileRoute("/admin")({ component: AdminPage });

const COLORS = [
  "var(--color-primary)",
  "var(--color-mid)",
  "var(--color-ready)",
  "var(--color-gap)",
  "var(--color-muted)",
  "var(--color-ink)",
];

const GAP_FIELDS: { key: keyof StudentRecord; label: string }[] = [
  { key: "excel", label: "Excel" },
  { key: "sql", label: "SQL" },
  { key: "python", label: "Python" },
  { key: "powerbi", label: "Power BI" },
  { key: "communication", label: "Communication" },
  { key: "dataAnalysis", label: "Data Analysis" },
];

function AdminPage() {
  const overrides = useCareerStore((state) => state.overrides);
  const [mounted, setMounted] = useState(false);
  const [department, setDepartment] = useState("All");
  const [year, setYear] = useState("All");
  const [gender, setGender] = useState("All");
  const [career, setCareer] = useState("All");

  useEffect(() => setMounted(true), []);

  const all = useMemo(() => mergeStudents(overrides).filter((student) => isAssessed(student) && student.cgpa > 0), [overrides]);
  const departments = useMemo(() => unique(all.map((student) => student.department)), [all]);
  const filtered = all.filter((student) => {
    if (department !== "All" && student.department !== department) return false;
    if (year !== "All" && String(student.year) !== year) return false;
    if (gender !== "All" && student.gender !== gender) return false;
    if (career !== "All" && student.firstChoice !== career) return false;
    return true;
  });

  const stats = useMemo(() => buildStats(filtered), [filtered]);

  return (
    <div className="grid gap-6">
      <div>
        <h1 className="font-serif text-4xl">Teacher analytics</h1>
        <p className="mt-2 max-w-3xl text-muted">
          Cohort view of the fictional students. Filters apply to every number and chart on this page. Assessments
          saved in this browser are included.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Filter label="Department" value={department} onChange={setDepartment} options={["All", ...departments]} />
        <Filter label="Year" value={year} onChange={setYear} options={["All", "1", "2", "3"]} />
        <Filter label="Gender" value={gender} onChange={setGender} options={["All", "Female", "Male", "Other", "Prefer not to say"]} />
        <Filter
          label="Career interest"
          value={career}
          onChange={setCareer}
          options={["All", ...CAREERS]}
        />
      </div>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi label="Students" value={String(stats.count)} />
        <Kpi label="Average CGPA" value={stats.avgCgpa.toFixed(2)} />
        <Kpi label="Average attendance" value={`${stats.avgAttendance.toFixed(1)}%`} />
        <Kpi label="Average career score" value={stats.avgReadiness.toFixed(1)} />
        <Kpi label="Most popular career" value={stats.popular} />
        <Kpi label="Most common skill gap" value={stats.commonGap} />
        <Kpi label="Placement percentage" value={`${stats.placement.toFixed(1)}%`} />
        <Kpi label="Highly ready" value={String(stats.highlyReady)} />
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Chart title="CGPA distribution">
          {mounted ? <ColumnChart data={stats.cgpaBins} x="band" y="students" /> : null}
        </Chart>
        <Chart title="Attendance distribution">
          {mounted ? <ColumnChart data={stats.attendanceBins} x="band" y="students" /> : null}
        </Chart>
        <Chart title="Placement status">
          {mounted ? <ShareChart data={stats.placementMix} /> : null}
        </Chart>
        <Chart title="Department performance">
          {mounted ? <ColumnChart data={stats.departments} x="name" y="cgpa" /> : null}
        </Chart>
        <Chart title="Average skill scores">
          {mounted ? <ColumnChart data={stats.skillAverages} x="skill" y="score" /> : null}
        </Chart>
        <Chart title="Students below 6 — skill gaps">
          {mounted ? <ColumnChart data={stats.gapCounts} x="skill" y="students" /> : null}
        </Chart>
        <Chart title="First-choice careers">
          {mounted ? <ColumnChart data={stats.careers} x="career" y="students" /> : null}
        </Chart>
        <Chart title="Readiness bands">
          {mounted ? <ShareChart data={stats.bands} /> : null}
        </Chart>
      </section>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">Students who may need support</h2>
        <p className="mt-1 text-sm text-muted">Lowest project scores in the current filter. Not a ranking of worth.</p>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[36rem] text-left text-sm">
            <thead className="text-muted">
              <tr className="border-b border-line">
                <th className="py-2 font-medium">Student</th>
                <th className="py-2 font-medium">Department</th>
                <th className="py-2 font-medium">Score</th>
                <th className="py-2 font-medium">Top match</th>
                <th className="py-2 font-medium">Main gap</th>
              </tr>
            </thead>
            <tbody>
              {stats.support.map((row) => (
                <tr key={row.id} className="border-b border-line">
                  <td className="py-2">
                    {row.name}
                    <span className="block text-muted">{row.id}</span>
                  </td>
                  <td className="py-2">{row.department}</td>
                  <td className="py-2 tabular-nums">{row.score}</td>
                  <td className="py-2">{row.career}</td>
                  <td className="py-2">{row.gap}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className={cardClass} id="powerbi">
        <h2 className="font-serif text-2xl">Power BI</h2>
        <p className="mt-2 text-sm text-muted">
          Power BI is a desktop tool, so it is not embedded here. Download the analytical file and build the three
          pages described in Project files. The charts above use the same columns.
        </p>
        <a className="mt-4 inline-flex min-h-11 items-center font-semibold text-primary" href="/downloads/CareerAI_Analytical.csv">
          Download Power BI dataset
        </a>
      </section>
    </div>
  );
}

function buildStats(students: StudentRecord[]) {
  const empty = {
    count: 0,
    avgCgpa: 0,
    avgAttendance: 0,
    avgReadiness: 0,
    popular: "—",
    commonGap: "—",
    placement: 0,
    highlyReady: 0,
    cgpaBins: [] as { band: string; students: number }[],
    attendanceBins: [] as { band: string; students: number }[],
    placementMix: [] as { name: string; value: number }[],
    departments: [] as { name: string; cgpa: number }[],
    skillAverages: [] as { skill: string; score: number }[],
    gapCounts: [] as { skill: string; students: number }[],
    careers: [] as { career: string; students: number }[],
    bands: [] as { name: string; value: number }[],
    support: [] as { id: string; name: string; department: string; score: number; career: string; gap: string }[],
  };
  if (!students.length) return empty;

  const analysed = students.map((student) => ({ student, analysis: analyzeStudent(student) }));
  const count = analysed.length;
  const avgCgpa = roundPlaces(analysed.reduce((sum, row) => sum + row.student.cgpa, 0) / count, 2);
  const avgAttendance = roundPlaces(analysed.reduce((sum, row) => sum + row.student.attendance, 0) / count, 1);
  const avgReadiness = roundPlaces(analysed.reduce((sum, row) => sum + row.analysis.readinessExact, 0) / count, 1);
  const popular = mode(analysed.map((row) => row.student.firstChoice));
  const gapCounts = GAP_FIELDS.map((field) => ({
    skill: field.label,
    students: analysed.filter((row) => Number(row.student[field.key]) < 6).length,
  }));
  const commonGap = [...gapCounts].sort((a, b) => b.students - a.students)[0]?.skill ?? "—";
  const known = analysed.filter((row) =>
    ["Placed", "Not Placed", "Higher Studies"].includes(row.student.placementStatus),
  );
  const placed = known.filter((row) => row.student.placementStatus === "Placed").length;
  const placement = known.length ? roundPlaces((placed / known.length) * 100, 1) : 0;
  const highlyReady = analysed.filter((row) => row.analysis.band === "Highly Ready").length;

  const cgpaOrder = ["Below 6", "6 to 7", "7 to 8", "8 to 9", "9 to 10"];
  const cgpaBins = cgpaOrder.map((band) => ({
    band,
    students: analysed.filter((row) => cgpaBand(row.student.cgpa) === band).length,
  }));
  const attendanceOrder = ["Below 75", "75 to 85", "85 to 95", "95 and above"];
  const attendanceBins = attendanceOrder.map((band) => ({
    band,
    students: analysed.filter((row) => attendanceBand(row.student.attendance) === band).length,
  }));
  const placementMix = ["Placed", "Not Placed", "Higher Studies", "In Progress"].map((name) => ({
    name,
    value: analysed.filter((row) => row.student.placementStatus === name).length,
  })).filter((row) => row.value > 0);

  const deptNames = unique(analysed.map((row) => row.student.department));
  const departments = deptNames.map((name) => {
    const rows = analysed.filter((row) => row.student.department === name);
    const cgpa = roundPlaces(rows.reduce((sum, row) => sum + row.student.cgpa, 0) / rows.length, 2);
    return { name: shortDept(name), cgpa };
  });
  const skillAverages = GAP_FIELDS.map((field) => ({
    skill: field.label === "Communication" ? "Comm." : field.label === "Data Analysis" ? "Analysis" : field.label,
    score: roundPlaces(analysed.reduce((sum, row) => sum + Number(row.student[field.key]), 0) / count, 2),
  }));
  const careerNames = unique(analysed.map((row) => row.student.firstChoice));
  const careers = careerNames.map((name) => ({
    career: name.replace(" Analyst", ""),
    students: analysed.filter((row) => row.student.firstChoice === name).length,
  }));
  const bands = ["Highly Ready", "Moderately Ready", "Needs Improvement"].map((name) => ({
    name,
    value: analysed.filter((row) => row.analysis.band === name).length,
  }));
  const support = [...analysed]
    .sort((a, b) => a.analysis.readiness - b.analysis.readiness)
    .slice(0, 6)
    .map((row) => ({
      id: row.student.studentId,
      name: row.student.name,
      department: row.student.department,
      score: row.analysis.readiness,
      career: row.analysis.top3[0]?.career ?? "—",
      gap: row.analysis.primaryGap,
    }));

  return {
    count,
    avgCgpa,
    avgAttendance,
    avgReadiness,
    popular,
    commonGap,
    placement,
    highlyReady,
    cgpaBins,
    attendanceBins,
    placementMix,
    departments,
    skillAverages,
    gapCounts,
    careers,
    bands,
    support,
  };
}

function cgpaBand(cgpa: number): string {
  if (cgpa < 6) return "Below 6";
  if (cgpa < 7) return "6 to 7";
  if (cgpa < 8) return "7 to 8";
  if (cgpa < 9) return "8 to 9";
  return "9 to 10";
}

function attendanceBand(attendance: number): string {
  if (attendance < 75) return "Below 75";
  if (attendance < 85) return "75 to 85";
  if (attendance < 95) return "85 to 95";
  return "95 and above";
}

function shortDept(name: string): string {
  if (name === "Information Technology") return "IT";
  if (name === "General Management") return "Gen. Mgmt";
  if (name === "Human Resources") return "HR";
  if (name === "Data Analytics") return "Data";
  return name;
}

function unique(values: string[]): string[] {
  return [...new Set(values.filter(Boolean))].sort();
}

function mode(values: string[]): string {
  const counts = new Map<string, number>();
  for (const value of values) counts.set(value, (counts.get(value) ?? 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "—";
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <article className={cardClass}>
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 font-serif text-2xl tabular-nums">{value}</p>
    </article>
  );
}

function Filter({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
}) {
  return (
    <label className="grid gap-1 text-sm font-medium">
      {label}
      <select className={fieldClass} value={value} onChange={(event) => onChange(event.target.value)}>
        {options.map((option) => (
          <option key={option}>{option}</option>
        ))}
      </select>
    </label>
  );
}

function Chart({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className={cardClass}>
      <h2 className="font-serif text-xl">{title}</h2>
      <div className="mt-3 h-64 w-full">{children}</div>
    </section>
  );
}

function ColumnChart({ data, x, y }: { data: object[]; x: string; y: string }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 8 }}>
        <CartesianGrid stroke="var(--color-line)" vertical={false} />
        <XAxis dataKey={x} tick={{ fill: "var(--color-muted)", fontSize: 11 }} interval={0} angle={-20} height={48} textAnchor="end" />
        <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
        <Tooltip />
        <Bar dataKey={y} fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function ShareChart({ data }: { data: { name: string; value: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius={48} outerRadius={76} paddingAngle={2}>
          {data.map((entry, index) => (
            <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Legend />
        <Tooltip />
      </PieChart>
    </ResponsiveContainer>
  );
}
