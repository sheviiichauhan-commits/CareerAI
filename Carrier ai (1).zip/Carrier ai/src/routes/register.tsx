import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { btnPrimary, cardClass, fieldClass, labelClass } from "@/components/ui";
import { findStudent } from "@/lib/career/cohort";
import { useCareerStore } from "@/lib/career/store";
import type { StudentRecord } from "@/lib/career/types";

export const Route = createFileRoute("/register")({ component: RegisterPage });

const COURSES = ["BBA", "B.Com", "BCA"];
const DEPARTMENTS = [
  "Marketing",
  "Finance",
  "Human Resources",
  "Operations",
  "Accounting",
  "General Management",
  "Information Technology",
  "Data Analytics",
];
const GENDERS = ["Female", "Male", "Other", "Prefer not to say"];

type FormState = {
  studentId: string;
  name: string;
  age: string;
  gender: string;
  course: string;
  year: string;
  semester: string;
  department: string;
  email: string;
};

const EMPTY: FormState = {
  studentId: "",
  name: "",
  age: "",
  gender: "",
  course: "",
  year: "",
  semester: "",
  department: "",
  email: "",
};

function RegisterPage() {
  const navigate = useNavigate();
  const hydrated = useCareerStore((state) => state.hydrated);
  const overrides = useCareerStore((state) => state.overrides);
  const saveStudent = useCareerStore((state) => state.saveStudent);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [existing, setExisting] = useState<StudentRecord | null>(null);

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function suggestId() {
    const stamp = String(Date.now()).slice(-4);
    set("studentId", `CAIU${stamp}`);
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    const next = validate(form);
    setErrors(next);
    if (Object.keys(next).length) return;
    const id = form.studentId.trim().toUpperCase();
    const already = findStudent(id, overrides);
    if (already?.assessed !== false && already) {
      setExisting(already);
      return;
    }
    const student: StudentRecord = {
      studentId: id,
      name: form.name.trim(),
      age: Number(form.age),
      gender: form.gender,
      course: form.course,
      year: Number(form.year),
      semester: Number(form.semester),
      department: form.department,
      email: form.email.trim(),
      cgpa: 0,
      attendance: 0,
      backlogs: 0,
      internships: 0,
      certifications: 0,
      excel: 1,
      sql: 1,
      python: 1,
      powerbi: 1,
      communication: 1,
      dataAnalysis: 1,
      interests: [],
      firstChoice: "",
      secondChoice: "",
      placementStatus: "In Progress",
      packageLpa: null,
      assessed: false,
    };
    saveStudent(student);
    void navigate({ to: "/assess", search: { id } });
  }

  return (
    <div className="mx-auto grid max-w-3xl gap-6">
      <div>
        <h1 className="font-serif text-4xl">Student registration</h1>
        <p className="mt-2 text-muted">
          This project uses sample data. Do not enter a real address, phone number, or another person’s private
          information. A demo email such as priya@demo.careerai.edu is enough.
        </p>
      </div>
      <form onSubmit={submit} className={`${cardClass} grid gap-4`} noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className={labelClass}>
            Student ID
            <input className={fieldClass} value={form.studentId} onChange={(event) => set("studentId", event.target.value)} placeholder="CAIU1024" />
            <FieldError message={errors.studentId} />
          </label>
          <div className="flex items-end">
            <button type="button" className="min-h-11 text-sm font-semibold text-primary" onClick={suggestId}>
              Suggest a demo ID
            </button>
          </div>
          <label className={`${labelClass} sm:col-span-2`}>
            Name
            <input className={fieldClass} value={form.name} onChange={(event) => set("name", event.target.value)} />
            <FieldError message={errors.name} />
          </label>
          <label className={labelClass}>
            Age
            <input className={fieldClass} inputMode="numeric" value={form.age} onChange={(event) => set("age", event.target.value)} />
            <FieldError message={errors.age} />
          </label>
          <label className={labelClass}>
            Gender
            <select className={fieldClass} value={form.gender} onChange={(event) => set("gender", event.target.value)}>
              <option value="">Select</option>
              {GENDERS.map((gender) => (
                <option key={gender}>{gender}</option>
              ))}
            </select>
            <FieldError message={errors.gender} />
          </label>
          <label className={labelClass}>
            Course
            <select className={fieldClass} value={form.course} onChange={(event) => set("course", event.target.value)}>
              <option value="">Select</option>
              {COURSES.map((course) => (
                <option key={course}>{course}</option>
              ))}
            </select>
            <FieldError message={errors.course} />
          </label>
          <label className={labelClass}>
            Department
            <select className={fieldClass} value={form.department} onChange={(event) => set("department", event.target.value)}>
              <option value="">Select</option>
              {DEPARTMENTS.map((department) => (
                <option key={department}>{department}</option>
              ))}
            </select>
            <FieldError message={errors.department} />
          </label>
          <label className={labelClass}>
            Year
            <select className={fieldClass} value={form.year} onChange={(event) => set("year", event.target.value)}>
              <option value="">Select</option>
              {[1, 2, 3].map((year) => (
                <option key={year} value={year}>
                  Year {year}
                </option>
              ))}
            </select>
            <FieldError message={errors.year} />
          </label>
          <label className={labelClass}>
            Semester
            <select className={fieldClass} value={form.semester} onChange={(event) => set("semester", event.target.value)}>
              <option value="">Select</option>
              {[1, 2, 3, 4, 5, 6].map((semester) => (
                <option key={semester} value={semester}>
                  Semester {semester}
                </option>
              ))}
            </select>
            <FieldError message={errors.semester} />
          </label>
          <label className={`${labelClass} sm:col-span-2`}>
            Email
            <input className={fieldClass} type="email" value={form.email} onChange={(event) => set("email", event.target.value)} placeholder="name@demo.careerai.edu" />
            <FieldError message={errors.email} />
          </label>
        </div>
        {existing ? (
          <div className="rounded-md bg-mid-soft p-3 text-sm text-mid">
            {existing.studentId} is already in the demo cohort ({existing.name}). Open the assessment to review it,
            or choose a new ID.
            <div className="mt-2">
              <Link to="/assess" search={{ id: existing.studentId }} className="font-semibold text-primary">
                Continue to assessment
              </Link>
            </div>
          </div>
        ) : null}
        <button className={btnPrimary} type="submit" disabled={!hydrated}>
          Save and continue to assessment
        </button>
        <p className="text-xs text-muted">
          Saved in this browser for the demonstration. The MySQL script in Project files shows how the same record
          would be stored in a database.
        </p>
      </form>
    </div>
  );
}

function validate(form: FormState): Record<string, string> {
  const errors: Record<string, string> = {};
  const id = form.studentId.trim();
  if (!/^[A-Za-z0-9-]{4,16}$/.test(id)) {
    errors.studentId = "Use 4–16 letters or numbers. Example: CAIU1024.";
  }
  if (form.name.trim().length < 3) errors.name = "Enter a name with at least 3 characters.";
  const age = Number(form.age);
  if (!form.age || Number.isNaN(age) || age < 16 || age > 40) errors.age = "Enter an age from 16 to 40.";
  if (!form.gender) errors.gender = "Select a gender option.";
  if (!form.course) errors.course = "Select a course.";
  if (!form.department) errors.department = "Select a department.";
  if (!form.year) errors.year = "Select a year.";
  if (!form.semester) errors.semester = "Select a semester.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
    errors.email = "Enter an email like name@demo.careerai.edu.";
  }
  return errors;
}

function FieldError({ message }: { message?: string }) {
  if (!message) return null;
  return <span className="text-xs font-normal text-gap">{message}</span>;
}
