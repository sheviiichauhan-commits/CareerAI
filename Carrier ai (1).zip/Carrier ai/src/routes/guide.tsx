import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { btnGhost, btnPrimary, cardClass } from "@/components/ui";
import { SLIDES, VIVA } from "@/lib/career/guide";

export const Route = createFileRoute("/guide")({ component: GuidePage });

function GuidePage() {
  const [index, setIndex] = useState(0);
  const [showSay, setShowSay] = useState(true);
  const [tab, setTab] = useState<"slides" | "viva">("slides");
  const slide = SLIDES[index] ?? SLIDES[0];

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-serif text-4xl">Presentation and viva</h1>
          <p className="mt-2 text-muted">Fifteen slides and twenty short answers. Speak in your own words.</p>
        </div>
        <div className="flex gap-2">
          <button type="button" className={tab === "slides" ? btnPrimary : btnGhost} onClick={() => setTab("slides")}>
            Slides
          </button>
          <button type="button" className={tab === "viva" ? btnPrimary : btnGhost} onClick={() => setTab("viva")}>
            Viva
          </button>
        </div>
      </div>

      {tab === "slides" && slide ? (
        <section className={cardClass}>
          <p className="text-sm text-muted">
            Slide {index + 1} of {SLIDES.length}
          </p>
          <h2 className="mt-2 font-serif text-3xl">{slide.title}</h2>
          <ul className="mt-4 list-disc space-y-2 pl-5">
            {slide.bullets.map((bullet) => (
              <li key={bullet}>{bullet}</li>
            ))}
          </ul>
          {showSay ? (
            <p className="mt-4 rounded-md bg-primary-soft p-3 text-sm">
              <span className="font-semibold">What to say. </span>
              {slide.say}
            </p>
          ) : null}
          <div className="mt-4 flex flex-wrap gap-2">
            <button type="button" className={btnGhost} disabled={index === 0} onClick={() => setIndex((value) => value - 1)}>
              Previous
            </button>
            <button
              type="button"
              className={btnPrimary}
              disabled={index === SLIDES.length - 1}
              onClick={() => setIndex((value) => value + 1)}
            >
              Next
            </button>
            <button type="button" className={btnGhost} onClick={() => setShowSay((value) => !value)}>
              {showSay ? "Hide speaker notes" : "Show speaker notes"}
            </button>
          </div>
        </section>
      ) : (
        <div className="grid gap-3">
          {VIVA.map((item, vivaIndex) => (
            <article key={item.question} className={cardClass}>
              <h2 className="font-serif text-xl">
                {vivaIndex + 1}. {item.question}
              </h2>
              <p className="mt-2 text-sm">{item.answer}</p>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
