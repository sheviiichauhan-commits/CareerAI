import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { cardClass } from "@/components/ui";
import { DATASET } from "@/lib/career/cohort";
import { WEIGHTS, analyzeStudent } from "@/lib/career/engine";
import { SYSTEM_PROMPT } from "@/lib/career/prompts";
import { CAREERS } from "@/lib/career/types";

export const Route = createFileRoute("/project")({ component: ProjectPage });

const DOWNLOADS = [
  ["CareerAI_Student_Data.xlsx", "Excel workbook — 320 fictional students, 5 sheets"],
  ["CareerAI_Analytical.csv", "Flat file for Power BI, including scores and gaps"],
  ["schema.sql", "MySQL database careerai_db"],
  ["queries.sql", "Ten commented queries"],
  ["seed_demo_20.sql", "First 20 students, for a quick SQL demo"],
];

function ProjectPage() {
  const example = DATASET[0];
  const analysis = example ? analyzeStudent(example) : null;
  const [sql, setSql] = useState("Loading queries…");

  useEffect(() => {
    void fetch("/downloads/queries.sql")
      .then((response) => (response.ok ? response.text() : "Query file is not available."))
      .then(setSql)
      .catch(() => setSql("Query file could not be loaded."));
  }, []);

  return (
    <div className="grid gap-6">
      <div>
        <h1 className="font-serif text-4xl">Project files</h1>
        <p className="mt-2 max-w-3xl text-muted">
          The website, the Excel file, the SQL, and the Python programs are one project. They share the same
          readiness formula and the same career weights.
        </p>
      </div>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">Data flow</h2>
        <ol className="mt-4 grid gap-2 text-sm">
          {[
            "Excel holds the fictional students on five sheets.",
            "Python cleaning removes duplicate IDs, fixes types, fills gaps, and clips impossible scores.",
            "MySQL stores Students, Academic, Skills, Career_Interest, and Placement.",
            "Pandas calculates averages, placement, and preferences.",
            "The readiness function turns six inputs into a 0–100 score.",
            "The recommendation function scores sixteen careers and keeps the top three.",
            "The analytical CSV is the Power BI dataset.",
            "The AI coach receives the saved profile plus these scores, inside a fixed system prompt.",
          ].map((step, index) => (
            <li key={step} className="rounded-md bg-primary-soft px-3 py-2">
              <span className="mr-2 font-semibold text-primary">{index + 1}</span>
              {step}
            </li>
          ))}
        </ol>
      </section>

      {example && analysis ? (
        <section className={cardClass}>
          <h2 className="font-serif text-2xl">Worked score — {example.name}</h2>
          <p className="mt-1 text-sm text-muted">
            Same person as the home page. Exact total {analysis.readinessExact}, displayed score {analysis.readiness}{" "}
            ({analysis.band}).
          </p>
          <ul className="mt-3 grid gap-1 text-sm">
            {analysis.breakdown.map((part) => (
              <li key={part.key} className="flex justify-between gap-3 border-b border-line py-1">
                <span>
                  {part.label} ({part.weight})
                </span>
                <span className="tabular-nums">
                  {part.points} / {part.max}
                </span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">Career skill weights</h2>
        <p className="mt-1 text-sm text-muted">
          Each row sums to 100% of skill fit. Match percentage is 78% skill fit and 22% interest fit. Interest fit is
          100 for the first choice, 80 for the second, 65 for another selected interest, and 40 otherwise. Analytical
          ability is 70% data analysis and 30% CGPA.
        </p>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[44rem] text-left text-xs sm:text-sm">
            <thead className="text-muted">
              <tr>
                <th className="py-2 font-medium">Career</th>
                {["Excel", "SQL", "Python", "Power BI", "Analysis", "Comm.", "Analytical", "CGPA"].map((label) => (
                  <th key={label} className="py-2 font-medium">
                    {label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {CAREERS.map((career) => {
                const weights = WEIGHTS[career];
                const cells = [
                  weights.excel,
                  weights.sql,
                  weights.python,
                  weights.powerbi,
                  weights.dataAnalysis,
                  weights.communication,
                  weights.analytical,
                  weights.cgpa,
                ];
                return (
                  <tr key={career} className="border-t border-line">
                    <td className="py-2">{career}</td>
                    {cells.map((value, index) => (
                      <td key={index} className="py-2 tabular-nums">
                        {value ? Math.round(value * 100) : "—"}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">Downloads</h2>
        <ul className="mt-3 grid gap-2 text-sm">
          {DOWNLOADS.map(([file, label]) => (
            <li key={file}>
              <a className="font-semibold text-primary" href={`/downloads/${file}`}>
                {file}
              </a>
              <span className="block text-muted">{label}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">Power BI pages</h2>
        <div className="mt-3 grid gap-3 text-sm md:grid-cols-3">
          <article>
            <h3 className="font-serif text-lg">Student overview</h3>
            <p className="text-muted">Cards for students, CGPA, attendance, placement, and readiness. Charts for CGPA, attendance, placement, and department.</p>
          </article>
          <article>
            <h3 className="font-serif text-lg">Skill analytics</h3>
            <p className="text-muted">Average of each skill and a count of scores below 6. Python is the most common gap in this sample.</p>
          </article>
          <article>
            <h3 className="font-serif text-lg">Career analytics</h3>
            <p className="text-muted">First-choice careers, match columns, readiness bands, and placement by interest. Slicers: department, year, gender, career.</p>
          </article>
        </div>
        <ol className="mt-4 list-decimal space-y-1 pl-5 text-sm text-muted">
          <li>Open Power BI Desktop.</li>
          <li>Get data from Text/CSV and choose CareerAI_Analytical.csv. Or use MySQL with the schema and import script.</li>
          <li>Build the three pages. Put Department, Year, Gender, and First_Choice on slicers.</li>
        </ol>
      </section>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">SQL queries</h2>
        <pre className="mt-3 max-h-[28rem] overflow-auto rounded-md bg-primary-soft p-3 text-xs leading-relaxed whitespace-pre-wrap">
          {sql}
        </pre>
      </section>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">Coach system prompt</h2>
        <pre className="mt-3 overflow-auto rounded-md bg-primary-soft p-3 text-xs leading-relaxed whitespace-pre-wrap">
          {SYSTEM_PROMPT}
        </pre>
      </section>
    </div>
  );
}
