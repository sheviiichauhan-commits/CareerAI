import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Database, FileSpreadsheet, LineChart, MessagesSquare, ShieldCheck, Waypoints } from "lucide-react";
import type { ReactNode } from "react";
import { ScoreRing } from "@/components/score-ring";
import { btnGhost, btnPrimary, cardClass } from "@/components/ui";
import { DATASET, FEATURED } from "@/lib/career/cohort";
import { analyzeStudent } from "@/lib/career/engine";
import { useCareerStore } from "@/lib/career/store";
import { CAREERS } from "@/lib/career/types";

export const Route = createFileRoute("/")({ component: Home });

const example = DATASET[0];
const exampleAnalysis = example ? analyzeStudent(example) : null;

function Home() {
  const hydrated = useCareerStore((state) => state.hydrated);
  const setActive = useCareerStore((state) => state.setActive);
  const navigate = useNavigate();

  function openProfile(id: string) {
    setActive(id);
    void navigate({ to: "/results" });
  }

  return (
    <div className="grid gap-12">
      <section className="grid items-center gap-8 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="grid gap-4">
          <div className="max-w-xl rounded-lg bg-primary-soft px-4 py-3 shadow-card">
            <p className="text-sm leading-snug">
              <span className="font-semibold text-primary">Made by</span>
              <span className="mt-1 block font-serif text-lg font-semibold tracking-wide text-ink">
                SHIVANI SINGH
              </span>
              <span className="mt-1 block text-xs font-medium text-muted">(BBA) Final Year student</span>
              <span className="block text-xs font-medium text-muted">School of Business Management (SBM)</span>
              <span className="block text-xs font-semibold tracking-wide text-ink">
                CHHATRAPATI SHAHU JI MAHARAJ UNIVERSITY KANPUR
              </span>
            </p>
          </div>
          <h1 className="font-serif text-4xl leading-tight text-ink sm:text-5xl">
            Understand your skills. Discover your career. Build your future.
          </h1>
          <p className="max-w-xl text-base text-muted">
            CareerAI turns CGPA, attendance, skills, internships, and interests into a readiness score, three
            career matches, skill gaps, projects, and a 30-day plan. A teacher view summarises the whole cohort.
          </p>
          <div className="flex flex-wrap gap-2">
            <Link to="/assess" search={{ id: undefined }} className={btnPrimary}>
              Start career assessment
            </Link>
            <Link to="/coach" className={btnGhost}>
              AI Career Coach
            </Link>
            <Link to="/admin" className={btnGhost}>
              View dashboard
            </Link>
          </div>
        </div>
        {example && exampleAnalysis ? (
          <aside className={cardClass}>
            <p className="text-xs font-semibold tracking-wide text-primary uppercase">Worked example</p>
            <h2 className="mt-2 font-serif text-2xl">{example.name}</h2>
            <p className="text-sm text-muted">
              {example.course} · {example.department} · sample profile {example.studentId}
            </p>
            <div className="mt-4 flex items-center gap-4">
              <ScoreRing value={exampleAnalysis.readiness} caption={exampleAnalysis.band} />
              <ul className="grid flex-1 gap-2 text-sm">
                {exampleAnalysis.top3.map((match) => (
                  <li key={match.career} className="flex justify-between gap-3 border-b border-line pb-2">
                    <span>{match.career}</span>
                    <span className="tabular-nums font-semibold">{match.percent}%</span>
                  </li>
                ))}
              </ul>
            </div>
            <button
              type="button"
              className={`${btnPrimary} mt-4 w-full`}
              disabled={!hydrated}
              onClick={() => openProfile(example.studentId)}
            >
              Open this sample profile
            </button>
          </aside>
        ) : null}
      </section>

      <section className="grid gap-3 sm:grid-cols-3">
        <Stat label="Fictional students" value={String(DATASET.length)} />
        <Stat label="Career paths scored" value={String(CAREERS.length)} />
        <Stat label="What the score is" value="Classroom model" />
      </section>

      <section>
        <h2 className="font-serif text-3xl">What you can do</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <Feature icon={<LineChart className="size-5" />} title="Readiness score" text="A transparent 0–100 score from CGPA, skills, communication, attendance, internships, and certificates." />
          <Feature icon={<Waypoints className="size-5" />} title="Career matches" text="Analytics, business, finance, marketing, operations, and software roles. The top three are called out." />
          <Feature icon={<MessagesSquare className="size-5" />} title="AI Career Coach" text="Ask follow-up questions. The coach sees the saved profile and the scores already calculated." />
          <Feature icon={<FileSpreadsheet className="size-5" />} title="Excel cohort" text="320 invented student records, split into the five sheets a college project would clean and load." />
          <Feature icon={<Database className="size-5" />} title="SQL and Python" text="MySQL schema, commented queries, and Pandas modules that use the same formulas as this website." />
          <Feature icon={<ShieldCheck className="size-5" />} title="Teacher view" text="Averages, skill gaps, placement mix, and a file you can open in Power BI." />
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <div className={cardClass}>
          <h2 className="font-serif text-2xl">How it works</h2>
          <ol className="mt-4 grid gap-3 text-sm">
            {[
              "Register with a demo ID. Do not use a real student's private details.",
              "Rate skills from 1 to 10 and choose two career interests.",
              "The app saves the profile in this browser and runs the scoring rules.",
              "Read the score, gaps, and roadmap, then ask the coach a specific question.",
            ].map((step, index) => (
              <li key={step} className="flex gap-3">
                <span className="font-serif text-lg text-primary">0{index + 1}</span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </div>
        <div className={cardClass}>
          <h2 className="font-serif text-2xl">Try a classroom profile</h2>
          <ul className="mt-4 grid gap-2">
            {FEATURED.map((person) => (
              <li key={person.studentId}>
                <button
                  type="button"
                  disabled={!hydrated}
                  onClick={() => openProfile(person.studentId)}
                  className="flex min-h-11 w-full items-center justify-between rounded-lg px-3 text-left text-sm transition-colors duration-150 hover:bg-primary-soft disabled:opacity-50"
                >
                  <span>
                    {person.name}
                    <span className="block text-muted">{person.note}</span>
                  </span>
                  <span className="text-muted">{person.studentId}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">Technology path</h2>
        <p className="mt-2 text-sm text-muted">
          One pipeline, not seven separate assignments. This website is the working front end. The Excel, SQL,
          Python, and Power BI files use the same rules.
        </p>
        <ol className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
          {[
            "Excel — fictional student workbook",
            "Cleaning — duplicates, types, impossible scores",
            "MySQL — five related tables",
            "Python and Pandas — cohort statistics",
            "Readiness score — published weights",
            "Recommendation rules — skill fit plus interest",
            "Power BI — three dashboard pages from the CSV",
            "AI coach — structured prompt plus the saved profile",
          ].map((item, index) => (
            <li key={item} className="rounded-md bg-primary-soft px-3 py-2">
              <span className="mr-2 font-semibold text-primary">{index + 1}</span>
              {item}
            </li>
          ))}
        </ol>
        <Link to="/project" className={`${btnGhost} mt-4`}>
          Open project files and formulas
        </Link>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className={cardClass}>
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 font-serif text-2xl">{value}</p>
    </div>
  );
}

function Feature({ icon, title, text }: { icon: ReactNode; title: string; text: string }) {
  return (
    <article className={cardClass}>
      <div className="grid size-10 place-items-center rounded-md bg-primary-soft text-primary">{icon}</div>
      <h3 className="mt-3 font-serif text-xl">{title}</h3>
      <p className="mt-1 text-sm text-muted">{text}</p>
    </article>
  );
}
