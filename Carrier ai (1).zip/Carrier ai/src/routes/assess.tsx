import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { btnPrimary, cardClass, fieldClass, labelClass } from "@/components/ui";
import { findStudent } from "@/lib/career/cohort";
import { useCareerStore } from "@/lib/career/store";
import { CAREER_GROUPS, type StudentRecord } from "@/lib/career/types";

export const Route = createFileRoute("/assess")({
  validateSearch: (search: Record<string, unknown>) => ({
    id: typeof search.id === "string" ? search.id : undefined,
  }),
  component: AssessPage,
});

const SKILLS = [
  ["excel", "Excel"],
  ["sql", "SQL"],
  ["python", "Python"],
  ["powerbi", "Power BI"],
  ["dataAnalysis", "Data Analysis"],
  ["communication", "Communication"],
] as const;

type SkillKey = (typeof SKILLS)[number][0];

type FormState = {
  cgpa: string;
  attendance: string;
  backlogs: string;
  internships: string;
  certifications: string;
  skills: Record<SkillKey, number>;
  interests: string[];
  firstChoice: string;
  secondChoice: string;
};

const DEFAULT_SKILLS: Record<SkillKey, number> = {
  excel: 5,
  sql: 5,
  python: 5,
  powerbi: 5,
  dataAnalysis: 5,
  communication: 5,
};

function blankForm(): FormState {
  return {
    cgpa: "",
    attendance: "",
    backlogs: "",
    internships: "",
    certifications: "",
    skills: { ...DEFAULT_SKILLS },
    interests: [],
    firstChoice: "",
    secondChoice: "",
  };
}

function AssessPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const hydrated = useCareerStore((state) => state.hydrated);
  const overrides = useCareerStore((state) => state.overrides);
  const activeId = useCareerStore((state) => state.activeId);
  const saveStudent = useCareerStore((state) => state.saveStudent);
  const [form, setForm] = useState<FormState>(blankForm);
  const [errors, setErrors] = useState<string[]>([]);
  const [loadedId, setLoadedId] = useState<string | null>(null);

  const requestedId = (search.id ?? activeId ?? "").toUpperCase();
  const student = hydrated ? findStudent(requestedId, overrides) : undefined;

  useEffect(() => {
    if (!hydrated || !student || student.studentId === loadedId) return;
    if (student.assessed === false) {
      setForm(blankForm());
    } else {
      setForm({
        cgpa: String(student.cgpa),
        attendance: String(student.attendance),
        backlogs: String(student.backlogs),
        internships: String(student.internships),
        certifications: String(student.certifications),
        skills: {
          excel: student.excel,
          sql: student.sql,
          python: student.python,
          powerbi: student.powerbi,
          dataAnalysis: student.dataAnalysis,
          communication: student.communication,
        },
        interests: student.interests.length ? student.interests : [student.firstChoice, student.secondChoice].filter(Boolean),
        firstChoice: student.firstChoice,
        secondChoice: student.secondChoice,
      });
    }
    setLoadedId(student.studentId);
  }, [hydrated, student, loadedId]);

  function toggleInterest(career: string) {
    setForm((current) => {
      const has = current.interests.includes(career);
      return {
        ...current,
        interests: has ? current.interests.filter((item) => item !== career) : [...current.interests, career],
      };
    });
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    if (!student) {
      setErrors(["Register a student ID before the assessment, or open a sample profile from the home page."]);
      return;
    }
    const nextErrors = validateAssessment(form);
    setErrors(nextErrors);
    if (nextErrors.length) return;
    const interests = Array.from(new Set([...form.interests, form.firstChoice, form.secondChoice]));
    const updated: StudentRecord = {
      ...student,
      studentId: student.studentId.toUpperCase(),
      cgpa: Number(form.cgpa),
      attendance: Number(form.attendance),
      backlogs: Number(form.backlogs),
      internships: Number(form.internships),
      certifications: Number(form.certifications),
      excel: form.skills.excel,
      sql: form.skills.sql,
      python: form.skills.python,
      powerbi: form.skills.powerbi,
      dataAnalysis: form.skills.dataAnalysis,
      communication: form.skills.communication,
      interests,
      firstChoice: form.firstChoice,
      secondChoice: form.secondChoice,
      assessed: true,
    };
    saveStudent(updated);
    void navigate({ to: "/results" });
  }

  return (
    <div className="mx-auto grid max-w-3xl gap-6">
      <div>
        <h1 className="font-serif text-4xl">Career assessment</h1>
        <p className="mt-2 text-muted">
          CGPA uses a 10-point scale. Skill ratings are 1 to 10. The score that follows is a classroom model, not a
          prediction of a job offer.
        </p>
      </div>

      {!hydrated ? <p className="text-sm text-muted">Loading saved profiles…</p> : null}

      {hydrated && !student ? (
        <div className={cardClass}>
          <p>No student is selected. Register first, or open a sample profile.</p>
          <div className="mt-3 flex flex-wrap gap-3 text-sm font-semibold">
            <Link to="/register" className="text-primary">
              Register
            </Link>
            <Link to="/assess" search={{ id: "CAI24001" }} className="text-primary">
              Load Aanya Deshmukh (CAI24001)
            </Link>
            <Link to="/assess" search={{ id: "CAI24006" }} className="text-primary">
              Load Rohan Das (CAI24006)
            </Link>
          </div>
        </div>
      ) : null}

      {student ? (
        <form onSubmit={submit} className="grid gap-4" noValidate>
          <section className={cardClass}>
            <h2 className="font-serif text-2xl">Student</h2>
            <p className="mt-1 text-sm">
              {student.name} · {student.studentId} · {student.course} · {student.department}
            </p>
            {student.placementStatus !== "In Progress" ? (
              <p className="mt-2 text-sm text-muted">
                This ID is in the shared sample. Submitting updates the copy in your browser. The Excel file is not
                changed.
              </p>
            ) : null}
          </section>

          <section className={cardClass}>
            <h2 className="font-serif text-2xl">Academic information</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <NumberField label="CGPA (0–10)" value={form.cgpa} onChange={(value) => setForm({ ...form, cgpa: value })} step="0.1" />
              <NumberField label="Attendance %" value={form.attendance} onChange={(value) => setForm({ ...form, attendance: value })} />
              <NumberField label="Number of backlogs" value={form.backlogs} onChange={(value) => setForm({ ...form, backlogs: value })} />
              <NumberField label="Internships completed" value={form.internships} onChange={(value) => setForm({ ...form, internships: value })} />
              <NumberField label="Number of certifications" value={form.certifications} onChange={(value) => setForm({ ...form, certifications: value })} />
            </div>
          </section>

          <section className={cardClass}>
            <h2 className="font-serif text-2xl">Technical and communication skills</h2>
            <p className="mt-1 text-sm text-muted">1 is a beginner. 10 is confident enough to use the skill in a project.</p>
            <div className="mt-4 grid gap-4">
              {SKILLS.map(([key, label]) => (
                <label key={key} className="grid gap-1 text-sm font-medium">
                  <span className="flex justify-between">
                    {label}
                    <span className="tabular-nums">{form.skills[key]}/10</span>
                  </span>
                  <input
                    type="range"
                    min={1}
                    max={10}
                    step={1}
                    value={form.skills[key]}
                    onChange={(event) =>
                      setForm({ ...form, skills: { ...form.skills, [key]: Number(event.target.value) } })
                    }
                  />
                </label>
              ))}
            </div>
          </section>

          <section className={cardClass}>
            <h2 className="font-serif text-2xl">Career interests</h2>
            <div className="mt-3 grid gap-4">
              {CAREER_GROUPS.map((group) => (
                <div key={group.stream}>
                  <p className="text-xs font-semibold tracking-wide text-primary uppercase">{group.stream}</p>
                  <div className="mt-2 grid gap-2 sm:grid-cols-2">
                    {group.careers.map((career) => (
                      <label key={career} className="flex min-h-11 items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={form.interests.includes(career)}
                          onChange={() => toggleInterest(career)}
                        />
                        {career}
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <label className={labelClass}>
                First career choice
                <select className={fieldClass} value={form.firstChoice} onChange={(event) => setForm({ ...form, firstChoice: event.target.value })}>
                  <option value="">Select</option>
                  {CAREER_GROUPS.map((group) => (
                    <optgroup key={group.stream} label={group.stream}>
                      {group.careers.map((career) => (
                        <option key={career}>{career}</option>
                      ))}
                    </optgroup>
                  ))}
                </select>
              </label>
              <label className={labelClass}>
                Second career choice
                <select className={fieldClass} value={form.secondChoice} onChange={(event) => setForm({ ...form, secondChoice: event.target.value })}>
                  <option value="">Select</option>
                  {CAREER_GROUPS.map((group) => (
                    <optgroup key={group.stream} label={group.stream}>
                      {group.careers.map((career) => (
                        <option key={career}>{career}</option>
                      ))}
                    </optgroup>
                  ))}
                </select>
              </label>
            </div>
          </section>

          {errors.length ? (
            <div className="rounded-md bg-gap-soft p-3 text-sm text-gap" role="alert">
              <ul className="list-disc pl-4">
                {errors.map((error) => (
                  <li key={error}>{error}</li>
                ))}
              </ul>
            </div>
          ) : null}

          <button type="submit" className={btnPrimary}>
            Analyze my profile
          </button>
        </form>
      ) : null}
    </div>
  );
}

function NumberField({
  label,
  value,
  onChange,
  step,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  step?: string;
}) {
  return (
    <label className={labelClass}>
      {label}
      <input className={fieldClass} inputMode="decimal" step={step} value={value} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
}

function validateAssessment(form: FormState): string[] {
  const errors: string[] = [];
  const cgpa = Number(form.cgpa);
  if (form.cgpa.trim() === "" || Number.isNaN(cgpa) || cgpa < 0 || cgpa > 10) {
    errors.push("Enter CGPA from 0 to 10. This project does not use a 4-point scale.");
  } else if (cgpa > 0 && cgpa <= 4) {
    errors.push("CGPA is on a 10-point scale. If your mark is out of 4, convert it first. For example, 3.2 out of 4 is about 8.0 out of 10.");
  }
  const attendance = Number(form.attendance);
  if (form.attendance.trim() === "" || Number.isNaN(attendance) || attendance < 0 || attendance > 100) {
    errors.push("Attendance must be between 0 and 100.");
  }
  const backlogs = Number(form.backlogs);
  if (form.backlogs.trim() === "" || !Number.isInteger(backlogs) || backlogs < 0 || backlogs > 20) {
    errors.push("Backlogs must be a whole number from 0 to 20.");
  }
  const internships = Number(form.internships);
  if (form.internships.trim() === "" || !Number.isInteger(internships) || internships < 0 || internships > 10) {
    errors.push("Internships must be a whole number from 0 to 10.");
  }
  const certifications = Number(form.certifications);
  if (form.certifications.trim() === "" || !Number.isInteger(certifications) || certifications < 0 || certifications > 20) {
    errors.push("Certifications must be a whole number from 0 to 20.");
  }
  for (const [key, label] of SKILLS) {
    const score = form.skills[key];
    if (!Number.isInteger(score) || score < 1 || score > 10) {
      errors.push(`${label} must be a whole number from 1 to 10.`);
    }
  }
  if (!form.firstChoice || !form.secondChoice) errors.push("Select a first and a second career choice.");
  if (form.firstChoice && form.firstChoice === form.secondChoice) {
    errors.push("First and second career choices must be different.");
  }
  if (form.interests.length === 0 && !form.firstChoice) {
    errors.push("Select at least one career interest.");
  }
  return errors;
}
