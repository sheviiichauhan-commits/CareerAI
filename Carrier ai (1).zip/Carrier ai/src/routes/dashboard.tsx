import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ScoreRing } from "@/components/score-ring";
import { btnGhost, btnPrimary, cardClass } from "@/components/ui";
import { FEATURED, findStudent, isAssessed } from "@/lib/career/cohort";
import { analyzeStudent, bandTone } from "@/lib/career/engine";
import { useCareerStore } from "@/lib/career/store";

export const Route = createFileRoute("/dashboard")({ component: DashboardPage });

const BAND_CLASS = {
  ready: "bg-ready-soft text-ready",
  mid: "bg-mid-soft text-mid",
  gap: "bg-gap-soft text-gap",
} as const;

function DashboardPage() {
  const hydrated = useCareerStore((state) => state.hydrated);
  const activeId = useCareerStore((state) => state.activeId);
  const overrides = useCareerStore((state) => state.overrides);
  const setActive = useCareerStore((state) => state.setActive);
  const [mounted, setMounted] = useState(false);
  const [lookup, setLookup] = useState("");
  const [lookupError, setLookupError] = useState("");

  useEffect(() => setMounted(true), []);

  const student = findStudent(activeId, overrides);
  const ready = student && isAssessed(student) && student.cgpa > 0;
  const analysis = ready && student ? analyzeStudent(student) : null;

  function loadId(event: FormEvent) {
    event.preventDefault();
    const found = findStudent(lookup, overrides);
    if (!found) {
      setLookupError("No student with that ID. Try CAI24001 or register a new one.");
      return;
    }
    setLookupError("");
    setActive(found.studentId);
  }

  if (!hydrated) return <p className="text-sm text-muted">Loading your dashboard…</p>;

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-serif text-4xl">My dashboard</h1>
          <p className="mt-2 text-muted">Personal scores for the profile you are viewing.</p>
        </div>
        <form onSubmit={loadId} className="flex flex-wrap items-center gap-2">
          <input
            className="min-h-11 rounded-md border border-line bg-surface px-3 text-sm"
            placeholder="Student ID"
            value={lookup}
            onChange={(event) => setLookup(event.target.value)}
            aria-label="Student ID"
          />
          <button className={btnGhost} type="submit">
            Load
          </button>
        </form>
      </div>
      {lookupError ? <p className="text-sm text-gap">{lookupError}</p> : null}

      <div className="flex flex-wrap gap-2">
        {FEATURED.map((person) => (
          <button
            key={person.studentId}
            type="button"
            className="min-h-11 rounded-md border border-line bg-surface px-3 text-sm hover:bg-primary-soft"
            onClick={() => setActive(person.studentId)}
          >
            {person.name}
          </button>
        ))}
      </div>

      {!student || !analysis ? (
        <section className={cardClass}>
          <h2 className="font-serif text-2xl">Nothing to chart yet</h2>
          <p className="mt-2 text-sm text-muted">Finish an assessment or open a sample profile.</p>
          <Link to="/assess" search={{ id: undefined }} className={`${btnPrimary} mt-4`}>
            Go to assessment
          </Link>
        </section>
      ) : (
        <>
          <section className={`${cardClass} grid gap-4 md:grid-cols-[auto_1fr] md:items-center`}>
            <ScoreRing value={analysis.readiness} caption="Career Readiness" />
            <div>
              <p className="text-sm text-muted">
                {student.name} · {student.studentId}
              </p>
              <h2 className="font-serif text-3xl">{analysis.top3[0]?.career}</h2>
              <p className="text-sm text-muted">Top match · {analysis.top3[0]?.percent}%</p>
              <p className="mt-2">
                <span className={`inline-flex rounded-md px-2 py-1 text-sm font-semibold ${BAND_CLASS[bandTone(analysis.band)]}`}>
                  {analysis.band}
                </span>
              </p>
            </div>
          </section>

          <section className="grid gap-4 lg:grid-cols-2">
            <ChartCard title="Skill scores">
              {mounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { skill: "Excel", score: student.excel },
                      { skill: "SQL", score: student.sql },
                      { skill: "Python", score: student.python },
                      { skill: "Power BI", score: student.powerbi },
                      { skill: "Analysis", score: student.dataAnalysis },
                      { skill: "Comm.", score: student.communication },
                    ]}
                    margin={{ top: 8, right: 8, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid stroke="var(--color-line)" vertical={false} />
                    <XAxis dataKey="skill" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
                    <YAxis domain={[0, 10]} tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="score" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : null}
            </ChartCard>
            <ChartCard title="Strongest career matches">
              {mounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={analysis.matches.slice(0, 8).map((match) => ({
                      career: match.career,
                      percent: match.percent,
                    }))}
                    layout="vertical"
                    margin={{ top: 8, right: 16, left: 8, bottom: 0 }}
                  >
                    <CartesianGrid stroke="var(--color-line)" horizontal={false} />
                    <XAxis type="number" domain={[0, 100]} tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
                    <YAxis type="category" dataKey="career" width={148} tick={{ fill: "var(--color-ink)", fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="percent" fill="var(--color-primary)" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : null}
            </ChartCard>
          </section>

          <section className="grid gap-4 md:grid-cols-3">
            <ListCard title="Strengths" items={analysis.strengths.map((item) => `${item.skill} · ${item.score}/10`)} empty="No skill at 7 or above yet." />
            <ListCard title="Skill gaps" items={analysis.gaps.map((item) => `${item.skill} · ${item.score}/10`)} empty="No rated skill is below 6." />
            <ListCard title="Recommended careers" items={analysis.top3.map((match) => `${match.career} · ${match.percent}%`)} empty="No matches." />
          </section>

          <section className="grid gap-4 md:grid-cols-2">
            <ListCard title="Learning roadmap" items={analysis.roadmap.map((week) => `${week.week}: ${week.focus}`)} empty="" />
            <ListCard title="Recommended projects" items={analysis.projects} empty="" />
          </section>

          <Link to="/results" className={btnGhost + " w-fit"}>
            Open the full result
          </Link>
        </>
      )}
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className={cardClass}>
      <h2 className="font-serif text-xl">{title}</h2>
      <div className="mt-3 h-80 w-full">{children}</div>
    </section>
  );
}

function ListCard({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <section className={cardClass}>
      <h2 className="font-serif text-xl">{title}</h2>
      {items.length === 0 ? (
        <p className="mt-2 text-sm text-muted">{empty}</p>
      ) : (
        <ul className="mt-3 grid gap-2 text-sm">
          {items.map((item) => (
            <li key={item} className="border-b border-line pb-2">
              {item}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
