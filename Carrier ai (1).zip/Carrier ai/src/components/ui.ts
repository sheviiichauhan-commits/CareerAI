export const btnPrimary =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-ink shadow-card transition-colors duration-150 hover:bg-primary-hover disabled:cursor-not-allowed disabled:opacity-50";

export const btnGhost =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-surface px-4 text-sm font-semibold text-ink shadow-card transition-colors duration-150 hover:bg-primary-soft disabled:cursor-not-allowed disabled:opacity-50";

export const fieldClass =
  "min-h-11 w-full rounded-lg border border-line bg-surface px-3 text-sm text-ink outline-none transition-colors duration-150 focus:border-primary focus:ring-2 focus:ring-primary/20";

export const cardClass = "rounded-lg bg-surface p-5 shadow-card";

export const labelClass = "grid gap-1 text-sm font-medium text-ink";
