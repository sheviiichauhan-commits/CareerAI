import { Link } from "@tanstack/react-router";
import { ScoreRing } from "@/components/score-ring";
import { btnGhost, btnPrimary, cardClass } from "@/components/ui";
import { bandTone } from "@/lib/career/engine";
import { readableAnswer } from "@/lib/career/text";
import { careerStream, type Analysis, type StudentRecord } from "@/lib/career/types";

const BAND_CLASS = {
  ready: "bg-ready-soft text-ready",
  mid: "bg-mid-soft text-mid",
  gap: "bg-gap-soft text-gap",
};

export function ResultPanel({
  student,
  analysis,
  advice,
  adviceError,
  adviceBusy,
  onAdvice,
}: {
  student: StudentRecord;
  analysis: Analysis;
  advice?: string;
  adviceError?: string;
  adviceBusy?: boolean;
  onAdvice?: () => void;
}) {
  const tone = bandTone(analysis.band);
  const best = analysis.top3[0];
  return (
    <div className="grid gap-6">
      <section className={`${cardClass} grid gap-6 md:grid-cols-[auto_1fr] md:items-center`}>
        <ScoreRing value={analysis.readiness} caption="Career Readiness" />
        <div className="grid gap-3">
          <p className="text-sm text-muted">
            {student.name} · {student.studentId} · {student.course}, Year {student.year} · {student.department}
          </p>
          <h1 className="font-serif text-3xl text-ink">Your career profile</h1>
          <p>
            <span className={`inline-flex rounded-md px-2 py-1 text-sm font-semibold ${BAND_CLASS[tone]}`}>
              {analysis.band}
            </span>
          </p>
          {best ? (
            <p className="text-lg">
              Best career match: <strong>{best.career}</strong>{" "}
              <span className="tabular-nums">{best.percent}%</span>
            </p>
          ) : null}
          <p className="text-sm text-muted">{analysis.note}</p>
          <div className="flex flex-wrap gap-2">
            <Link to="/coach" className={btnPrimary}>
              Ask CareerAI
            </Link>
            <Link to="/dashboard" className={btnGhost}>
              My dashboard
            </Link>
            {onAdvice ? (
              <button type="button" className={btnGhost} onClick={onAdvice} disabled={adviceBusy}>
                {adviceBusy ? "Writing advice…" : advice ? "Refresh AI advice" : "Generate AI advice"}
              </button>
            ) : null}
          </div>
          {adviceError ? <p className="text-sm text-gap">{adviceError}</p> : null}
        </div>
      </section>

      {advice ? (
        <section className={cardClass}>
          <h2 className="font-serif text-2xl">AI career advice</h2>
          <p className="mt-1 text-sm text-muted">Guidance only. Check anything important before you act on it.</p>
          <div className="mt-4 whitespace-pre-wrap text-sm leading-relaxed">{readableAnswer(advice)}</div>
        </section>
      ) : null}

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">Career matches</h2>
        <p className="mt-1 text-sm text-muted">
          Match = 78% skill fit + 22% stated interest. The top three are the recommendations.
        </p>
        <ul className="mt-4 grid gap-3">
          {analysis.matches.map((match, index) => (
            <li key={match.career}>
              <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
                <span>
                  {index < 3 ? <span className="mr-2 text-muted">Top {index + 1}</span> : null}
                  {match.career}
                  <span className="ml-2 text-xs text-muted">{careerStream(match.career)}</span>
                </span>
                <span className="tabular-nums font-semibold">{match.percent}%</span>
              </div>
              <div className="h-2 rounded-full bg-primary-soft">
                <div className="h-2 rounded-full bg-primary" style={{ width: `${match.percent}%` }} />
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className="grid gap-4 md:grid-cols-2">
        <div className={cardClass}>
          <h2 className="font-serif text-2xl">Strengths</h2>
          <p className="mt-1 text-sm text-muted">Rated skills at 7/10 or above.</p>
          {analysis.strengths.length === 0 ? (
            <p className="mt-3 text-sm">No rated skill is at 7 yet. That is a starting point, not a verdict.</p>
          ) : (
            <ul className="mt-3 grid gap-2 text-sm">
              {analysis.strengths.map((item) => (
                <li key={item.skill} className="flex justify-between border-b border-line py-2">
                  <span>{item.skill}</span>
                  <span className="tabular-nums">{item.score}/10</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className={cardClass}>
          <h2 className="font-serif text-2xl">Skill gaps</h2>
          <p className="mt-1 text-sm text-muted">Rated skills below 6/10.</p>
          {analysis.gaps.length === 0 ? (
            <p className="mt-3 text-sm">No rated skill is below 6. Keep building depth in the top career.</p>
          ) : (
            <ul className="mt-3 grid gap-2 text-sm">
              {analysis.gaps.map((item) => (
                <li key={item.skill} className="flex justify-between border-b border-line py-2">
                  <span>{item.skill}</span>
                  <span className="tabular-nums text-gap">{item.score}/10</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2">
        <div className={cardClass}>
          <h2 className="font-serif text-2xl">Skills to learn</h2>
          <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm">
            {analysis.recommendedSkills.map((skill) => (
              <li key={skill}>{skill}</li>
            ))}
          </ol>
        </div>
        <div className={cardClass}>
          <h2 className="font-serif text-2xl">Recommended projects</h2>
          <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm">
            {analysis.projects.map((project) => (
              <li key={project}>{project}</li>
            ))}
          </ol>
        </div>
      </section>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">30-day learning roadmap</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {analysis.roadmap.map((week) => (
            <article key={week.week} className="rounded-md bg-primary-soft p-4">
              <p className="text-xs font-semibold tracking-wide text-primary uppercase">{week.week}</p>
              <h3 className="mt-1 font-serif text-lg">{week.focus}</h3>
              <ul className="mt-2 list-disc space-y-1 pl-4 text-sm">
                {week.tasks.map((task) => (
                  <li key={task}>{task}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className={cardClass}>
        <h2 className="font-serif text-2xl">How the score was calculated</h2>
        <p className="mt-1 text-sm text-muted">
          Weighted total {analysis.readinessExact}, shown as {analysis.readiness} after rounding to the nearest
          whole number. Bands: 80–100 Highly Ready, 60–79 Moderately Ready, below 60 Needs Improvement.
        </p>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[32rem] text-left text-sm">
            <thead className="text-muted">
              <tr className="border-b border-line">
                <th className="py-2 font-medium">Part</th>
                <th className="py-2 font-medium">Weight</th>
                <th className="py-2 font-medium">Input</th>
                <th className="py-2 text-right font-medium">Points</th>
              </tr>
            </thead>
            <tbody>
              {analysis.breakdown.map((part) => (
                <tr key={part.key} className="border-b border-line">
                  <td className="py-2">{part.label}</td>
                  <td className="py-2">{part.weight}</td>
                  <td className="py-2 text-muted">{part.detail}</td>
                  <td className="py-2 text-right tabular-nums">
                    {part.points} / {part.max}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
