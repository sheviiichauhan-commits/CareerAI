export function ScoreRing({ value, caption }: { value: number; caption: string }) {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - Math.max(0, Math.min(100, value)) / 100);
  return (
    <figure className="grid justify-items-center gap-1">
      <svg viewBox="0 0 140 140" className="size-36" role="img" aria-label={`${caption}: ${value} out of 100`}>
        <circle cx="70" cy="70" r={radius} fill="none" stroke="var(--color-primary-soft)" strokeWidth="10" />
        <circle
          cx="70"
          cy="70"
          r={radius}
          fill="none"
          stroke="var(--color-primary)"
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          transform="rotate(-90 70 70)"
        />
        <text
          x="70"
          y="66"
          textAnchor="middle"
          fill="var(--color-ink)"
          fontSize="28"
          fontFamily="var(--font-serif)"
        >
          {value}
        </text>
        <text x="70" y="86" textAnchor="middle" fill="var(--color-muted)" fontSize="11">
          out of 100
        </text>
      </svg>
      <figcaption className="text-center text-sm text-muted">{caption}</figcaption>
    </figure>
  );
}
