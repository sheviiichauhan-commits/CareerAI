import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { useCareerStore } from "@/lib/career/store";

const LINKS = [
  { to: "/", label: "Home" },
  { to: "/register", label: "Register" },
  { to: "/assess", label: "Assessment" },
  { to: "/results", label: "Results" },
  { to: "/dashboard", label: "Dashboard" },
  { to: "/coach", label: "AI Coach" },
  { to: "/admin", label: "Admin" },
  { to: "/project", label: "Project files" },
] as const;

function NavLinks({ path, onNavigate }: { path: string; onNavigate?: () => void }) {
  return (
    <>
      {LINKS.map((link) => {
        const active = link.to === "/" ? path === "/" : path.startsWith(link.to);
        return (
          <Link
            key={link.to}
            to={link.to}
            onClick={(event) => {
              event.currentTarget.closest("details")?.removeAttribute("open");
              onNavigate?.();
            }}
            className={
              "inline-flex min-h-11 items-center rounded-lg px-3 text-sm transition-colors duration-150 " +
              (active ? "bg-primary-soft font-semibold text-primary" : "text-muted hover:bg-surface hover:text-ink")
            }
          >
            {link.label}
          </Link>
        );
      })}
    </>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    void Promise.resolve(useCareerStore.persist.rehydrate()).finally(() => {
      useCareerStore.setState({ hydrated: true });
    });
  }, []);

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-20 border-b border-line bg-surface/90 backdrop-blur-md">
        <div className="h-1 bg-primary" />
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-2">
          <Link to="/" className="flex min-h-11 items-center gap-2 py-2">
            <span className="grid size-9 place-items-center rounded-lg bg-primary font-serif text-base font-semibold text-primary-ink">
              C
            </span>
            <span>
              <span className="block font-serif text-xl font-semibold leading-none text-ink">CareerAI</span>
              <span className="text-xs text-muted">Student career analytics</span>
            </span>
          </Link>
          <nav className="hidden flex-wrap justify-end lg:flex">{<NavLinks path={path} />}</nav>
          <details className="relative lg:hidden">
            <summary className="min-h-11 list-none rounded-lg bg-surface px-3 py-2 text-sm font-semibold shadow-card">
              Menu
            </summary>
            <nav className="absolute right-0 z-30 mt-2 grid w-52 rounded-lg bg-surface p-2 shadow-card">
              <NavLinks path={path} onNavigate={() => {}} />
            </nav>
          </details>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">{children}</main>
      <footer className="border-t border-line">
        <div className="mx-auto grid max-w-6xl gap-3 px-4 py-6 text-sm text-muted sm:grid-cols-[1fr_auto]">
          <p>
            Fictional demo data only. The Career Readiness score is a project-defined classroom model, not a
            scientific test. Career suggestions are guidance. AI answers can be wrong and should be checked.
            Do not use this system for high-stakes decisions about students.
          </p>
          <Link to="/guide" className="font-semibold text-primary">
            Presentation and viva notes
          </Link>
        </div>
      </footer>
    </div>
  );
}
