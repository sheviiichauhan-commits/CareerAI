//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CYX62n4M.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/assess",
			"/coach",
			"/dashboard",
			"/guide",
			"/project",
			"/register",
			"/results"
		],
		preloads: ["/assets/index-CHo-oIS7.js", "/assets/jsx-runtime-D3jfb0Ew.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CHo-oIS7.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-uPcomTxE.js",
			"/assets/ui-DRQy7ell.js",
			"/assets/dataset-DxejBtsx.js",
			"/assets/engine-D-7IIVxl.js",
			"/assets/score-ring-Dx-qSZ9r.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CJhtnOK7.js",
			"/assets/BarChart-EWfZp7xh.js",
			"/assets/ui-DRQy7ell.js",
			"/assets/cohort-pmQEvA1n.js",
			"/assets/engine-D-7IIVxl.js"
		]
	},
	"/assess": {
		filePath: "/workspace/src/routes/assess.tsx",
		children: void 0,
		preloads: [
			"/assets/assess-ZoZZ8Kc_.js",
			"/assets/ui-DRQy7ell.js",
			"/assets/cohort-pmQEvA1n.js",
			"/assets/types-CMRNupVs.js"
		]
	},
	"/coach": {
		filePath: "/workspace/src/routes/coach.tsx",
		children: void 0,
		preloads: [
			"/assets/coach-CRh-BsK2.js",
			"/assets/text-D4Q7iI3F.js",
			"/assets/ui-DRQy7ell.js",
			"/assets/dataset-DxejBtsx.js",
			"/assets/cohort-pmQEvA1n.js",
			"/assets/engine-D-7IIVxl.js",
			"/assets/prompts-CHMkNe8j.js"
		]
	},
	"/dashboard": {
		filePath: "/workspace/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-BTMQCNkT.js",
			"/assets/BarChart-EWfZp7xh.js",
			"/assets/ui-DRQy7ell.js",
			"/assets/dataset-DxejBtsx.js",
			"/assets/cohort-pmQEvA1n.js",
			"/assets/engine-D-7IIVxl.js",
			"/assets/score-ring-Dx-qSZ9r.js"
		]
	},
	"/guide": {
		filePath: "/workspace/src/routes/guide.tsx",
		children: void 0,
		preloads: ["/assets/guide-FB9teeaK.js", "/assets/ui-DRQy7ell.js"]
	},
	"/project": {
		filePath: "/workspace/src/routes/project.tsx",
		children: void 0,
		preloads: [
			"/assets/project-Cz9XxutT.js",
			"/assets/ui-DRQy7ell.js",
			"/assets/dataset-DxejBtsx.js",
			"/assets/types-CMRNupVs.js",
			"/assets/engine-D-7IIVxl.js",
			"/assets/prompts-CHMkNe8j.js"
		]
	},
	"/register": {
		filePath: "/workspace/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-B95-MWni.js",
			"/assets/ui-DRQy7ell.js",
			"/assets/cohort-pmQEvA1n.js"
		]
	},
	"/results": {
		filePath: "/workspace/src/routes/results.tsx",
		children: void 0,
		preloads: [
			"/assets/results-Bw7qbMBY.js",
			"/assets/text-D4Q7iI3F.js",
			"/assets/ui-DRQy7ell.js",
			"/assets/cohort-pmQEvA1n.js",
			"/assets/engine-D-7IIVxl.js",
			"/assets/score-ring-Dx-qSZ9r.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
