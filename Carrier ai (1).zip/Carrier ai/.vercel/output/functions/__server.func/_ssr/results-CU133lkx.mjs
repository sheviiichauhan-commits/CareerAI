import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useCareerStore } from "./router-Ctgn2Dah.mjs";
import { n as btnPrimary, r as cardClass, t as btnGhost } from "./ui-BxRuaKth.mjs";
import { i as studentContext, n as isAssessed, t as findStudent } from "./cohort-C1wzc9rD.mjs";
import { n as analyzeStudent, r as bandTone } from "./engine-NXHUDjOE.mjs";
import { n as readableAnswer, t as askCoach } from "./text-CwEMlgtO.mjs";
import { t as ScoreRing } from "./score-ring-BUJhMBAB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/results-CU133lkx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BAND_CLASS = {
	ready: "bg-ready-soft text-ready",
	mid: "bg-mid-soft text-mid",
	gap: "bg-gap-soft text-gap"
};
function ResultPanel({ student, analysis, advice, adviceError, adviceBusy, onAdvice }) {
	const tone = bandTone(analysis.band);
	const best = analysis.top3[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: `${cardClass} grid gap-6 md:grid-cols-[auto_1fr] md:items-center`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, {
					value: analysis.readiness,
					caption: "Career Readiness"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								student.name,
								" · ",
								student.studentId,
								" · ",
								student.course,
								", Year ",
								student.year,
								" · ",
								student.department
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-serif text-3xl text-ink",
							children: "Your career profile"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `inline-flex rounded-md px-2 py-1 text-sm font-semibold ${BAND_CLASS[tone]}`,
							children: analysis.band
						}) }),
						best ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-lg",
							children: [
								"Best career match: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: best.career }),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: [best.percent, "%"]
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: analysis.note
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/coach",
									className: btnPrimary,
									children: "Ask CareerAI"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/dashboard",
									className: btnGhost,
									children: "My dashboard"
								}),
								onAdvice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: btnGhost,
									onClick: onAdvice,
									disabled: adviceBusy,
									children: adviceBusy ? "Writing advice…" : advice ? "Refresh AI advice" : "Generate AI advice"
								}) : null
							]
						}),
						adviceError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-gap",
							children: adviceError
						}) : null
					]
				})]
			}),
			advice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "AI career advice"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Guidance only. Check anything important before you act on it."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 whitespace-pre-wrap text-sm leading-relaxed",
						children: readableAnswer(advice)
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Career matches"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Match = 78% skill fit + 22% stated interest. The top three are the recommendations."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-3",
						children: analysis.matches.map((match, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex items-baseline justify-between gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [index < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mr-2 text-muted",
								children: ["Top ", index + 1]
							}) : null, match.career] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums font-semibold",
								children: [match.percent, "%"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-2 rounded-full bg-primary-soft",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 rounded-full bg-primary",
								style: { width: `${match.percent}%` }
							})
						})] }, match.career))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cardClass,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl",
							children: "Strengths"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Rated skills at 7/10 or above."
						}),
						analysis.strengths.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm",
							children: "No rated skill is at 7 yet. That is a starting point, not a verdict."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 grid gap-2 text-sm",
							children: analysis.strengths.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between border-b border-line py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.skill }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: [item.score, "/10"]
								})]
							}, item.skill))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cardClass,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl",
							children: "Skill gaps"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Rated skills below 6/10."
						}),
						analysis.gaps.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm",
							children: "No rated skill is below 6. Keep building depth in the top career."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 grid gap-2 text-sm",
							children: analysis.gaps.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between border-b border-line py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.skill }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums text-gap",
									children: [item.score, "/10"]
								})]
							}, item.skill))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cardClass,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Skills to learn"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 list-decimal space-y-2 pl-5 text-sm",
						children: analysis.recommendedSkills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: skill }, skill))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cardClass,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Recommended projects"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 list-decimal space-y-2 pl-5 text-sm",
						children: analysis.projects.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: project }, project))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "30-day learning roadmap"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid gap-3 sm:grid-cols-2",
					children: analysis.roadmap.map((week) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-md bg-primary-soft p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-wide text-primary uppercase",
								children: week.week
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 font-serif text-lg",
								children: week.focus
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 list-disc space-y-1 pl-4 text-sm",
								children: week.tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: task }, task))
							})
						]
					}, week.week))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "How the score was calculated"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"Weighted total ",
							analysis.readinessExact,
							", shown as ",
							analysis.readiness,
							" after rounding to the nearest whole number. Bands: 80–100 Highly Ready, 60–79 Moderately Ready, below 60 Needs Improvement."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[32rem] text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-line",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "Part"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "Weight"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "Input"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-right font-medium",
											children: "Points"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: analysis.breakdown.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2",
										children: part.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2",
										children: part.weight
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 text-muted",
										children: part.detail
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-2 text-right tabular-nums",
										children: [
											part.points,
											" / ",
											part.max
										]
									})
								]
							}, part.key)) })]
						})
					})
				]
			})
		]
	});
}
function ResultsPage() {
	const hydrated = useCareerStore((state) => state.hydrated);
	const activeId = useCareerStore((state) => state.activeId);
	const overrides = useCareerStore((state) => state.overrides);
	const advice = useCareerStore((state) => activeId ? state.advice[activeId] : void 0);
	const setAdvice = useCareerStore((state) => state.setAdvice);
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const student = findStudent(activeId, overrides);
	const analysis = student && isAssessed(student) && student.cgpa > 0 && student ? analyzeStudent(student) : null;
	async function generate() {
		if (!student || !analysis) return;
		setBusy(true);
		setError("");
		try {
			const result = await askCoach({ data: {
				message: "Give me my full career guidance using the stored profile and the project scores. Keep each section short.",
				context: studentContext(student, analysis),
				history: []
			} });
			if (!result.ok) setError(result.error);
			else setAdvice(student.studentId, result.text);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "The advice could not be generated.");
		} finally {
			setBusy(false);
		}
	}
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Loading your saved profile…"
	});
	if (!student || !analysis) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cardClass,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl",
				children: "No assessment yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Complete an assessment, or open a sample profile from the home page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/assess",
					search: { id: void 0 },
					className: btnPrimary,
					children: "Start assessment"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "inline-flex min-h-11 items-center text-sm font-semibold text-primary",
					children: "Sample profiles"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, {
		student,
		analysis,
		advice,
		adviceError: error,
		adviceBusy: busy,
		onAdvice: () => void generate()
	});
}
//#endregion
export { ResultsPage as component };
