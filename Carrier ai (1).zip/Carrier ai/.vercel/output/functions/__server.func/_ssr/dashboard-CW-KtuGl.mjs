import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useCareerStore } from "./router-Ctgn2Dah.mjs";
import { n as btnPrimary, r as cardClass, t as btnGhost } from "./ui-BxRuaKth.mjs";
import { n as FEATURED } from "./dataset-DBGWRlVu.mjs";
import { n as isAssessed, t as findStudent } from "./cohort-C1wzc9rD.mjs";
import { n as analyzeStudent, r as bandTone } from "./engine-NXHUDjOE.mjs";
import { a as CartesianGrid, i as XAxis, l as ResponsiveContainer, n as BarChart, o as Bar, r as YAxis, u as Tooltip } from "../_libs/recharts+[...].mjs";
import { t as ScoreRing } from "./score-ring-BUJhMBAB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-CW-KtuGl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BAND_CLASS = {
	ready: "bg-ready-soft text-ready",
	mid: "bg-mid-soft text-mid",
	gap: "bg-gap-soft text-gap"
};
function DashboardPage() {
	const hydrated = useCareerStore((state) => state.hydrated);
	const activeId = useCareerStore((state) => state.activeId);
	const overrides = useCareerStore((state) => state.overrides);
	const setActive = useCareerStore((state) => state.setActive);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [lookup, setLookup] = (0, import_react.useState)("");
	const [lookupError, setLookupError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => setMounted(true), []);
	const student = findStudent(activeId, overrides);
	const analysis = student && isAssessed(student) && student.cgpa > 0 && student ? analyzeStudent(student) : null;
	function loadId(event) {
		event.preventDefault();
		const found = findStudent(lookup, overrides);
		if (!found) {
			setLookupError("No student with that ID. Try CAI24001 or register a new one.");
			return;
		}
		setLookupError("");
		setActive(found.studentId);
	}
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Loading your dashboard…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl",
					children: "My dashboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Personal scores for the profile you are viewing."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: loadId,
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "min-h-11 rounded-md border border-line bg-surface px-3 text-sm",
						placeholder: "Student ID",
						value: lookup,
						onChange: (event) => setLookup(event.target.value),
						"aria-label": "Student ID"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: btnGhost,
						type: "submit",
						children: "Load"
					})]
				})]
			}),
			lookupError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-gap",
				children: lookupError
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: FEATURED.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-md border border-line bg-surface px-3 text-sm hover:bg-primary-soft",
					onClick: () => setActive(person.studentId),
					children: person.name
				}, person.studentId))
			}),
			!student || !analysis ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Nothing to chart yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Finish an assessment or open a sample profile."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/assess",
						search: { id: void 0 },
						className: `${btnPrimary} mt-4`,
						children: "Go to assessment"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: `${cardClass} grid gap-4 md:grid-cols-[auto_1fr] md:items-center`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, {
						value: analysis.readiness,
						caption: "Career Readiness"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								student.name,
								" · ",
								student.studentId
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-3xl",
							children: analysis.top3[0]?.career
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Top match · ",
								analysis.top3[0]?.percent,
								"%"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `inline-flex rounded-md px-2 py-1 text-sm font-semibold ${BAND_CLASS[bandTone(analysis.band)]}`,
								children: analysis.band
							})
						})
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-4 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartCard, {
						title: "Skill scores",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: [
									{
										skill: "Excel",
										score: student.excel
									},
									{
										skill: "SQL",
										score: student.sql
									},
									{
										skill: "Python",
										score: student.python
									},
									{
										skill: "Power BI",
										score: student.powerbi
									},
									{
										skill: "Analysis",
										score: student.dataAnalysis
									},
									{
										skill: "Comm.",
										score: student.communication
									}
								],
								margin: {
									top: 8,
									right: 8,
									left: 0,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--color-line)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "skill",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [0, 10],
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "score",
										fill: "var(--color-primary)",
										radius: [
											4,
											4,
											0,
											0
										]
									})
								]
							})
						}) : null
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartCard, {
						title: "Career match",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: analysis.matches.map((match) => ({
									career: match.career.replace(" Analyst", ""),
									percent: match.percent
								})),
								layout: "vertical",
								margin: {
									top: 8,
									right: 16,
									left: 16,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--color-line)",
										horizontal: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										type: "number",
										domain: [0, 100],
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										type: "category",
										dataKey: "career",
										width: 88,
										tick: {
											fill: "var(--color-ink)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "percent",
										fill: "var(--color-primary)",
										radius: [
											0,
											4,
											4,
											0
										]
									})
								]
							})
						}) : null
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-4 md:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
							title: "Strengths",
							items: analysis.strengths.map((item) => `${item.skill} · ${item.score}/10`),
							empty: "No skill at 7 or above yet."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
							title: "Skill gaps",
							items: analysis.gaps.map((item) => `${item.skill} · ${item.score}/10`),
							empty: "No rated skill is below 6."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
							title: "Recommended careers",
							items: analysis.top3.map((match) => `${match.career} · ${match.percent}%`),
							empty: "No matches."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-4 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
						title: "Learning roadmap",
						items: analysis.roadmap.map((week) => `${week.week}: ${week.focus}`),
						empty: ""
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
						title: "Recommended projects",
						items: analysis.projects,
						empty: ""
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/results",
					className: btnGhost + " w-fit",
					children: "Open the full result"
				})
			] })
		]
	});
}
function ChartCard({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cardClass,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-xl",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 h-64 w-full",
			children
		})]
	});
}
function ListCard({ title, items, empty }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cardClass,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-xl",
			children: title
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: empty
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 grid gap-2 text-sm",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "border-b border-line pb-2",
				children: item
			}, item))
		})]
	});
}
//#endregion
export { DashboardPage as component };
