//#region node_modules/.nitro/vite/services/ssr/assets/types-DJ-C95mh.js
var CAREERS = [
	"Data Analyst",
	"Business Analyst",
	"HR Analyst",
	"Marketing Analyst",
	"Financial Analyst",
	"Entrepreneur"
];
//#endregion
export { CAREERS as t };
