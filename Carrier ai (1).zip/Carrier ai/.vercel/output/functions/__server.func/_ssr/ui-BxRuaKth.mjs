//#region node_modules/.nitro/vite/services/ssr/assets/ui-BxRuaKth.js
var btnPrimary = "inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-ink hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50";
var btnGhost = "inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-line bg-surface px-4 text-sm font-semibold text-ink hover:bg-primary-soft disabled:cursor-not-allowed disabled:opacity-50";
var fieldClass = "min-h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-ink outline-none focus:border-primary";
var cardClass = "rounded-lg border border-line bg-surface p-5";
var labelClass = "grid gap-1 text-sm font-medium text-ink";
//#endregion
export { labelClass as a, fieldClass as i, btnPrimary as n, cardClass as r, btnGhost as t };
