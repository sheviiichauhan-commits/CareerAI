import { t as DATASET } from "./dataset-DBGWRlVu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cohort-C1wzc9rD.js
function isAssessed(student) {
	return student.assessed !== false;
}
function mergeStudents(overrides) {
	const map = new Map(DATASET.map((student) => [student.studentId.toUpperCase(), student]));
	for (const student of Object.values(overrides)) map.set(student.studentId.toUpperCase(), {
		...student,
		studentId: student.studentId.toUpperCase()
	});
	return [...map.values()].sort((a, b) => a.studentId.localeCompare(b.studentId));
}
function findStudent(id, overrides) {
	const key = (id ?? "").trim().toUpperCase();
	if (!key) return void 0;
	return mergeStudents(overrides).find((student) => student.studentId === key);
}
function studentContext(student, analysis) {
	const skillLine = (label, score) => `${label}: ${score}/10`;
	return [
		"Student context. Use only these facts. Do not invent marks, projects, internships, or employers.",
		`Student ID: ${student.studentId}`,
		`Name: ${student.name}`,
		`Age: ${student.age}`,
		`Gender: ${student.gender}`,
		`Course: ${student.course}`,
		`Year: ${student.year}, Semester: ${student.semester}`,
		`Department: ${student.department}`,
		`CGPA (10-point scale): ${student.cgpa}`,
		`Attendance: ${student.attendance}%`,
		`Backlogs: ${student.backlogs}`,
		`Internships completed: ${student.internships}`,
		`Certifications: ${student.certifications}`,
		skillLine("Excel", student.excel),
		skillLine("SQL", student.sql),
		skillLine("Python", student.python),
		skillLine("Power BI", student.powerbi),
		skillLine("Communication", student.communication),
		skillLine("Data Analysis", student.dataAnalysis),
		`Selected interests: ${student.interests.join(", ") || "not provided"}`,
		`First career choice: ${student.firstChoice}`,
		`Second career choice: ${student.secondChoice}`,
		`Project-defined Career Readiness: ${analysis.readiness}/100 (${analysis.band}). Exact weighted total before rounding: ${analysis.readinessExact}.`,
		"Career match percentages already calculated by the project rules:",
		...analysis.matches.map((match) => `${match.career}: ${match.percent}%`),
		`Strengths (7/10 or above): ${analysis.strengths.map((item) => `${item.skill} ${item.score}`).join(", ") || "none yet"}`,
		`Skill gaps (below 6/10): ${analysis.gaps.map((item) => `${item.skill} ${item.score}`).join(", ") || "none"}`,
		`Suggested skills and topics: ${analysis.recommendedSkills.join(", ")}`,
		`Suggested projects: ${analysis.projects.join("; ")}`,
		"30-day roadmap already prepared:",
		...analysis.roadmap.map((week) => `${week.week} — ${week.focus}: ${week.tasks.join(" ")}`),
		"Quote the readiness score and match percentages above. Do not replace them with new percentages."
	].join("\n");
}
//#endregion
export { studentContext as i, isAssessed as n, mergeStudents as r, findStudent as t };
