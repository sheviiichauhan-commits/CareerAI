import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useCareerStore } from "./router-Ctgn2Dah.mjs";
import { i as fieldClass, r as cardClass } from "./ui-BxRuaKth.mjs";
import { n as isAssessed, r as mergeStudents } from "./cohort-C1wzc9rD.mjs";
import { i as roundPlaces, n as analyzeStudent } from "./engine-NXHUDjOE.mjs";
import { a as CartesianGrid, c as Cell, d as Legend, i as XAxis, l as ResponsiveContainer, n as BarChart, o as Bar, r as YAxis, s as Pie, t as PieChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CWRPTHiw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COLORS = [
	"var(--color-primary)",
	"var(--color-mid)",
	"var(--color-ready)",
	"var(--color-gap)",
	"var(--color-muted)",
	"var(--color-ink)"
];
var GAP_FIELDS = [
	{
		key: "excel",
		label: "Excel"
	},
	{
		key: "sql",
		label: "SQL"
	},
	{
		key: "python",
		label: "Python"
	},
	{
		key: "powerbi",
		label: "Power BI"
	},
	{
		key: "communication",
		label: "Communication"
	},
	{
		key: "dataAnalysis",
		label: "Data Analysis"
	}
];
function AdminPage() {
	const overrides = useCareerStore((state) => state.overrides);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [department, setDepartment] = (0, import_react.useState)("All");
	const [year, setYear] = (0, import_react.useState)("All");
	const [gender, setGender] = (0, import_react.useState)("All");
	const [career, setCareer] = (0, import_react.useState)("All");
	(0, import_react.useEffect)(() => setMounted(true), []);
	const all = (0, import_react.useMemo)(() => mergeStudents(overrides).filter((student) => isAssessed(student) && student.cgpa > 0), [overrides]);
	const departments = (0, import_react.useMemo)(() => unique(all.map((student) => student.department)), [all]);
	const filtered = all.filter((student) => {
		if (department !== "All" && student.department !== department) return false;
		if (year !== "All" && String(student.year) !== year) return false;
		if (gender !== "All" && student.gender !== gender) return false;
		if (career !== "All" && student.firstChoice !== career) return false;
		return true;
	});
	const stats = (0, import_react.useMemo)(() => buildStats(filtered), [filtered]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "Teacher analytics"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-3xl text-muted",
				children: "Cohort view of the fictional students. Filters apply to every number and chart on this page. Assessments saved in this browser are included."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
						label: "Department",
						value: department,
						onChange: setDepartment,
						options: ["All", ...departments]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
						label: "Year",
						value: year,
						onChange: setYear,
						options: [
							"All",
							"1",
							"2",
							"3"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
						label: "Gender",
						value: gender,
						onChange: setGender,
						options: [
							"All",
							"Female",
							"Male",
							"Other",
							"Prefer not to say"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
						label: "Career interest",
						value: career,
						onChange: setCareer,
						options: [
							"All",
							"Data Analyst",
							"Business Analyst",
							"HR Analyst",
							"Marketing Analyst",
							"Financial Analyst",
							"Entrepreneur"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Students",
						value: String(stats.count)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Average CGPA",
						value: stats.avgCgpa.toFixed(2)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Average attendance",
						value: `${stats.avgAttendance.toFixed(1)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Average career score",
						value: stats.avgReadiness.toFixed(1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Most popular career",
						value: stats.popular
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Most common skill gap",
						value: stats.commonGap
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Placement percentage",
						value: `${stats.placement.toFixed(1)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Highly ready",
						value: String(stats.highlyReady)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
						title: "CGPA distribution",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
							data: stats.cgpaBins,
							x: "band",
							y: "students"
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
						title: "Attendance distribution",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
							data: stats.attendanceBins,
							x: "band",
							y: "students"
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
						title: "Placement status",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareChart, { data: stats.placementMix }) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
						title: "Department performance",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
							data: stats.departments,
							x: "name",
							y: "cgpa"
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
						title: "Average skill scores",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
							data: stats.skillAverages,
							x: "skill",
							y: "score"
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
						title: "Students below 6 — skill gaps",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
							data: stats.gapCounts,
							x: "skill",
							y: "students"
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
						title: "First-choice careers",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
							data: stats.careers,
							x: "career",
							y: "students"
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, {
						title: "Readiness bands",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareChart, { data: stats.bands }) : null
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Students who may need support"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Lowest project scores in the current filter. Not a ranking of worth."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[36rem] text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-line",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "Student"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "Department"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "Score"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "Top match"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 font-medium",
											children: "Main gap"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: stats.support.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-2",
										children: [row.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-muted",
											children: row.id
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2",
										children: row.department
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 tabular-nums",
										children: row.score
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2",
										children: row.career
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2",
										children: row.gap
									})
								]
							}, row.id)) })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				id: "powerbi",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Power BI"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Power BI is a desktop tool, so it is not embedded here. Download the analytical file and build the three pages described in Project files. The charts above use the same columns."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "mt-4 inline-flex min-h-11 items-center font-semibold text-primary",
						href: "/downloads/CareerAI_Analytical.csv",
						children: "Download Power BI dataset"
					})
				]
			})
		]
	});
}
function buildStats(students) {
	const empty = {
		count: 0,
		avgCgpa: 0,
		avgAttendance: 0,
		avgReadiness: 0,
		popular: "—",
		commonGap: "—",
		placement: 0,
		highlyReady: 0,
		cgpaBins: [],
		attendanceBins: [],
		placementMix: [],
		departments: [],
		skillAverages: [],
		gapCounts: [],
		careers: [],
		bands: [],
		support: []
	};
	if (!students.length) return empty;
	const analysed = students.map((student) => ({
		student,
		analysis: analyzeStudent(student)
	}));
	const count = analysed.length;
	const avgCgpa = roundPlaces(analysed.reduce((sum, row) => sum + row.student.cgpa, 0) / count, 2);
	const avgAttendance = roundPlaces(analysed.reduce((sum, row) => sum + row.student.attendance, 0) / count, 1);
	const avgReadiness = roundPlaces(analysed.reduce((sum, row) => sum + row.analysis.readinessExact, 0) / count, 1);
	const popular = mode(analysed.map((row) => row.student.firstChoice));
	const gapCounts = GAP_FIELDS.map((field) => ({
		skill: field.label,
		students: analysed.filter((row) => Number(row.student[field.key]) < 6).length
	}));
	const commonGap = [...gapCounts].sort((a, b) => b.students - a.students)[0]?.skill ?? "—";
	const known = analysed.filter((row) => [
		"Placed",
		"Not Placed",
		"Higher Studies"
	].includes(row.student.placementStatus));
	const placed = known.filter((row) => row.student.placementStatus === "Placed").length;
	return {
		count,
		avgCgpa,
		avgAttendance,
		avgReadiness,
		popular,
		commonGap,
		placement: known.length ? roundPlaces(placed / known.length * 100, 1) : 0,
		highlyReady: analysed.filter((row) => row.analysis.band === "Highly Ready").length,
		cgpaBins: [
			"Below 6",
			"6 to 7",
			"7 to 8",
			"8 to 9",
			"9 to 10"
		].map((band) => ({
			band,
			students: analysed.filter((row) => cgpaBand(row.student.cgpa) === band).length
		})),
		attendanceBins: [
			"Below 75",
			"75 to 85",
			"85 to 95",
			"95 and above"
		].map((band) => ({
			band,
			students: analysed.filter((row) => attendanceBand(row.student.attendance) === band).length
		})),
		placementMix: [
			"Placed",
			"Not Placed",
			"Higher Studies",
			"In Progress"
		].map((name) => ({
			name,
			value: analysed.filter((row) => row.student.placementStatus === name).length
		})).filter((row) => row.value > 0),
		departments: unique(analysed.map((row) => row.student.department)).map((name) => {
			const rows = analysed.filter((row) => row.student.department === name);
			const cgpa = roundPlaces(rows.reduce((sum, row) => sum + row.student.cgpa, 0) / rows.length, 2);
			return {
				name: shortDept(name),
				cgpa
			};
		}),
		skillAverages: GAP_FIELDS.map((field) => ({
			skill: field.label === "Communication" ? "Comm." : field.label === "Data Analysis" ? "Analysis" : field.label,
			score: roundPlaces(analysed.reduce((sum, row) => sum + Number(row.student[field.key]), 0) / count, 2)
		})),
		gapCounts,
		careers: unique(analysed.map((row) => row.student.firstChoice)).map((name) => ({
			career: name.replace(" Analyst", ""),
			students: analysed.filter((row) => row.student.firstChoice === name).length
		})),
		bands: [
			"Highly Ready",
			"Moderately Ready",
			"Needs Improvement"
		].map((name) => ({
			name,
			value: analysed.filter((row) => row.analysis.band === name).length
		})),
		support: [...analysed].sort((a, b) => a.analysis.readiness - b.analysis.readiness).slice(0, 6).map((row) => ({
			id: row.student.studentId,
			name: row.student.name,
			department: row.student.department,
			score: row.analysis.readiness,
			career: row.analysis.top3[0]?.career ?? "—",
			gap: row.analysis.primaryGap
		}))
	};
}
function cgpaBand(cgpa) {
	if (cgpa < 6) return "Below 6";
	if (cgpa < 7) return "6 to 7";
	if (cgpa < 8) return "7 to 8";
	if (cgpa < 9) return "8 to 9";
	return "9 to 10";
}
function attendanceBand(attendance) {
	if (attendance < 75) return "Below 75";
	if (attendance < 85) return "75 to 85";
	if (attendance < 95) return "85 to 95";
	return "95 and above";
}
function shortDept(name) {
	if (name === "Information Technology") return "IT";
	if (name === "General Management") return "Gen. Mgmt";
	if (name === "Human Resources") return "HR";
	if (name === "Data Analytics") return "Data";
	return name;
}
function unique(values) {
	return [...new Set(values.filter(Boolean))].sort();
}
function mode(values) {
	const counts = /* @__PURE__ */ new Map();
	for (const value of values) counts.set(value, (counts.get(value) ?? 0) + 1);
	return [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "—";
}
function Kpi({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cardClass,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-serif text-2xl tabular-nums",
			children: value
		})]
	});
}
function Filter({ label, value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1 text-sm font-medium",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			className: fieldClass,
			value,
			onChange: (event) => onChange(event.target.value),
			children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: option }, option))
		})]
	});
}
function Chart({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cardClass,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-xl",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 h-64 w-full",
			children
		})]
	});
}
function ColumnChart({ data, x, y }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				left: 0,
				bottom: 8
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: "var(--color-line)",
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: x,
					tick: {
						fill: "var(--color-muted)",
						fontSize: 11
					},
					interval: 0,
					angle: -20,
					height: 48,
					textAnchor: "end"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { tick: {
					fill: "var(--color-muted)",
					fontSize: 12
				} }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey: y,
					fill: "var(--color-primary)",
					radius: [
						4,
						4,
						0,
						0
					]
				})
			]
		})
	});
}
function ShareChart({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
				data,
				dataKey: "value",
				nameKey: "name",
				innerRadius: 48,
				outerRadius: 76,
				paddingAngle: 2,
				children: data.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: COLORS[index % COLORS.length] }, entry.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {})
		] })
	});
}
//#endregion
export { AdminPage as component };
