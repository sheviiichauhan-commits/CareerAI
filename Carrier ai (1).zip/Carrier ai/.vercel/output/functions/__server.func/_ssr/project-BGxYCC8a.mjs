import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as cardClass } from "./ui-BxRuaKth.mjs";
import { t as DATASET } from "./dataset-DBGWRlVu.mjs";
import { t as CAREERS } from "./types-DJ-C95mh.mjs";
import { n as analyzeStudent, t as WEIGHTS } from "./engine-NXHUDjOE.mjs";
import { n as SYSTEM_PROMPT } from "./prompts-B6akQsRt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/project-BGxYCC8a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DOWNLOADS = [
	["CareerAI_Student_Data.xlsx", "Excel workbook — 320 fictional students, 5 sheets"],
	["CareerAI_Analytical.csv", "Flat file for Power BI, including scores and gaps"],
	["schema.sql", "MySQL database careerai_db"],
	["queries.sql", "Ten commented queries"],
	["seed_demo_20.sql", "First 20 students, for a quick SQL demo"]
];
function ProjectPage() {
	const example = DATASET[0];
	const analysis = example ? analyzeStudent(example) : null;
	const [sql, setSql] = (0, import_react.useState)("Loading queries…");
	(0, import_react.useEffect)(() => {
		fetch("/downloads/queries.sql").then((response) => response.ok ? response.text() : "Query file is not available.").then(setSql).catch(() => setSql("Query file could not be loaded."));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "Project files"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-3xl text-muted",
				children: "The website, the Excel file, the SQL, and the Python programs are one project. They share the same readiness formula and the same career weights."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Data flow"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid gap-2 text-sm",
					children: [
						"Excel holds the fictional students on five sheets.",
						"Python cleaning removes duplicate IDs, fixes types, fills gaps, and clips impossible scores.",
						"MySQL stores Students, Academic, Skills, Career_Interest, and Placement.",
						"Pandas calculates averages, placement, and preferences.",
						"The readiness function turns six inputs into a 0–100 score.",
						"The recommendation function scores six careers and keeps the top three.",
						"The analytical CSV is the Power BI dataset.",
						"The AI coach receives the saved profile plus these scores, inside a fixed system prompt."
					].map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md bg-primary-soft px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 font-semibold text-primary",
							children: index + 1
						}), step]
					}, step))
				})]
			}),
			example && analysis ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-serif text-2xl",
						children: ["Worked score — ", example.name]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"Same person as the home page. Exact total ",
							analysis.readinessExact,
							", displayed score ",
							analysis.readiness,
							" ",
							"(",
							analysis.band,
							")."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid gap-1 text-sm",
						children: analysis.breakdown.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3 border-b border-line py-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								part.label,
								" (",
								part.weight,
								")"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [
									part.points,
									" / ",
									part.max
								]
							})]
						}, part.key))
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Career skill weights"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Each row sums to 100% of skill fit. Match percentage is 78% skill fit and 22% interest fit. Interest fit is 100 for the first choice, 80 for the second, 65 for another selected interest, and 40 otherwise. Analytical ability is 70% data analysis and 30% CGPA."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[44rem] text-left text-xs sm:text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: "Career"
								}), [
									"Excel",
									"SQL",
									"Python",
									"Power BI",
									"Analysis",
									"Comm.",
									"Analytical",
									"CGPA"
								].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: label
								}, label))] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: CAREERS.map((career) => {
								const weights = WEIGHTS[career];
								const cells = [
									weights.excel,
									weights.sql,
									weights.python,
									weights.powerbi,
									weights.dataAnalysis,
									weights.communication,
									weights.analytical,
									weights.cgpa
								];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-line",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2",
										children: career
									}), cells.map((value, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 tabular-nums",
										children: value ? Math.round(value * 100) : "—"
									}, index))]
								}, career);
							}) })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Downloads"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2 text-sm",
					children: DOWNLOADS.map(([file, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "font-semibold text-primary",
						href: `/downloads/${file}`,
						children: file
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-muted",
						children: label
					})] }, file))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Power BI pages"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3 text-sm md:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-serif text-lg",
								children: "Student overview"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: "Cards for students, CGPA, attendance, placement, and readiness. Charts for CGPA, attendance, placement, and department."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-serif text-lg",
								children: "Skill analytics"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: "Average of each skill and a count of scores below 6. Python is the most common gap in this sample."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-serif text-lg",
								children: "Career analytics"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: "First-choice careers, match columns, readiness bands, and placement by interest. Slicers: department, year, gender, career."
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-4 list-decimal space-y-1 pl-5 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open Power BI Desktop." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Get data from Text/CSV and choose CareerAI_Analytical.csv. Or use MySQL with the schema and import script." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Build the three pages. Put Department, Year, Gender, and First_Choice on slicers." })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "SQL queries"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 max-h-[28rem] overflow-auto rounded-md bg-primary-soft p-3 text-xs leading-relaxed whitespace-pre-wrap",
					children: sql
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Coach system prompt"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 overflow-auto rounded-md bg-primary-soft p-3 text-xs leading-relaxed whitespace-pre-wrap",
					children: SYSTEM_PROMPT
				})]
			})
		]
	});
}
//#endregion
export { ProjectPage as component };
