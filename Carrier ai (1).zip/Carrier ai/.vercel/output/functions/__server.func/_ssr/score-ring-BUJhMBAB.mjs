import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/score-ring-BUJhMBAB.js
var import_jsx_runtime = require_jsx_runtime();
function ScoreRing({ value, caption }) {
	const radius = 52;
	const circumference = 2 * Math.PI * radius;
	const offset = circumference * (1 - Math.max(0, Math.min(100, value)) / 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "grid justify-items-center gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 140 140",
			className: "size-36",
			role: "img",
			"aria-label": `${caption}: ${value} out of 100`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "70",
					cy: "70",
					r: radius,
					fill: "none",
					stroke: "var(--color-primary-soft)",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "70",
					cy: "70",
					r: radius,
					fill: "none",
					stroke: "var(--color-primary)",
					strokeWidth: "10",
					strokeLinecap: "round",
					strokeDasharray: circumference,
					strokeDashoffset: offset,
					transform: "rotate(-90 70 70)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "70",
					y: "66",
					textAnchor: "middle",
					fill: "var(--color-ink)",
					fontSize: "28",
					fontFamily: "var(--font-serif)",
					children: value
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "70",
					y: "86",
					textAnchor: "middle",
					fill: "var(--color-muted)",
					fontSize: "11",
					children: "out of 100"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "text-center text-sm text-muted",
			children: caption
		})]
	});
}
//#endregion
export { ScoreRing as t };
