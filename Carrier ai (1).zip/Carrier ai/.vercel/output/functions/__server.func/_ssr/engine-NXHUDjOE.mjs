import { t as CAREERS } from "./types-DJ-C95mh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-NXHUDjOE.js
var WEIGHTS = {
	"Data Analyst": {
		excel: .15,
		sql: .25,
		python: .22,
		powerbi: .18,
		dataAnalysis: .2,
		communication: 0,
		analytical: 0,
		cgpa: 0
	},
	"Business Analyst": {
		excel: .22,
		sql: .18,
		python: 0,
		powerbi: .05,
		dataAnalysis: .22,
		communication: .23,
		analytical: .1,
		cgpa: 0
	},
	"HR Analyst": {
		excel: .22,
		sql: .05,
		python: 0,
		powerbi: .08,
		dataAnalysis: .1,
		communication: .35,
		analytical: .2,
		cgpa: 0
	},
	"Marketing Analyst": {
		excel: .2,
		sql: .05,
		python: 0,
		powerbi: .12,
		dataAnalysis: .23,
		communication: .3,
		analytical: .1,
		cgpa: 0
	},
	"Financial Analyst": {
		excel: .3,
		sql: .08,
		python: .05,
		powerbi: .1,
		dataAnalysis: .12,
		communication: .08,
		analytical: .12,
		cgpa: .15
	},
	Entrepreneur: {
		excel: .1,
		sql: .05,
		python: .05,
		powerbi: .08,
		dataAnalysis: .15,
		communication: .32,
		analytical: .15,
		cgpa: .1
	}
};
var SKILL_FIELDS = [
	{
		key: "excel",
		label: "Excel",
		weightKey: "excel"
	},
	{
		key: "sql",
		label: "SQL",
		weightKey: "sql"
	},
	{
		key: "python",
		label: "Python",
		weightKey: "python"
	},
	{
		key: "powerbi",
		label: "Power BI",
		weightKey: "powerbi"
	},
	{
		key: "communication",
		label: "Communication",
		weightKey: "communication"
	},
	{
		key: "dataAnalysis",
		label: "Data Analysis",
		weightKey: "dataAnalysis"
	}
];
var RELATED = {
	"Data Analyst": ["Statistics", "Data storytelling"],
	"Business Analyst": ["Requirements writing", "Process mapping"],
	"HR Analyst": ["People analytics basics", "Survey design"],
	"Marketing Analyst": ["Campaign measurement", "Customer segmentation"],
	"Financial Analyst": ["Financial statements", "Forecasting"],
	Entrepreneur: ["Customer discovery", "Unit economics"]
};
var PROJECTS = {
	"Data Analyst": [
		"Sales Dashboard",
		"Student Performance Analysis",
		"Customer Segmentation",
		"Marketing Analytics"
	],
	"Business Analyst": [
		"Process Improvement Case",
		"Requirements Dashboard",
		"Market Sizing Model",
		"Stakeholder Status Report"
	],
	"HR Analyst": [
		"Attrition Dashboard",
		"Hiring Funnel Analysis",
		"Employee Survey Insights",
		"Compensation Benchmark"
	],
	"Marketing Analyst": [
		"Campaign Performance Dashboard",
		"Customer Segmentation Study",
		"Social Media KPI Tracker",
		"A/B Test Summary"
	],
	"Financial Analyst": [
		"Budget versus Actual Dashboard",
		"Ratio Analysis Workbook",
		"Cash Flow Forecast",
		"Expense Variance Report"
	],
	Entrepreneur: [
		"Lean Canvas with Market Sizing",
		"Customer Discovery Notes",
		"Unit Economics Model",
		"Pitch Metrics Dashboard"
	]
};
var WEEK_TASKS = {
	Excel: [
		"Clean one small table: remove blanks and fix number formats.",
		"Practice SUMIF, AVERAGEIF, and one PivotTable.",
		"Write two sentences explaining what the PivotTable shows."
	],
	SQL: [
		"Write SELECT, WHERE, and ORDER BY on the Students table.",
		"JOIN Students with Academic on Student_ID.",
		"Add one GROUP BY to find an average by department."
	],
	Python: [
		"Load the Excel file with Pandas.",
		"Calculate average CGPA and average attendance.",
		"Check data types and fix one column if needed."
	],
	"Power BI": [
		"Import the analytical CSV.",
		"Build one KPI card and one bar chart.",
		"Add a slicer for Department."
	],
	"Data Analysis": [
		"Write one question the dataset can answer.",
		"Compare two departments on CGPA and attendance.",
		"List three findings and one limitation."
	],
	Communication: [
		"Explain your top career match in 60 seconds.",
		"Rewrite that explanation without jargon.",
		"Ask a classmate to repeat it back to you."
	],
	Statistics: [
		"Revise mean, median, and percentage.",
		"Read one chart from the dashboard out loud.",
		"State one reason a score is not a prediction."
	],
	"Data storytelling": [
		"Turn one number into a sentence a non-technical person understands.",
		"Give a chart a title that states the finding.",
		"End with one recommended action."
	],
	"Requirements writing": [
		"Write the question a manager is trying to answer.",
		"List the fields you would need.",
		"Note who would use the result."
	],
	"Process mapping": [
		"Sketch five steps of a campus process you know.",
		"Mark where data is collected.",
		"Suggest one delay that data could reveal."
	],
	"People analytics basics": [
		"Define attrition in one sentence.",
		"List three HR metrics that use a percentage.",
		"Explain why a small sample can mislead."
	],
	"Survey design": [
		"Write five clear questions for a student survey.",
		"Remove any leading wording.",
		"Decide how you would score the answers."
	],
	"Campaign measurement": [
		"Pick a fictional college-fest campaign.",
		"Choose reach, clicks, and sign-ups as metrics.",
		"Say which metric matters most and why."
	],
	"Customer segmentation": [
		"Split a fictional customer list into three groups.",
		"Name each group by behaviour, not only age.",
		"Suggest one offer for each group."
	],
	"Financial statements": [
		"Name the income statement, balance sheet, and cash flow statement.",
		"Explain revenue versus profit in one line.",
		"Calculate one simple expense ratio."
	],
	Forecasting: [
		"Take six fictional monthly sales numbers.",
		"Find the average and a simple next-month estimate.",
		"Write one reason the estimate could be wrong."
	],
	"Customer discovery": [
		"Write five questions you would ask a possible customer.",
		"Do not pitch inside those questions.",
		"Summarise what you would listen for."
	],
	"Unit economics": [
		"Define price, cost, and margin with a campus example.",
		"Calculate margin for one fictional product.",
		"Say what happens if the cost rises."
	],
	"Review and explain your strongest skill": [
		"Pick the skill you rated 7 or above.",
		"Explain it in five sentences without slides.",
		"Write one example you could put on a resume."
	]
};
function roundHalfUp(value) {
	return Math.floor(value + .5);
}
function roundPlaces(value, places) {
	const factor = 10 ** places;
	return Math.floor(value * factor + .5) / factor;
}
function clamp(value, low, high) {
	return Math.max(low, Math.min(high, value));
}
function internshipPoints(internships) {
	if (internships <= 0) return 0;
	if (internships === 1) return 6;
	return 10;
}
function certificationPoints(certifications) {
	if (certifications <= 0) return 0;
	if (certifications === 1) return 4;
	if (certifications === 2) return 7;
	return 10;
}
function analyticalAbility(dataAnalysis, cgpa) {
	const cgpa10 = clamp(cgpa, 0, 10);
	return roundPlaces(.7 * dataAnalysis + .3 * cgpa10, 2);
}
function readinessParts(student) {
	const cgpa = clamp(student.cgpa, 0, 10);
	const attendance = clamp(student.attendance, 0, 100);
	const techAvg = (student.excel + student.sql + student.python + student.powerbi + student.dataAnalysis) / 5;
	const communication = clamp(student.communication, 0, 10);
	return [
		{
			key: "cgpa",
			label: "CGPA",
			weight: "25%",
			detail: `${cgpa.toFixed(1)} / 10`,
			points: roundPlaces(cgpa / 10 * 25, 2),
			max: 25
		},
		{
			key: "technical",
			label: "Technical skills",
			weight: "30%",
			detail: `Average ${techAvg.toFixed(1)} / 10 across Excel, SQL, Python, Power BI, Data Analysis`,
			points: roundPlaces(techAvg / 10 * 30, 2),
			max: 30
		},
		{
			key: "communication",
			label: "Communication",
			weight: "15%",
			detail: `${communication.toFixed(0)} / 10`,
			points: roundPlaces(communication / 10 * 15, 2),
			max: 15
		},
		{
			key: "attendance",
			label: "Attendance",
			weight: "10%",
			detail: `${attendance.toFixed(0)}%`,
			points: roundPlaces(attendance / 100 * 10, 2),
			max: 10
		},
		{
			key: "internship",
			label: "Internship",
			weight: "10%",
			detail: `${student.internships} internship(s) — 0→0, 1→6, 2+→10`,
			points: internshipPoints(student.internships),
			max: 10
		},
		{
			key: "certifications",
			label: "Certifications",
			weight: "10%",
			detail: `${student.certifications} certificate(s) — 0→0, 1→4, 2→7, 3+→10`,
			points: certificationPoints(student.certifications),
			max: 10
		}
	];
}
function interestFit(career, student) {
	if (career === student.firstChoice) return 100;
	if (career === student.secondChoice) return 80;
	if (student.interests.includes(career)) return 65;
	return 40;
}
function to100(score) {
	return clamp(score, 0, 10) / 10 * 100;
}
function skillFit(career, student) {
	const analytical = analyticalAbility(student.dataAnalysis, student.cgpa);
	const values = {
		excel: to100(student.excel),
		sql: to100(student.sql),
		python: to100(student.python),
		powerbi: to100(student.powerbi),
		dataAnalysis: to100(student.dataAnalysis),
		communication: to100(student.communication),
		analytical: to100(analytical),
		cgpa: clamp(student.cgpa, 0, 10) / 10 * 100
	};
	const weights = WEIGHTS[career];
	return Object.keys(weights).reduce((sum, key) => sum + weights[key] * values[key], 0);
}
function matchPercent(career, student) {
	return clamp(roundHalfUp(.78 * skillFit(career, student) + .22 * interestFit(career, student)), 0, 100);
}
function tasksFor(topic) {
	return WEEK_TASKS[topic] ?? [
		`Spend three short sessions learning the basics of ${topic}.`,
		"Write five bullet notes in your own words.",
		"Connect the topic to your top career match in one paragraph."
	];
}
function buildRoadmap(career, gapNames) {
	const weights = WEIGHTS[career];
	const weightOf = (label) => {
		const field = SKILL_FIELDS.find((item) => item.label === label);
		return field ? weights[field.weightKey] : 0;
	};
	const ranked = [...gapNames].sort((a, b) => weightOf(b) - weightOf(a));
	const extras = RELATED[career].filter((topic) => !ranked.includes(topic));
	const focus = [];
	for (const name of [...ranked, ...extras]) {
		if (!focus.includes(name)) focus.push(name);
		if (focus.length === 3) break;
	}
	while (focus.length < 3) {
		const topic = [...RELATED[career], "Review and explain your strongest skill"].find((item) => !focus.includes(item));
		if (!topic) break;
		focus.push(topic);
	}
	const project = PROJECTS[career][0] ?? "Analytics project";
	const weeks = focus.map((topic, index) => ({
		week: `Week ${index + 1}`,
		focus: topic,
		tasks: tasksFor(topic)
	}));
	weeks.push({
		week: "Week 4",
		focus: `Build: ${project}`,
		tasks: [
			`Start the project “${project}” with the sample data or a small public dataset.`,
			"Show one chart, three findings, and one limitation.",
			"Add the project to your resume in four lines: tool, data, action, result."
		]
	});
	return weeks;
}
function analyzeStudent(student) {
	const breakdown = readinessParts(student);
	const readinessExact = roundPlaces(breakdown.reduce((sum, part) => sum + part.points, 0), 2);
	const readiness = roundHalfUp(readinessExact);
	const band = readiness >= 80 ? "Highly Ready" : readiness >= 60 ? "Moderately Ready" : "Needs Improvement";
	const matches = CAREERS.map((career) => ({
		career,
		percent: matchPercent(career, student),
		skillFit: roundPlaces(skillFit(career, student), 1),
		interestFit: interestFit(career, student)
	})).sort((a, b) => b.percent - a.percent || a.career.localeCompare(b.career));
	const rated = SKILL_FIELDS.map((field) => ({
		key: field.key,
		skill: field.label,
		score: Math.round(Number(student[field.key]))
	}));
	const strengths = rated.filter((item) => item.score >= 7).sort((a, b) => b.score - a.score);
	const gaps = rated.filter((item) => item.score < 6).sort((a, b) => a.score - b.score);
	const top = matches[0];
	if (!top) throw new Error("No careers configured.");
	const weights = WEIGHTS[top.career];
	const recommended = [...gaps].sort((a, b) => {
		const aw = SKILL_FIELDS.find((field) => field.label === a.skill);
		const bw = SKILL_FIELDS.find((field) => field.label === b.skill);
		return (bw ? weights[bw.weightKey] : 0) - (aw ? weights[aw.weightKey] : 0);
	}).map((item) => item.skill);
	for (const topic of RELATED[top.career]) if (!recommended.includes(topic)) recommended.push(topic);
	return {
		readinessExact,
		readiness,
		band,
		breakdown,
		analyticalAbility: analyticalAbility(student.dataAnalysis, student.cgpa),
		matches,
		top3: matches.slice(0, 3),
		strengths,
		gaps,
		recommendedSkills: recommended,
		projects: PROJECTS[top.career],
		roadmap: buildRoadmap(top.career, gaps.map((item) => item.skill)),
		primaryGap: gaps[0]?.skill ?? "None — no rated skill is below 6",
		note: "Project-defined analytical score for learning and guidance. Not a placement prediction and not a decision about the student."
	};
}
function bandTone(band) {
	if (band === "Highly Ready") return "ready";
	if (band === "Moderately Ready") return "mid";
	return "gap";
}
//#endregion
export { roundPlaces as i, analyzeStudent as n, bandTone as r, WEIGHTS as t };
