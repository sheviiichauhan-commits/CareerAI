import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/text-CwEMlgtO.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function cleanHistory(value) {
	if (!Array.isArray(value)) return [];
	const items = [];
	for (const entry of value) {
		if (!entry || typeof entry !== "object") continue;
		const role = entry.role;
		const content = entry.content;
		if ((role === "user" || role === "assistant") && typeof content === "string" && content.trim()) items.push({
			role,
			content: content.trim().slice(0, 1800)
		});
	}
	return items.slice(-6);
}
var askCoach = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Type a question before sending.");
	const message = String(input.message ?? "").trim();
	if (!message) throw new Error("Type a question before sending.");
	if (message.length > 1200) throw new Error("Please keep the question under 1200 characters.");
	return {
		message,
		context: String(input.context ?? "").slice(0, 7e3),
		history: cleanHistory(input.history)
	};
}).handler(createSsrRpc("2a7a177034ee0840ee0289c64047e8e88f3c59389ce15d41f34357b81d0c1765"));
/** Drop markdown markers so coach answers read cleanly without a markdown library. */
function readableAnswer(text) {
	return text.replace(/\*\*/g, "").replace(/^#{1,6}\s+/gm, "");
}
//#endregion
export { readableAnswer as n, askCoach as t };
