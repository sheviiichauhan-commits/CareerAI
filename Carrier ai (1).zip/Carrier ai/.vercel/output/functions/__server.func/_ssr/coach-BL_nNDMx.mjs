import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useCareerStore } from "./router-Ctgn2Dah.mjs";
import { i as fieldClass, n as btnPrimary, r as cardClass, t as btnGhost } from "./ui-BxRuaKth.mjs";
import { n as FEATURED } from "./dataset-DBGWRlVu.mjs";
import { i as studentContext, n as isAssessed, t as findStudent } from "./cohort-C1wzc9rD.mjs";
import { n as analyzeStudent } from "./engine-NXHUDjOE.mjs";
import { t as SUGGESTED_QUESTIONS } from "./prompts-B6akQsRt.mjs";
import { n as readableAnswer, t as askCoach } from "./text-CwEMlgtO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/coach-BL_nNDMx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CoachPage() {
	const hydrated = useCareerStore((state) => state.hydrated);
	const activeId = useCareerStore((state) => state.activeId);
	const overrides = useCareerStore((state) => state.overrides);
	const chats = useCareerStore((state) => state.chats);
	const setActive = useCareerStore((state) => state.setActive);
	const pushMessage = useCareerStore((state) => state.pushMessage);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const student = findStudent(activeId, overrides);
	const ready = Boolean(student && isAssessed(student) && student.cgpa > 0);
	const analysis = ready && student ? analyzeStudent(student) : null;
	const thread = activeId ? chats[activeId.toUpperCase()] ?? [] : [];
	async function send(text) {
		const message = text.trim();
		if (!message) {
			setError("Type a question before sending.");
			return;
		}
		if (!student) {
			setError("Open a student profile first so the coach has something to use.");
			return;
		}
		setBusy(true);
		setError("");
		setDraft("");
		try {
			const result = await askCoach({ data: {
				message,
				context: analysis ? studentContext(student, analysis) : "Profile is registered but the assessment is not complete. Say that more information is required.",
				history: thread
			} });
			if (!result.ok) {
				setDraft(message);
				setError(result.error);
				return;
			}
			pushMessage(student.studentId, {
				role: "user",
				content: message
			});
			pushMessage(student.studentId, {
				role: "assistant",
				content: result.text
			});
		} catch (caught) {
			setDraft(message);
			setError(caught instanceof Error ? caught.message : "The coach could not answer.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[16rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "grid content-start gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl",
					children: "AI Career Coach"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Answers use the selected profile and the project scores. They are guidance, and they can be wrong."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-sm font-medium",
					children: ["Profile", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: student?.studentId ?? "",
						onChange: (event) => setActive(event.target.value || null),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Select a student"
							}),
							FEATURED.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: person.studentId,
								children: person.name
							}, person.studentId)),
							Object.values(overrides).filter((person) => person.assessed !== false).map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: person.studentId,
								children: [person.name, " (saved)"]
							}, person.studentId))
						]
					})]
				}),
				student && analysis ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-md bg-primary-soft p-3 text-sm",
					children: [
						student.name,
						": readiness ",
						analysis.readiness,
						", best match ",
						analysis.top3[0]?.career,
						" ",
						analysis.top3[0]?.percent,
						"%."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"No assessed profile selected.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/assess",
							search: { id: void 0 },
							className: "font-semibold text-primary",
							children: "Complete an assessment"
						}),
						"."
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: `${cardClass} grid gap-4`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid max-h-[28rem] gap-3 overflow-y-auto",
					children: thread.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: hydrated ? "Ask about careers, skills, projects, internships, or a resume. Suggested questions are below." : "Loading saved chat…"
					}) : thread.map((message, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: message.role === "user" ? "max-w-2xl justify-self-end rounded-md bg-primary px-3 py-2 text-sm break-words text-primary-ink" : "max-w-2xl rounded-md bg-primary-soft px-3 py-2 text-sm break-words text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-xs font-semibold opacity-80",
							children: message.role === "user" ? "You" : "CareerAI"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "whitespace-pre-wrap leading-relaxed",
							children: readableAnswer(message.content)
						})]
					}, `${message.role}-${index}`))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: SUGGESTED_QUESTIONS.map((question) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-md border border-line px-3 text-left text-sm hover:bg-primary-soft disabled:opacity-50",
						disabled: busy || !ready,
						onClick: () => void send(question),
						children: question
					}, question))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						send(draft);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm font-medium",
							children: ["Your question", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: `${fieldClass} min-h-24 py-2`,
								value: draft,
								maxLength: 1200,
								onChange: (event) => setDraft(event.target.value),
								placeholder: "What should I learn before an internship?"
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-gap",
							role: "alert",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: btnPrimary,
								type: "submit",
								disabled: busy || !hydrated,
								children: busy ? "Thinking…" : "Send"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/results",
								className: btnGhost,
								children: "View score"
							})]
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { CoachPage as component };
