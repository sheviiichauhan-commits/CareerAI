import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useCareerStore } from "./router-Ctgn2Dah.mjs";
import { a as labelClass, i as fieldClass, n as btnPrimary, r as cardClass } from "./ui-BxRuaKth.mjs";
import { t as findStudent } from "./cohort-C1wzc9rD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-DWy0ed6q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COURSES = [
	"BBA",
	"B.Com",
	"BCA"
];
var DEPARTMENTS = [
	"Marketing",
	"Finance",
	"Human Resources",
	"Operations",
	"Accounting",
	"General Management",
	"Information Technology",
	"Data Analytics"
];
var GENDERS = [
	"Female",
	"Male",
	"Other",
	"Prefer not to say"
];
var EMPTY = {
	studentId: "",
	name: "",
	age: "",
	gender: "",
	course: "",
	year: "",
	semester: "",
	department: "",
	email: ""
};
function RegisterPage() {
	const navigate = useNavigate();
	const hydrated = useCareerStore((state) => state.hydrated);
	const overrides = useCareerStore((state) => state.overrides);
	const saveStudent = useCareerStore((state) => state.saveStudent);
	const [form, setForm] = (0, import_react.useState)(EMPTY);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [existing, setExisting] = (0, import_react.useState)(null);
	function set(key, value) {
		setForm((current) => ({
			...current,
			[key]: value
		}));
	}
	function suggestId() {
		set("studentId", `CAIU${String(Date.now()).slice(-4)}`);
	}
	function submit(event) {
		event.preventDefault();
		const next = validate(form);
		setErrors(next);
		if (Object.keys(next).length) return;
		const id = form.studentId.trim().toUpperCase();
		const already = findStudent(id, overrides);
		if (already?.assessed !== false && already) {
			setExisting(already);
			return;
		}
		const student = {
			studentId: id,
			name: form.name.trim(),
			age: Number(form.age),
			gender: form.gender,
			course: form.course,
			year: Number(form.year),
			semester: Number(form.semester),
			department: form.department,
			email: form.email.trim(),
			cgpa: 0,
			attendance: 0,
			backlogs: 0,
			internships: 0,
			certifications: 0,
			excel: 1,
			sql: 1,
			python: 1,
			powerbi: 1,
			communication: 1,
			dataAnalysis: 1,
			interests: [],
			firstChoice: "",
			secondChoice: "",
			placementStatus: "In Progress",
			packageLpa: null,
			assessed: false
		};
		saveStudent(student);
		navigate({
			to: "/assess",
			search: { id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-3xl gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-4xl",
			children: "Student registration"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted",
			children: "This project uses sample data. Do not enter a real address, phone number, or another person’s private information. A demo email such as priya@demo.careerai.edu is enough."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: `${cardClass} grid gap-4`,
			noValidate: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: labelClass,
							children: [
								"Student ID",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									value: form.studentId,
									onChange: (event) => set("studentId", event.target.value),
									placeholder: "CAIU1024"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.studentId })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 text-sm font-semibold text-primary",
								onClick: suggestId,
								children: "Suggest a demo ID"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: `${labelClass} sm:col-span-2`,
							children: [
								"Name",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									value: form.name,
									onChange: (event) => set("name", event.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.name })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: labelClass,
							children: [
								"Age",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									inputMode: "numeric",
									value: form.age,
									onChange: (event) => set("age", event.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.age })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: labelClass,
							children: [
								"Gender",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: fieldClass,
									value: form.gender,
									onChange: (event) => set("gender", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select"
									}), GENDERS.map((gender) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: gender }, gender))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.gender })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: labelClass,
							children: [
								"Course",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: fieldClass,
									value: form.course,
									onChange: (event) => set("course", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select"
									}), COURSES.map((course) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: course }, course))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.course })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: labelClass,
							children: [
								"Department",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: fieldClass,
									value: form.department,
									onChange: (event) => set("department", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select"
									}), DEPARTMENTS.map((department) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: department }, department))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.department })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: labelClass,
							children: [
								"Year",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: fieldClass,
									value: form.year,
									onChange: (event) => set("year", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select"
									}), [
										1,
										2,
										3
									].map((year) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: year,
										children: ["Year ", year]
									}, year))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.year })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: labelClass,
							children: [
								"Semester",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: fieldClass,
									value: form.semester,
									onChange: (event) => set("semester", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select"
									}), [
										1,
										2,
										3,
										4,
										5,
										6
									].map((semester) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: semester,
										children: ["Semester ", semester]
									}, semester))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.semester })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: `${labelClass} sm:col-span-2`,
							children: [
								"Email",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									type: "email",
									value: form.email,
									onChange: (event) => set("email", event.target.value),
									placeholder: "name@demo.careerai.edu"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { message: errors.email })
							]
						})
					]
				}),
				existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-mid-soft p-3 text-sm text-mid",
					children: [
						existing.studentId,
						" is already in the demo cohort (",
						existing.name,
						"). Open the assessment to review it, or choose a new ID.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/assess",
								search: { id: existing.studentId },
								className: "font-semibold text-primary",
								children: "Continue to assessment"
							})
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: btnPrimary,
					type: "submit",
					disabled: !hydrated,
					children: "Save and continue to assessment"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Saved in this browser for the demonstration. The MySQL script in Project files shows how the same record would be stored in a database."
				})
			]
		})]
	});
}
function validate(form) {
	const errors = {};
	const id = form.studentId.trim();
	if (!/^[A-Za-z0-9-]{4,16}$/.test(id)) errors.studentId = "Use 4–16 letters or numbers. Example: CAIU1024.";
	if (form.name.trim().length < 3) errors.name = "Enter a name with at least 3 characters.";
	const age = Number(form.age);
	if (!form.age || Number.isNaN(age) || age < 16 || age > 40) errors.age = "Enter an age from 16 to 40.";
	if (!form.gender) errors.gender = "Select a gender option.";
	if (!form.course) errors.course = "Select a course.";
	if (!form.department) errors.department = "Select a department.";
	if (!form.year) errors.year = "Select a year.";
	if (!form.semester) errors.semester = "Select a semester.";
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) errors.email = "Enter an email like name@demo.careerai.edu.";
	return errors;
}
function FieldError({ message }) {
	if (!message) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-xs font-normal text-gap",
		children: message
	});
}
//#endregion
export { RegisterPage as component };
