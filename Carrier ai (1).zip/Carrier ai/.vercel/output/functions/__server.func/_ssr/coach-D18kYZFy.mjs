import { n as SYSTEM_PROMPT } from "./prompts-B6akQsRt.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/coach-D18kYZFy.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function cleanHistory(value) {
	if (!Array.isArray(value)) return [];
	const items = [];
	for (const entry of value) {
		if (!entry || typeof entry !== "object") continue;
		const role = entry.role;
		const content = entry.content;
		if ((role === "user" || role === "assistant") && typeof content === "string" && content.trim()) items.push({
			role,
			content: content.trim().slice(0, 1800)
		});
	}
	return items.slice(-6);
}
var askCoach_createServerFn_handler = createServerRpc({
	id: "2a7a177034ee0840ee0289c64047e8e88f3c59389ce15d41f34357b81d0c1765",
	name: "askCoach",
	filename: "src/lib/ai/coach.ts"
}, (opts) => askCoach.__executeServer(opts));
var askCoach = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Type a question before sending.");
	const message = String(input.message ?? "").trim();
	if (!message) throw new Error("Type a question before sending.");
	if (message.length > 1200) throw new Error("Please keep the question under 1200 characters.");
	return {
		message,
		context: String(input.context ?? "").slice(0, 7e3),
		history: cleanHistory(input.history)
	};
}).handler(askCoach_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "The AI Career Coach is not available in this environment. Your score, skill gaps, and roadmap still work without it."
	};
	const messages = [
		{
			role: "system",
			content: SYSTEM_PROMPT
		},
		{
			role: "system",
			content: data.context || "No student profile was provided. Tell the student that more information is required before you can give a personal recommendation. You may still explain the project in general terms."
		},
		...data.history,
		{
			role: "user",
			content: data.message
		}
	];
	try {
		const response = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .4,
				max_tokens: 700,
				messages
			})
		});
		if (!response.ok) return {
			ok: false,
			error: `The AI service returned an error (${response.status}). Please try again once.`
		};
		const text = (await response.json()).choices?.[0]?.message?.content?.trim() ?? "";
		if (!text) return {
			ok: false,
			error: "The AI returned an empty answer. Please try again."
		};
		return {
			ok: true,
			text
		};
	} catch {
		return {
			ok: false,
			error: "Could not reach the AI service. Please try again in a moment."
		};
	}
});
//#endregion
export { askCoach_createServerFn_handler };
