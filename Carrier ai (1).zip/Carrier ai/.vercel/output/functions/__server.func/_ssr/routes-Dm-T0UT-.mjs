import { C as require_jsx_runtime, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as FileSpreadsheet, i as MessagesSquare, o as Database, r as ShieldCheck, s as ChartLine, t as Waypoints } from "../_libs/lucide-react.mjs";
import { r as useCareerStore } from "./router-Ctgn2Dah.mjs";
import { n as btnPrimary, r as cardClass, t as btnGhost } from "./ui-BxRuaKth.mjs";
import { n as FEATURED, t as DATASET } from "./dataset-DBGWRlVu.mjs";
import { n as analyzeStudent } from "./engine-NXHUDjOE.mjs";
import { t as ScoreRing } from "./score-ring-BUJhMBAB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dm-T0UT-.js
var import_jsx_runtime = require_jsx_runtime();
var example = DATASET[0];
var exampleAnalysis = example ? analyzeStudent(example) : null;
function Home() {
	const hydrated = useCareerStore((state) => state.hydrated);
	const setActive = useCareerStore((state) => state.setActive);
	const navigate = useNavigate();
	function openProfile(id) {
		setActive(id);
		navigate({ to: "/results" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid items-center gap-8 lg:grid-cols-[1.2fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-primary",
							children: "For college students · fictional demo data"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-serif text-4xl leading-tight text-ink sm:text-5xl",
							children: "Understand your skills. Discover your career. Build your future."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xl text-base text-muted",
							children: "CareerAI turns CGPA, attendance, skills, internships, and interests into a readiness score, three career matches, skill gaps, projects, and a 30-day plan. A teacher view summarises the whole cohort."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/assess",
									search: { id: void 0 },
									className: btnPrimary,
									children: "Start career assessment"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/coach",
									className: btnGhost,
									children: "AI Career Coach"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/admin",
									className: btnGhost,
									children: "View dashboard"
								})
							]
						})
					]
				}), example && exampleAnalysis ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: cardClass,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-primary uppercase",
							children: "Worked example"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-serif text-2xl",
							children: example.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								example.course,
								" · ",
								example.department,
								" · sample profile ",
								example.studentId
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, {
								value: exampleAnalysis.readiness,
								caption: exampleAnalysis.band
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid flex-1 gap-2 text-sm",
								children: exampleAnalysis.top3.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between gap-3 border-b border-line pb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: match.career }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums font-semibold",
										children: [match.percent, "%"]
									})]
								}, match.career))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btnPrimary} mt-4 w-full`,
							disabled: !hydrated,
							onClick: () => openProfile(example.studentId),
							children: "Open this sample profile"
						})
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Fictional students",
						value: String(DATASET.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Career paths scored",
						value: "6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "What the score is",
						value: "Classroom model"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-3xl",
				children: "What you can do"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartLine, { className: "size-5" }),
						title: "Readiness score",
						text: "A transparent 0–100 score from CGPA, skills, communication, attendance, internships, and certificates."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waypoints, { className: "size-5" }),
						title: "Career matches",
						text: "Rule-based match percentages for analyst roles and entrepreneurship, with the top three called out."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesSquare, { className: "size-5" }),
						title: "AI Career Coach",
						text: "Ask follow-up questions. The coach sees the saved profile and the scores already calculated."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-5" }),
						title: "Excel cohort",
						text: "320 invented student records, split into the five sheets a college project would clean and load."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-5" }),
						title: "SQL and Python",
						text: "MySQL schema, commented queries, and Pandas modules that use the same formulas as this website."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" }),
						title: "Teacher view",
						text: "Averages, skill gaps, placement mix, and a file you can open in Power BI."
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cardClass,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "How it works"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 grid gap-3 text-sm",
						children: [
							"Register with a demo ID. Do not use a real student's private details.",
							"Rate skills from 1 to 10 and choose two career interests.",
							"The app saves the profile in this browser and runs the scoring rules.",
							"Read the score, gaps, and roadmap, then ask the coach a specific question."
						].map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-serif text-lg text-primary",
								children: ["0", index + 1]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: step })]
						}, step))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cardClass,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Try a classroom profile"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-2",
						children: FEATURED.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !hydrated,
							onClick: () => openProfile(person.studentId),
							className: "flex min-h-11 w-full items-center justify-between rounded-md border border-line px-3 text-left text-sm hover:bg-primary-soft disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [person.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-muted",
								children: person.note
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: person.studentId
							})]
						}) }, person.studentId))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cardClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Technology path"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "One pipeline, not seven separate assignments. This website is the working front end. The Excel, SQL, Python, and Power BI files use the same rules."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 grid gap-2 text-sm sm:grid-cols-2",
						children: [
							"Excel — fictional student workbook",
							"Cleaning — duplicates, types, impossible scores",
							"MySQL — five related tables",
							"Python and Pandas — cohort statistics",
							"Readiness score — published weights",
							"Recommendation rules — skill fit plus interest",
							"Power BI — three dashboard pages from the CSV",
							"AI coach — structured prompt plus the saved profile"
						].map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-md bg-primary-soft px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 font-semibold text-primary",
								children: index + 1
							}), item]
						}, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/project",
						className: `${btnGhost} mt-4`,
						children: "Open project files and formulas"
					})
				]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cardClass,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-serif text-2xl",
			children: value
		})]
	});
}
function Feature({ icon, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cardClass,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-10 place-items-center rounded-md bg-primary-soft text-primary",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-serif text-xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: text
			})
		]
	});
}
//#endregion
export { Home as component };
