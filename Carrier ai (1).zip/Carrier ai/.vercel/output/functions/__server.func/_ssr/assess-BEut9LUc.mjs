import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route$6, r as useCareerStore } from "./router-Ctgn2Dah.mjs";
import { a as labelClass, i as fieldClass, n as btnPrimary, r as cardClass } from "./ui-BxRuaKth.mjs";
import { t as findStudent } from "./cohort-C1wzc9rD.mjs";
import { t as CAREERS } from "./types-DJ-C95mh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assess-BEut9LUc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SKILLS = [
	["excel", "Excel"],
	["sql", "SQL"],
	["python", "Python"],
	["powerbi", "Power BI"],
	["dataAnalysis", "Data Analysis"],
	["communication", "Communication"]
];
var DEFAULT_SKILLS = {
	excel: 5,
	sql: 5,
	python: 5,
	powerbi: 5,
	dataAnalysis: 5,
	communication: 5
};
function blankForm() {
	return {
		cgpa: "",
		attendance: "",
		backlogs: "",
		internships: "",
		certifications: "",
		skills: { ...DEFAULT_SKILLS },
		interests: [],
		firstChoice: "",
		secondChoice: ""
	};
}
function AssessPage() {
	const search = Route$6.useSearch();
	const navigate = useNavigate();
	const hydrated = useCareerStore((state) => state.hydrated);
	const overrides = useCareerStore((state) => state.overrides);
	const activeId = useCareerStore((state) => state.activeId);
	const saveStudent = useCareerStore((state) => state.saveStudent);
	const [form, setForm] = (0, import_react.useState)(blankForm);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [loadedId, setLoadedId] = (0, import_react.useState)(null);
	const requestedId = (search.id ?? activeId ?? "").toUpperCase();
	const student = hydrated ? findStudent(requestedId, overrides) : void 0;
	(0, import_react.useEffect)(() => {
		if (!hydrated || !student || student.studentId === loadedId) return;
		if (student.assessed === false) setForm(blankForm());
		else setForm({
			cgpa: String(student.cgpa),
			attendance: String(student.attendance),
			backlogs: String(student.backlogs),
			internships: String(student.internships),
			certifications: String(student.certifications),
			skills: {
				excel: student.excel,
				sql: student.sql,
				python: student.python,
				powerbi: student.powerbi,
				dataAnalysis: student.dataAnalysis,
				communication: student.communication
			},
			interests: student.interests.length ? student.interests : [student.firstChoice, student.secondChoice].filter(Boolean),
			firstChoice: student.firstChoice,
			secondChoice: student.secondChoice
		});
		setLoadedId(student.studentId);
	}, [
		hydrated,
		student,
		loadedId
	]);
	function toggleInterest(career) {
		setForm((current) => {
			const has = current.interests.includes(career);
			return {
				...current,
				interests: has ? current.interests.filter((item) => item !== career) : [...current.interests, career]
			};
		});
	}
	function submit(event) {
		event.preventDefault();
		if (!student) {
			setErrors(["Register a student ID before the assessment, or open a sample profile from the home page."]);
			return;
		}
		const nextErrors = validateAssessment(form);
		setErrors(nextErrors);
		if (nextErrors.length) return;
		const interests = Array.from(/* @__PURE__ */ new Set([
			...form.interests,
			form.firstChoice,
			form.secondChoice
		]));
		const updated = {
			...student,
			studentId: student.studentId.toUpperCase(),
			cgpa: Number(form.cgpa),
			attendance: Number(form.attendance),
			backlogs: Number(form.backlogs),
			internships: Number(form.internships),
			certifications: Number(form.certifications),
			excel: form.skills.excel,
			sql: form.skills.sql,
			python: form.skills.python,
			powerbi: form.skills.powerbi,
			dataAnalysis: form.skills.dataAnalysis,
			communication: form.skills.communication,
			interests,
			firstChoice: form.firstChoice,
			secondChoice: form.secondChoice,
			assessed: true
		};
		saveStudent(updated);
		navigate({ to: "/results" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-3xl gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "Career assessment"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "CGPA uses a 10-point scale. Skill ratings are 1 to 10. The score that follows is a classroom model, not a prediction of a job offer."
			})] }),
			!hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Loading saved profiles…"
			}) : null,
			hydrated && !student ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cardClass,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No student is selected. Register first, or open a sample profile." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-3 text-sm font-semibold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/register",
							className: "text-primary",
							children: "Register"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/assess",
							search: { id: "CAI24001" },
							className: "text-primary",
							children: "Load Aanya Deshmukh (CAI24001)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/assess",
							search: { id: "CAI24006" },
							className: "text-primary",
							children: "Load Rohan Das (CAI24006)"
						})
					]
				})]
			}) : null,
			student ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "grid gap-4",
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: cardClass,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: "Student"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm",
								children: [
									student.name,
									" · ",
									student.studentId,
									" · ",
									student.course,
									" · ",
									student.department
								]
							}),
							student.placementStatus !== "In Progress" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "This ID is in the shared sample. Submitting updates the copy in your browser. The Excel file is not changed."
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: cardClass,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl",
							children: "Academic information"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
									label: "CGPA (0–10)",
									value: form.cgpa,
									onChange: (value) => setForm({
										...form,
										cgpa: value
									}),
									step: "0.1"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
									label: "Attendance %",
									value: form.attendance,
									onChange: (value) => setForm({
										...form,
										attendance: value
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
									label: "Number of backlogs",
									value: form.backlogs,
									onChange: (value) => setForm({
										...form,
										backlogs: value
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
									label: "Internships completed",
									value: form.internships,
									onChange: (value) => setForm({
										...form,
										internships: value
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
									label: "Number of certifications",
									value: form.certifications,
									onChange: (value) => setForm({
										...form,
										certifications: value
									})
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: cardClass,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: "Technical and communication skills"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "1 is a beginner. 10 is confident enough to use the skill in a project."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 grid gap-4",
								children: SKILLS.map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-1 text-sm font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex justify-between",
										children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "tabular-nums",
											children: [form.skills[key], "/10"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 1,
										max: 10,
										step: 1,
										value: form.skills[key],
										onChange: (event) => setForm({
											...form,
											skills: {
												...form.skills,
												[key]: Number(event.target.value)
											}
										})
									})]
								}, key))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: cardClass,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: "Career interests"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 grid gap-2 sm:grid-cols-2",
								children: CAREERS.map((career) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-h-11 items-center gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: form.interests.includes(career),
										onChange: () => toggleInterest(career)
									}), career]
								}, career))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: labelClass,
									children: ["First career choice", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: fieldClass,
										value: form.firstChoice,
										onChange: (event) => setForm({
											...form,
											firstChoice: event.target.value
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Select"
										}), CAREERS.map((career) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: career }, career))]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: labelClass,
									children: ["Second career choice", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: fieldClass,
										value: form.secondChoice,
										onChange: (event) => setForm({
											...form,
											secondChoice: event.target.value
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Select"
										}), CAREERS.map((career) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: career }, career))]
									})]
								})]
							})
						]
					}),
					errors.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-md bg-gap-soft p-3 text-sm text-gap",
						role: "alert",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "list-disc pl-4",
							children: errors.map((error) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: error }, error))
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: btnPrimary,
						children: "Analyze my profile"
					})
				]
			}) : null
		]
	});
}
function NumberField({ label, value, onChange, step }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: labelClass,
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: fieldClass,
			inputMode: "decimal",
			step,
			value,
			onChange: (event) => onChange(event.target.value)
		})]
	});
}
function validateAssessment(form) {
	const errors = [];
	const cgpa = Number(form.cgpa);
	if (form.cgpa.trim() === "" || Number.isNaN(cgpa) || cgpa < 0 || cgpa > 10) errors.push("Enter CGPA from 0 to 10. This project does not use a 4-point scale.");
	else if (cgpa > 0 && cgpa <= 4) errors.push("CGPA is on a 10-point scale. If your mark is out of 4, convert it first. For example, 3.2 out of 4 is about 8.0 out of 10.");
	const attendance = Number(form.attendance);
	if (form.attendance.trim() === "" || Number.isNaN(attendance) || attendance < 0 || attendance > 100) errors.push("Attendance must be between 0 and 100.");
	const backlogs = Number(form.backlogs);
	if (form.backlogs.trim() === "" || !Number.isInteger(backlogs) || backlogs < 0 || backlogs > 20) errors.push("Backlogs must be a whole number from 0 to 20.");
	const internships = Number(form.internships);
	if (form.internships.trim() === "" || !Number.isInteger(internships) || internships < 0 || internships > 10) errors.push("Internships must be a whole number from 0 to 10.");
	const certifications = Number(form.certifications);
	if (form.certifications.trim() === "" || !Number.isInteger(certifications) || certifications < 0 || certifications > 20) errors.push("Certifications must be a whole number from 0 to 20.");
	for (const [key, label] of SKILLS) {
		const score = form.skills[key];
		if (!Number.isInteger(score) || score < 1 || score > 10) errors.push(`${label} must be a whole number from 1 to 10.`);
	}
	if (!form.firstChoice || !form.secondChoice) errors.push("Select a first and a second career choice.");
	if (form.firstChoice && form.firstChoice === form.secondChoice) errors.push("First and second career choices must be different.");
	if (form.interests.length === 0 && !form.firstChoice) errors.push("Select at least one career interest.");
	return errors;
}
//#endregion
export { AssessPage as component };
