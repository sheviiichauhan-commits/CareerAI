-- Twenty fictional students for a quick MySQL demo.
-- Import the full workbook with: python import_excel.py
-- Safe to re-run: deletes these 20 IDs first.
USE careerai_db;

DELETE FROM Placement WHERE Student_ID IN ('CAI24001', 'CAI24002', 'CAI24003', 'CAI24004', 'CAI24005', 'CAI24006', 'CAI24007', 'CAI24008', 'CAI24009', 'CAI24010', 'CAI24011', 'CAI24012', 'CAI24013', 'CAI24014', 'CAI24015', 'CAI24016', 'CAI24017', 'CAI24018', 'CAI24019', 'CAI24020');
DELETE FROM Career_Interest WHERE Student_ID IN ('CAI24001', 'CAI24002', 'CAI24003', 'CAI24004', 'CAI24005', 'CAI24006', 'CAI24007', 'CAI24008', 'CAI24009', 'CAI24010', 'CAI24011', 'CAI24012', 'CAI24013', 'CAI24014', 'CAI24015', 'CAI24016', 'CAI24017', 'CAI24018', 'CAI24019', 'CAI24020');
DELETE FROM Skills WHERE Student_ID IN ('CAI24001', 'CAI24002', 'CAI24003', 'CAI24004', 'CAI24005', 'CAI24006', 'CAI24007', 'CAI24008', 'CAI24009', 'CAI24010', 'CAI24011', 'CAI24012', 'CAI24013', 'CAI24014', 'CAI24015', 'CAI24016', 'CAI24017', 'CAI24018', 'CAI24019', 'CAI24020');
DELETE FROM Academic WHERE Student_ID IN ('CAI24001', 'CAI24002', 'CAI24003', 'CAI24004', 'CAI24005', 'CAI24006', 'CAI24007', 'CAI24008', 'CAI24009', 'CAI24010', 'CAI24011', 'CAI24012', 'CAI24013', 'CAI24014', 'CAI24015', 'CAI24016', 'CAI24017', 'CAI24018', 'CAI24019', 'CAI24020');
DELETE FROM Students WHERE Student_ID IN ('CAI24001', 'CAI24002', 'CAI24003', 'CAI24004', 'CAI24005', 'CAI24006', 'CAI24007', 'CAI24008', 'CAI24009', 'CAI24010', 'CAI24011', 'CAI24012', 'CAI24013', 'CAI24014', 'CAI24015', 'CAI24016', 'CAI24017', 'CAI24018', 'CAI24019', 'CAI24020');

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24001', 'Aanya Deshmukh', 21, 'Female', 'BCA', 3, 6, 'Data Analytics');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24001', 8.8, 94, 0, 2, 3);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24001', 9, 9, 8, 8, 8, 8);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24001', 'Data Analyst', 'Business Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24001', 'Placed', 8.4);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24002', 'Kabir Menon', 21, 'Male', 'BBA', 3, 5, 'Marketing');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24002', 8.1, 88, 0, 1, 1);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24002', 8, 7, 4, 6, 9, 8);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24002', 'Business Analyst', 'Marketing Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24002', 'Placed', 6.5);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24003', 'Meera Iyer', 20, 'Female', 'BBA', 2, 4, 'Human Resources');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24003', 7.8, 91, 0, 1, 2);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24003', 7, 4, 3, 5, 9, 6);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24003', 'HR Analyst', 'Business Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24003', 'Not Placed', NULL);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24004', 'Riya Kapoor', 21, 'Female', 'BBA', 3, 6, 'Marketing');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24004', 8.0, 86, 0, 1, 2);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24004', 7, 4, 3, 6, 9, 7);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24004', 'Marketing Analyst', 'Entrepreneur');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24004', 'Placed', 5.8);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24005', 'Arjun Reddy', 22, 'Male', 'B.Com', 3, 6, 'Finance');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24005', 8.8, 90, 0, 1, 2);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24005', 9, 6, 4, 6, 6, 7);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24005', 'Financial Analyst', 'Business Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24005', 'Placed', 7.6);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24006', 'Rohan Das', 19, 'Male', 'BCA', 1, 2, 'Information Technology');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24006', 5.4, 64, 3, 0, 0);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24006', 4, 3, 3, 3, 4, 3);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24006', 'Data Analyst', 'Business Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24006', 'Not Placed', NULL);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24007', 'Anika Bose', 20, 'Female', 'BBA', 2, 3, 'General Management');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24007', 7.4, 82, 1, 0, 1);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24007', 6, 5, 4, 5, 8, 6);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24007', 'Entrepreneur', 'Marketing Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24007', 'Higher Studies', NULL);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24008', 'Vivaan Shah', 21, 'Male', 'BBA', 3, 5, 'Operations');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24008', 7.2, 79, 1, 1, 1);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24008', 7, 6, 5, 6, 7, 6);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24008', 'Business Analyst', 'Data Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24008', 'Placed', 4.8);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24009', 'Myra Nair', 22, 'Female', 'B.Com', 1, 2, 'Finance');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24009', 7.7, 86, 1, 1, 2);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24009', 8, 6, 6, 6, 7, 5);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24009', 'Business Analyst', 'HR Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24009', 'Placed', 6.0);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24010', 'Ayaan Malhotra', 21, 'Male', 'BBA', 1, 1, 'Finance');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24010', 7.7, 83, 2, 1, 3);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24010', 8, 4, 6, 6, 7, 8);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24010', 'Financial Analyst', 'Business Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24010', 'Placed', 5.7);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24011', 'Ananya Chowdhury', 20, 'Female', 'BBA', 3, 5, 'Finance');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24011', 7.3, 84, 1, 1, 0);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24011', 10, 7, 2, 5, 5, 5);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24011', 'Data Analyst', 'Marketing Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24011', 'Not Placed', NULL);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24012', 'Saanvi Kulkarni', 20, 'Female', 'BBA', 3, 6, 'Marketing');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24012', 7.0, 77, 0, 0, 1);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24012', 8, 3, 2, 4, 7, 6);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24012', 'Marketing Analyst', 'HR Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24012', 'Placed', 4.9);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24013', 'Yash Reddy', 21, 'Male', 'BCA', 1, 2, 'Data Analytics');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24013', 8.0, 88, 0, 2, 2);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24013', 8, 10, 8, 7, 4, 9);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24013', 'Financial Analyst', 'Data Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24013', 'Not Placed', NULL);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24014', 'Aisha Banerjee', 21, 'Female', 'BCA', 1, 1, 'Information Technology');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24014', 7.7, 93, 1, 0, 3);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24014', 7, 8, 9, 8, 7, 7);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24014', 'Business Analyst', 'HR Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24014', 'Placed', 6.7);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24015', 'Kabir Malhotra', 20, 'Male', 'BCA', 2, 4, 'Information Technology');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24015', 8.0, 80, 0, 2, 1);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24015', 5, 6, 8, 7, 5, 6);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24015', 'Data Analyst', 'Marketing Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24015', 'Placed', 6.2);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24016', 'Shruti Joshi', 21, 'Female', 'BBA', 3, 6, 'Finance');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24016', 7.4, 79, 0, 0, 2);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24016', 9, 5, 4, 7, 6, 8);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24016', 'Business Analyst', 'Data Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24016', 'Placed', 5.7);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24017', 'Myra Kulkarni', 21, 'Female', 'BCA', 1, 1, 'Information Technology');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24017', 8.3, 83, 1, 1, 1);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24017', 6, 8, 9, 6, 7, 8);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24017', 'Entrepreneur', 'Financial Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24017', 'Placed', 6.0);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24018', 'Siddharth Rao', 21, 'Male', 'BBA', 2, 3, 'Marketing');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24018', 6.8, 84, 0, 1, 3);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24018', 7, 3, 5, 4, 8, 7);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24018', 'Marketing Analyst', 'Business Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24018', 'Higher Studies', NULL);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24019', 'Kavya Chowdhury', 19, 'Female', 'B.Com', 2, 4, 'General Management');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24019', 7.6, 78, 1, 1, 1);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24019', 6, 5, 3, 6, 8, 5);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24019', 'Entrepreneur', 'Marketing Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24019', 'Not Placed', NULL);

INSERT INTO Students (Student_ID, Name, Age, Gender, Course, Year, Semester, Department) VALUES ('CAI24020', 'Kunal Nair', 18, 'Male', 'BBA', 2, 4, 'Marketing');
INSERT INTO Academic (Student_ID, CGPA, Attendance, Backlogs, Internship, Certifications) VALUES ('CAI24020', 7.6, 82, 0, 0, 1);
INSERT INTO Skills (Student_ID, Excel_Score, SQL_Score, Python_Score, PowerBI_Score, Communication_Score, Data_Analysis_Score) VALUES ('CAI24020', 6, 2, 6, 8, 7, 4);
INSERT INTO Career_Interest (Student_ID, First_Choice, Second_Choice) VALUES ('CAI24020', 'Marketing Analyst', 'Data Analyst');
INSERT INTO Placement (Student_ID, Placement_Status, Package) VALUES ('CAI24020', 'Not Placed', NULL);
