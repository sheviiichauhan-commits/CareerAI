-- CareerAI MySQL schema
-- Database: careerai_db
-- Fictional student project. Do not load real student records.
-- Engine InnoDB is required so the foreign keys are enforced.

CREATE DATABASE IF NOT EXISTS careerai_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE careerai_db;

-- Drop child tables first so this script can be re-run in a demo.
DROP TABLE IF EXISTS Placement;
DROP TABLE IF EXISTS Career_Interest;
DROP TABLE IF EXISTS Skills;
DROP TABLE IF EXISTS Academic;
DROP TABLE IF EXISTS Students;

-- One row per student. Student_ID is the primary key.
CREATE TABLE Students (
  Student_ID VARCHAR(20) NOT NULL,
  Name VARCHAR(120) NOT NULL,
  Age INT NOT NULL,
  Gender VARCHAR(30) NOT NULL,
  Course VARCHAR(40) NOT NULL,
  Year INT NOT NULL,
  Semester INT NOT NULL,
  Department VARCHAR(80) NOT NULL,
  PRIMARY KEY (Student_ID)
);

-- Marks and experience. Academic_ID is its own primary key.
-- Student_ID must already exist in Students.
CREATE TABLE Academic (
  Academic_ID INT NOT NULL AUTO_INCREMENT,
  Student_ID VARCHAR(20) NOT NULL,
  CGPA DECIMAL(4,1) NOT NULL,
  Attendance DECIMAL(5,1) NOT NULL,
  Backlogs INT NOT NULL,
  Internship INT NOT NULL,
  Certifications INT NOT NULL,
  PRIMARY KEY (Academic_ID),
  CONSTRAINT fk_academic_student
    FOREIGN KEY (Student_ID) REFERENCES Students (Student_ID)
);

-- Self-rated skills, 1 to 10.
CREATE TABLE Skills (
  Skill_ID INT NOT NULL AUTO_INCREMENT,
  Student_ID VARCHAR(20) NOT NULL,
  Excel_Score INT NOT NULL,
  SQL_Score INT NOT NULL,
  Python_Score INT NOT NULL,
  PowerBI_Score INT NOT NULL,
  Communication_Score INT NOT NULL,
  Data_Analysis_Score INT NOT NULL,
  PRIMARY KEY (Skill_ID),
  CONSTRAINT fk_skills_student
    FOREIGN KEY (Student_ID) REFERENCES Students (Student_ID)
);

-- First and second career choices from the assessment.
CREATE TABLE Career_Interest (
  Interest_ID INT NOT NULL AUTO_INCREMENT,
  Student_ID VARCHAR(20) NOT NULL,
  First_Choice VARCHAR(40) NOT NULL,
  Second_Choice VARCHAR(40) NOT NULL,
  PRIMARY KEY (Interest_ID),
  CONSTRAINT fk_interest_student
    FOREIGN KEY (Student_ID) REFERENCES Students (Student_ID)
);

-- Placement outcome for the sample cohort.
-- Package is NULL when the student was not placed.
CREATE TABLE Placement (
  Placement_ID INT NOT NULL AUTO_INCREMENT,
  Student_ID VARCHAR(20) NOT NULL,
  Placement_Status VARCHAR(30) NOT NULL,
  Package DECIMAL(5,1) NULL,
  PRIMARY KEY (Placement_ID),
  CONSTRAINT fk_placement_student
    FOREIGN KEY (Student_ID) REFERENCES Students (Student_ID)
);
