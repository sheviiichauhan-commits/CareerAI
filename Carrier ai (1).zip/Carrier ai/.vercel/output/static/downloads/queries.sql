-- CareerAI teaching queries
-- Run these after schema.sql and after the Excel file has been imported.
-- USE careerai_db;

-- 1. Students with attendance below 75%.
-- Attendance is stored as a percentage. 75 is the usual college cutoff used in this project.
SELECT s.Student_ID, s.Name, s.Department, a.Attendance
FROM Students AS s
JOIN Academic AS a ON a.Student_ID = s.Student_ID
WHERE a.Attendance < 75
ORDER BY a.Attendance ASC;

-- 2. Average CGPA of the whole cohort.
-- AVG ignores nothing here because CGPA is required. ROUND keeps two decimals.
SELECT ROUND(AVG(CGPA), 2) AS Average_CGPA
FROM Academic;

-- 3. Students with a SQL score above 8.
-- Scores are on a 1–10 scale. Above 8 means 9 or 10.
SELECT s.Student_ID, s.Name, sk.SQL_Score
FROM Students AS s
JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
WHERE sk.SQL_Score > 8
ORDER BY sk.SQL_Score DESC, s.Name;

-- 4. Average skill scores.
-- One row, six averages, so they can be compared in a table or a bar chart.
SELECT
  ROUND(AVG(Excel_Score), 2) AS Average_Excel,
  ROUND(AVG(SQL_Score), 2) AS Average_SQL,
  ROUND(AVG(Python_Score), 2) AS Average_Python,
  ROUND(AVG(PowerBI_Score), 2) AS Average_PowerBI,
  ROUND(AVG(Communication_Score), 2) AS Average_Communication,
  ROUND(AVG(Data_Analysis_Score), 2) AS Average_Data_Analysis
FROM Skills;

-- 5. Most preferred careers.
-- First_Choice is the student's main interest. The largest count is the most preferred career.
SELECT First_Choice, COUNT(*) AS Students
FROM Career_Interest
GROUP BY First_Choice
ORDER BY Students DESC;

-- 6. Placement percentage.
-- Only rows marked Placed count as placed. Higher Studies is not counted as placed.
SELECT
  COUNT(*) AS Students_With_Status,
  SUM(Placement_Status = 'Placed') AS Placed_Students,
  ROUND(100 * SUM(Placement_Status = 'Placed') / COUNT(*), 1) AS Placement_Percentage
FROM Placement;

-- 7. Department-wise performance.
-- Average CGPA and attendance for each department, highest CGPA first.
SELECT
  s.Department,
  COUNT(*) AS Students,
  ROUND(AVG(a.CGPA), 2) AS Average_CGPA,
  ROUND(AVG(a.Attendance), 1) AS Average_Attendance
FROM Students AS s
JOIN Academic AS a ON a.Student_ID = s.Student_ID
GROUP BY s.Department
ORDER BY Average_CGPA DESC;

-- 8. Students with high career readiness.
-- This repeats the project weights in SQL:
--   CGPA 25%, technical average 30%, communication 15%,
--   attendance 10%, internship 10%, certifications 10%.
-- Internship points: 0 → 0, 1 → 6, 2 or more → 10.
-- Certification points: 0 → 0, 1 → 4, 2 → 7, 3 or more → 10.
-- The website rounds each part to 2 decimals before summing, so a score here can differ by 1.
SELECT
  s.Student_ID,
  s.Name,
  s.Department,
  ROUND(
    (a.CGPA / 10) * 25
    + ((sk.Excel_Score + sk.SQL_Score + sk.Python_Score + sk.PowerBI_Score + sk.Data_Analysis_Score) / 5) / 10 * 30
    + (sk.Communication_Score / 10) * 15
    + (a.Attendance / 100) * 10
    + CASE
        WHEN a.Internship <= 0 THEN 0
        WHEN a.Internship = 1 THEN 6
        ELSE 10
      END
    + CASE
        WHEN a.Certifications <= 0 THEN 0
        WHEN a.Certifications = 1 THEN 4
        WHEN a.Certifications = 2 THEN 7
        ELSE 10
      END
  , 0) AS Career_Readiness
FROM Students AS s
JOIN Academic AS a ON a.Student_ID = s.Student_ID
JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
HAVING Career_Readiness >= 80
ORDER BY Career_Readiness DESC;

-- 9. Skill gaps.
-- Project rule: a score below 6 out of 10 is a gap.
-- UNION ALL stacks one row per weak skill so the result can be counted by skill name.
SELECT s.Student_ID, s.Name, 'Excel' AS Skill, sk.Excel_Score AS Score
FROM Students AS s JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
WHERE sk.Excel_Score < 6
UNION ALL
SELECT s.Student_ID, s.Name, 'SQL', sk.SQL_Score
FROM Students AS s JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
WHERE sk.SQL_Score < 6
UNION ALL
SELECT s.Student_ID, s.Name, 'Python', sk.Python_Score
FROM Students AS s JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
WHERE sk.Python_Score < 6
UNION ALL
SELECT s.Student_ID, s.Name, 'Power BI', sk.PowerBI_Score
FROM Students AS s JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
WHERE sk.PowerBI_Score < 6
UNION ALL
SELECT s.Student_ID, s.Name, 'Communication', sk.Communication_Score
FROM Students AS s JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
WHERE sk.Communication_Score < 6
UNION ALL
SELECT s.Student_ID, s.Name, 'Data Analysis', sk.Data_Analysis_Score
FROM Students AS s JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
WHERE sk.Data_Analysis_Score < 6
ORDER BY Student_ID, Skill;

-- 10. One JOIN across student, academic, skills, and career data.
-- Placement is included so a teacher can see the full row used by the recommendation engine.
SELECT
  s.Student_ID,
  s.Name,
  s.Course,
  s.Year,
  s.Department,
  a.CGPA,
  a.Attendance,
  a.Backlogs,
  a.Internship,
  a.Certifications,
  sk.Excel_Score,
  sk.SQL_Score,
  sk.Python_Score,
  sk.PowerBI_Score,
  sk.Communication_Score,
  sk.Data_Analysis_Score,
  c.First_Choice,
  c.Second_Choice,
  p.Placement_Status,
  p.Package
FROM Students AS s
JOIN Academic AS a ON a.Student_ID = s.Student_ID
JOIN Skills AS sk ON sk.Student_ID = s.Student_ID
JOIN Career_Interest AS c ON c.Student_ID = s.Student_ID
JOIN Placement AS p ON p.Student_ID = s.Student_ID
ORDER BY s.Student_ID;
